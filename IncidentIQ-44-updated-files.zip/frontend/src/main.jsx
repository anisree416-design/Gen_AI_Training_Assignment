import '@fontsource-variable/inter'
import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './styles.css'
import Incidents from './Incidents.jsx'

const dashboard = window.location.pathname.replace(/\/$/, '') === '/incidents'
createRoot(document.getElementById('root')).render(<React.StrictMode>{dashboard ? <Incidents /> : <><App /><a className="iq-pos-link" href="/incidents" target="_blank" rel="noreferrer">IncidentIQ · RCA</a></>}</React.StrictMode>)

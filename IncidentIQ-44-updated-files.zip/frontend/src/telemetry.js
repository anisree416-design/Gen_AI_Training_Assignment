﻿// Logging is deliberately independent of the POS API client: no recursive logging.
let context = { screen: 'LOGIN', cashier: null, orderNumber: null, lane: 59 }
let queue = []
let sending = false
let sequence = 0
let recentErrors = []
let sessionId = 'browser'
try {
  sessionId = sessionStorage.getItem('keele-trace') || crypto.randomUUID()
  sessionStorage.setItem('keele-trace', sessionId)
} catch { /* Storage is optional for telemetry. */ }
const sensitive = /password|authorization|token|cookie|secret|cardnumber|cvv|^pin$/i
export function redact(value, depth = 0) {
  if (depth > 8) return '[truncated]'
  if (Array.isArray(value)) return value.slice(0, 100).map(item => redact(item, depth + 1))
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).slice(0, 100).map(([key, item]) => [key, sensitive.test(key.replaceAll('_', '')) ? '[REDACTED]' : redact(item, depth + 1)]))
  return typeof value === 'string' ? value.slice(0, 4000) : value
}
export function setLogContext(next) { try { context = { ...context, ...next } } catch { /* Best effort. */ } }
export function getLogContext() { return { ...context, sessionId } }
export function buildMessage(eventType, details = {}, status = 'SUCCESS', snapshot = context) {
  if (details.message) return String(details.message)
  const order = details.orderNumber ?? snapshot.orderNumber
  const orderText = order ? ` for order ${order}` : ''
  const messages = {
    SCREEN_VIEW: () => `Opened ${details.screen || snapshot.screen} screen`,
    LOGIN_ATTEMPT: () => `Sign-in attempt started for partner ${details.partnerId || 'unknown'}`,
    LOGIN_SUCCESS: () => `${details.cashier?.name || 'Cashier'} signed in successfully`,
    LOGIN_FAILED: () => `Sign-in failed for partner ${details.partnerId || 'unknown'}`,
    LOGOUT_SUCCESS: () => 'Cashier signed out successfully',
    LOGOUT_FAILED: () => 'Cashier sign-out failed',
    LOGOUT_BLOCKED: () => `Sign-out blocked: ${details.reason || 'active operation'}`,
    CATEGORY_SELECTED: () => `${details.category || 'Catalog'} category selected`,
    CATALOG_SEARCH: () => `Catalog searched for "${details.query || ''}"`,
    CATALOG_LOADED: () => `Catalog loaded with ${details.productCount ?? 0} products`,
    CATALOG_LOAD_FAILED: () => 'Catalog could not be loaded',
    PLU_ENTRY_CHANGED: () => `PLU entry updated to ${details.plu || 'empty'} using ${details.inputMethod || 'input'}`,
    PLU_ENTRY_CLEARED: () => 'PLU entry cleared',
    PLU_LOOKUP: () => `PLU lookup started for ${details.plu || 'empty value'}`,
    PLU_LOOKUP_SUCCEEDED: () => `PLU ${details.plu} matched ${details.name}`,
    PLU_LOOKUP_FAILED: () => `PLU lookup failed for ${details.plu || 'empty value'}`,
    ORDER_STARTED: () => `Order ${details.orderNumber} started`,
    ITEM_ADDED: () => `${details.name || details.productId} added to order ${details.orderNumber || order || 'pending'}`,
    ITEM_ADD_FAILED: () => `${details.name || details.productId || 'Item'} could not be added${orderText}`,
    ITEM_REMOVED: () => `${details.productId} removed${orderText}`,
    ITEM_QUANTITY_CHANGED: () => `${details.productId} quantity changed from ${details.previousQuantity} to ${details.quantity}${orderText}`,
    CART_CLEARED: () => `Cart cleared${orderText}`,
    CHECKOUT_STARTED: () => `Checkout started${orderText}`,
    CHECKOUT_READY: () => `Checkout total calculated${orderText}`,
    CHECKOUT_FAILED: () => `Checkout failed${orderText}`,
    PAYMENT_METHOD_SELECTED: () => `${details.displayName || details.method || 'Payment method'} selected${orderText}`,
    PAYMENT_METHOD_UNAVAILABLE: () => `${details.displayName || details.method || 'Payment method'} is unavailable${orderText}`,
    CASH_TENDER_CHANGED: () => `Cash tender updated to ${details.amountTenderedCents ?? 0} cents${orderText}`,
    PAYMENT_STARTED: () => `${details.method === 'card' ? 'Electronic' : 'Cash'} payment started${orderText}`,
    ELECTRONIC_PAYMENT_STARTED: () => `Electronic payment authorization started${orderText}`,
    ELECTRONIC_PAYMENT_COMPLETED: () => `Electronic payment approved${orderText}`,
    ELECTRONIC_PAYMENT_FAILED: () => `Electronic payment failed${orderText}`,
    CASH_PAYMENT_STARTED: () => `Cash payment started${orderText}`,
    CASH_PAYMENT_COMPLETED: () => `Cash payment completed${orderText}`,
    CASH_PAYMENT_FAILED: () => `Cash payment failed${orderText}`,
    PAYMENT_COMPLETED: () => `${details.method === 'card' ? 'Electronic' : 'Cash'} payment completed${orderText}`,
    PAYMENT_FAILED: () => `${details.method === 'card' ? 'Electronic' : 'Cash'} payment failed${orderText}`,
    ORDER_COMPLETED: () => `Order ${details.orderNumber || order} completed successfully`,
    UI_ACTION: () => `User selected ${details.action || 'a control'}`,
    FIELD_CHANGED: () => `${details.field || 'Field'} value changed`,
    UI_ERROR: () => 'An interface error was displayed',
    CLIENT_ERROR: () => 'An unexpected browser error occurred',
    API_REQUEST: () => `${details.method || 'GET'} ${details.path || 'API'} request started`,
    API_RESPONSE: () => `${details.method || 'GET'} ${details.path || 'API'} returned HTTP ${details.httpStatus}`,
    API_ERROR: () => `${details.method || 'GET'} ${details.path || 'API'} request failed`,
  }
  const factory = messages[eventType]
  if (factory) return factory()
  const readable = String(eventType || 'EVENT').replaceAll('_', ' ').toLowerCase()
  return `${readable.charAt(0).toUpperCase()}${readable.slice(1)} (${String(status).toLowerCase()})`
}
export function logEvent(eventType, details = {}, status = 'SUCCESS', snapshot = context) {
  try {
    if (status === 'ERROR' && !details.requestId && !details.flowId) details = { ...details, flowId: crypto.randomUUID() }
    if (queue.length >= 200) queue.shift()
    const message = buildMessage(eventType, details, status, snapshot)
    if (status === 'ERROR' && eventType !== 'UI_ERROR') {
      recentErrors = [...recentErrors.slice(-19), { message, details, at: Date.now() }]
    }
    queue.push(redact({ ...snapshot, ...details, application: 'incidentiq_frontend', environment: 'DEMO', eventType, message, userFlow: snapshot.screen, status, sessionId, sequence: ++sequence, timestamp: new Date().toISOString() }))
  } catch { /* Never affect the register. */ }
}
export function logDisplayedError(message) {
  // Carry the originating request through to its dialog. Pure UI validation
  // failures get their own identity without borrowing a previous request.
  const source = [...recentErrors].reverse().find(error => error.message === message && Date.now() - error.at < 3000)
  const trace = source?.details || { flowId: crypto.randomUUID() }
  logEvent('UI_ERROR', { ...trace, message }, 'ERROR')
}
async function flush() {
  if (sending || !queue.length) return
  sending = true
  const events = queue.splice(0, 20)
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 2000)
  try {
    await fetch('/api/telemetry', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ events }), signal: controller.signal })
  } catch { /* Drop failed batches. No retries or cashier-facing errors. */ }
  finally { clearTimeout(timeout); sending = false }
}
setInterval(flush, 1000)
window.addEventListener('pagehide', () => {
  try { if (queue.length) navigator.sendBeacon('/api/telemetry', new Blob([JSON.stringify({ events: queue.splice(0, 20) })], { type: 'application/json' })) } catch { /* Best effort. */ }
})
window.addEventListener('error', event => logEvent('CLIENT_ERROR', { message: event.message, file: event.filename, line: event.lineno }, 'ERROR'))
window.addEventListener('unhandledrejection', event => logEvent('CLIENT_ERROR', { message: String(event.reason?.message || 'Unhandled promise rejection') }, 'ERROR'))
// Record button intent without input values or credential keypad digits.
document.addEventListener('click', event => {
  try {
    const button = event.target.closest('button')
    if (!button) return
    const isLogin = !!button.closest('.login-screen')
    const label = isLogin && button.closest('.key-grid') ? 'Login keypad control' : button.getAttribute('aria-label') || button.textContent.trim().replace(/\s+/g, ' ').slice(0, 100)
    logEvent('UI_ACTION', { action: label, control: button.className })
  } catch { /* Best effort. */ }
}, true)

document.addEventListener('change', event => {
  try {
    const input = event.target
    const field = input.getAttribute('aria-label')
    if (['PLU', 'Cash amount', 'Search catalog'].includes(field)) logEvent('FIELD_CHANGED', { field, value: input.value })
  } catch { /* Best effort. */ }
})

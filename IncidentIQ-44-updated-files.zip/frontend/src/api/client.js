import { getLogContext, logEvent } from '../telemetry.js'

function errorMessage(detail) {
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail)) {
    return detail.map(item => {
      const field = Array.isArray(item.loc) ? item.loc.filter(part => part !== 'body').join('.') : ''
      return `${field ? field + ': ' : ''}${item.msg || 'Invalid value'}`
    }).join('; ')
  }
  return 'Something went wrong. Please try again.'
}

export async function api(path, { token, ...options } = {}) {
  const snapshot = getLogContext()
  const requestId = crypto.randomUUID()
  const started = performance.now()
  const method = options.method || 'GET'
  let requestBody
  try { requestBody = options.body ? JSON.parse(options.body) : null } catch { requestBody = '[non-JSON body omitted]' }
  logEvent('API_REQUEST', { requestId, path: `/api${path}`, method, requestBody }, 'STARTED', snapshot)
  let response
  let data
  try {
    response = await fetch(`/api${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(snapshot.orderNumber != null ? { 'X-Order-Number': String(snapshot.orderNumber) } : {}),
        ...options.headers,
        'X-Request-ID': requestId,
        'X-Session-ID': snapshot.sessionId,
      },
    })
    const raw = await response.text()
    try {
      data = raw ? JSON.parse(raw) : {}
    } catch {
      data = {
        detail: response.ok
          ? 'The backend returned an unreadable response.'
          : `The backend returned HTTP ${response.status} instead of JSON. Check that the API server and frontend proxy use the same port.`,
      }
    }
  } catch (error) {
    logEvent('API_ERROR', { requestId, path: `/api${path}`, method, durationMs: Math.round(performance.now() - started), message: error.message }, 'ERROR', snapshot)
    error.telemetry = { requestId, path: `/api${path}`, method }
    throw error
  }
  logEvent('API_RESPONSE', { requestId, path: `/api${path}`, method, httpStatus: response.status, durationMs: Math.round(performance.now() - started), responseBody: data, orderNumber: data.order_number ?? snapshot.orderNumber }, response.ok ? 'SUCCESS' : 'ERROR', snapshot)
  if (!response.ok) {
    const error = new Error(errorMessage(data.detail))
    error.telemetry = { requestId, path: `/api${path}`, method, httpStatus: response.status }
    throw error
  }
  return data
}

import { useEffect, useState } from 'react'
import './incidents.css'

const PAGE_SIZE = 25
function selectedId() {
  try { return decodeURIComponent(window.location.hash.slice(1)) || null } catch { return null }
}
function readViewed() {
  try { return JSON.parse(localStorage.getItem('iq-viewed-incidents')) || {} } catch { return {} }
}

async function read(path, signal) {
  const response = await fetch(`/api${path}`, { signal, cache: 'no-store', headers: { 'Cache-Control': 'no-cache' } })
  if (!response.ok) throw new Error(`Could not load incident data (HTTP ${response.status}).`)
  return response.json()
}

async function remove(path) {
  const response = await fetch(`/api${path}`, { method: 'DELETE' })
  if (!response.ok) throw new Error(`Could not delete incident data (HTTP ${response.status}).`)
  return response.json()
}

async function create(path) {
  const response = await fetch(`/api${path}`, {
    method: 'POST',
    headers: { Accept: 'application/json' },
  })
  const payload = await response.json().catch(() => null)
  if (!response.ok) throw new Error(payload?.detail || `Could not prepare a fix (HTTP ${response.status}).`)
  return payload
}

function formatDate(value) {
  if (!value) return 'Not available'
  const parsed = new Date(value.includes('T') ? value : `${value.replace(' ', 'T')}Z`)
  return Number.isNaN(parsed.valueOf()) ? value : parsed.toLocaleString()
}

function incidentLabel(item) {
  return item?.incident_number ? `INC-${String(item.incident_number).padStart(5, '0')}` : item?.incident_id
}


function TextList({ items, empty = 'None reported.' }) {
  return items?.length
    ? <ul>{items.map((item, index) => <li key={index}>{item}</li>)}</ul>
    : <p className="iq-muted">{empty}</p>
}

function observedStep(log, index) {
  const details = log.metadata || log.details || {}
  const action = details.action || details.eventType || log.message || `Event ${index + 1}`
  const endpoint = [details.method, details.path].filter(Boolean).join(' ')
  const bodyDetail = details.responseBody?.detail
  const responseDetail = Array.isArray(bodyDetail)
    ? bodyDetail.map(item => item.msg || String(item)).join('; ')
    : bodyDetail
  const response = [details.httpStatus ? `Response ${details.httpStatus}` : details.status, responseDetail].filter(Boolean).join(': ')
  const submitted = details.requestBody ? `Submitted ${JSON.stringify(details.requestBody)}` : ''
  return {
    id: `observed-${index}`,
    title: String(action).replaceAll('_', ' ').toLowerCase(),
    detail: [endpoint, submitted, response, log.message !== action ? log.message : ''].filter(Boolean).join(' · '),
    timestamp: log.timestamp,
  }
}

export default function Incidents() {
  const [page, setPage] = useState(0)
  const [items, setItems] = useState([])
  const [total, setTotal] = useState(0)
  const [selected, setSelected] = useState(selectedId)
  const [detail, setDetail] = useState(null)
  const [pipeline, setPipeline] = useState(null)
  const [error, setError] = useState('')
  const [detailError, setDetailError] = useState('')
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [fixing, setFixing] = useState(false)
  const [viewed, setViewed] = useState(readViewed)

  useEffect(() => {
    const change = () => setSelected(selectedId())
    window.addEventListener('hashchange', change)
    return () => window.removeEventListener('hashchange', change)
  }, [])

  useEffect(() => {
    const controller = new AbortController()
    let timer
    async function poll() {
      try {
        const [records, status] = await Promise.all([
          read(`/incidents?limit=${PAGE_SIZE}&offset=${page * PAGE_SIZE}`, controller.signal),
          read('/pipeline/status', controller.signal).catch(() => null),
        ])
        setItems(records.items)
        setTotal(records.total)
        if (page > 0 && page * PAGE_SIZE >= records.total) setPage(Math.max(0, Math.ceil(records.total / PAGE_SIZE) - 1))
        setPipeline(status)
        setError('')
      } catch (failure) {
        if (failure.name !== 'AbortError') setError(`${failure.message} Check that the backend is running.`)
      } finally {
        setLoading(false)
        if (!controller.signal.aborted) timer = setTimeout(poll, 1000)
      }
    }
    poll()
    return () => { controller.abort(); clearTimeout(timer) }
  }, [page])

  useEffect(() => {
    const controller = new AbortController()
    let timer
    setDetail(null)
    setDetailError('')
    if (!selected) return () => controller.abort()
    async function poll() {
      try {
        const record = await read(`/incidents/${encodeURIComponent(selected)}`, controller.signal)
        setDetail(record)
        setViewed(previous => {
          const next = { ...previous, [record.incident_id]: true }
          try { localStorage.setItem('iq-viewed-incidents', JSON.stringify(next)) } catch { /* In-memory state remains available. */ }
          return next
        })
        setDetailError('')
      } catch (failure) {
        if (failure.name !== 'AbortError') setDetailError(failure.message)
      } finally {
        if (!controller.signal.aborted) timer = setTimeout(poll, 1000)
      }
    }
    poll()
    return () => { controller.abort(); clearTimeout(timer) }
  }, [selected])

  async function refreshNow() {
    setRefreshing(true)
    setError('')
    setDetailError('')
    try {
      const [records, status, selectedRecord] = await Promise.all([
        read(`/incidents?limit=${PAGE_SIZE}&offset=${page * PAGE_SIZE}`),
        read('/pipeline/status').catch(() => null),
        selected ? read(`/incidents/${encodeURIComponent(selected)}`) : Promise.resolve(null),
      ])
      setItems(records.items)
      setTotal(records.total)
      setPipeline(status)
      if (selectedRecord) setDetail(selectedRecord)
    } catch (failure) {
      if (selected) setDetailError(failure.message)
      else setError(failure.message)
    } finally {
      setRefreshing(false)
    }
  }

  async function deleteOne(id) {
    if (!window.confirm('Delete this incident and its RCA details?')) return
    setDeleting(true)
    try {
      await remove(`/incidents/${encodeURIComponent(id)}`)
      setItems(current => current.filter(item => item.incident_id !== id))
      setTotal(current => Math.max(0, current - 1))
      setViewed(current => {
        const next = { ...current }
        delete next[id]
        try { localStorage.setItem('iq-viewed-incidents', JSON.stringify(next)) } catch { /* Ignore storage failures. */ }
        return next
      })
      if (selected === id) window.location.hash = ''
    } catch (failure) {
      setError(failure.message)
      setDetailError(failure.message)
    } finally {
      setDeleting(false)
    }
  }

  async function deleteAll() {
    if (!total || !window.confirm(`Delete all ${total} incidents and their RCA details? This cannot be undone.`)) return
    setDeleting(true)
    try {
      await remove('/incidents')
      setItems([])
      setTotal(0)
      setDetail(null)
      setViewed({})
      try { localStorage.removeItem('iq-viewed-incidents') } catch { /* Ignore storage failures. */ }
      window.location.hash = ''
    } catch (failure) {
      setError(failure.message)
      setDetailError(failure.message)
    } finally {
      setDeleting(false)
    }
  }

  async function prepareFix() {
    if (!selected || fixing) return
    setFixing(true)
    setDetailError('')
    try {
      const updated = await create(`/incidents/${encodeURIComponent(selected)}/fix`)
      setDetail(updated)
    } catch (failure) {
      setDetailError(failure.message)
    } finally {
      setFixing(false)
    }
  }

  function openIncident(id) {
    window.location.hash = encodeURIComponent(id)
  }

  const rca = detail?.rca
  const observedSteps = (detail?.context?.logs || [])
    .slice()
    .sort((a, b) => String(a.timestamp || '').localeCompare(String(b.timestamp || '')))
    .map(observedStep)

  return <main className="iq-page">
    <header className="iq-header">
      <div>
        <span className="iq-eyebrow">INCIDENTIQ · OPERATIONS</span>
        <h1>{selected ? incidentLabel(detail || items.find(item => item.incident_id === selected)) : 'Incidents'}</h1>
        <p>{selected ? 'Root cause and the complete observed request flow.' : 'A simple view of every detected incident.'}</p>
      </div>
      <div className="iq-actions">
        {selected && <button className="iq-secondary" onClick={() => { window.location.hash = '' }}>Back to incidents</button>}
        {selected && <button className="iq-danger" disabled={deleting} onClick={() => deleteOne(selected)}>Delete incident</button>}
        <button disabled={refreshing} onClick={refreshNow}>{refreshing ? 'Refreshing…' : 'Refresh'}</button>
      </div>
    </header>

    {!selected && <div className="iq-list-summary">
      <div><strong>{total}</strong><span>Total incidents</span></div>
      <div className="iq-pipeline"><span className={`iq-dot ${pipeline?.state === 'polling' ? 'is-live' : ''}`} />{(pipeline?.state || 'connecting').replaceAll('_', ' ')}</div>
    </div>}

    {pipeline?.missing_settings?.length > 0 && <div className="iq-notice" role="status">New incident collection needs attention. Contact the administrator to check connection settings. Saved incidents remain available.</div>}
    {pipeline?.last_error && <div className="iq-notice" role="status">{pipeline.last_error}</div>}
    {error && <div className="iq-error" role="alert">{error}</div>}

    {!selected ? <section className="iq-list-panel" aria-label="Incident list">
      <div className="iq-list-heading"><div><h2>All incidents</h2><span>Live updates every second</span></div><button className="iq-danger" disabled={!total || deleting} onClick={deleteAll}>Delete all</button></div>
      {loading && <p className="iq-empty">Loading incidents…</p>}
      {!loading && !items.length && <p className="iq-empty">No incidents have been detected yet.</p>}
      <div className="iq-incident-list">{items.map(item => <article className="iq-incident" key={item.incident_id}>
        <div className="iq-incident-main">
          <div className="iq-card-topline">
            <strong>{incidentLabel(item)}</strong>
            {!viewed[item.incident_id] && <span className="iq-new-badge">New</span>}
            <span className={`iq-badge ${item.rca?.severity || item.error_event.severity}`}>{item.rca?.severity || item.error_event.severity}</span>
          </div>
          <p>{item.short_analysis || item.rca?.summary || item.error_event.message}</p>
          <div className="iq-basic-details">
            <span>{formatDate(item.occurred_at || item.error_event.occurred_at || item.updated_at)}</span>
            <span>{item.status.replaceAll('_', ' ')}</span>
          </div>
        </div>
        <div className="iq-card-actions"><button className="iq-danger" disabled={deleting} onClick={() => deleteOne(item.incident_id)} aria-label={`Delete ${incidentLabel(item)}`}>Delete</button><button className="iq-view-button" onClick={() => openIncident(item.incident_id)} aria-label={`View details for ${incidentLabel(item)}`}>View details</button></div>
      </article>)}</div>
      {total > PAGE_SIZE && <div className="iq-pagination">
        <button disabled={page === 0} onClick={() => setPage(value => value - 1)}>Previous</button>
        <span>Page {page + 1} of {Math.ceil(total / PAGE_SIZE)}</span>
        <button disabled={(page + 1) * PAGE_SIZE >= total} onClick={() => setPage(value => value + 1)}>Next</button>
      </div>}
    </section> : <article className="iq-detail" aria-label="Incident details">
      {detailError && <div className="iq-error" role="alert">{detailError}</div>}
      {!detail ? <p className="iq-empty">Loading incident details…</p> : <>
        <div className="iq-detail-heading">
          <div><span className="iq-eyebrow">{detail.incident_id}</span><h2>{rca?.summary || detail.error_event.message}</h2></div>
          <span className="iq-badge">{detail.status.replaceAll('_', ' ')}</span>
        </div>
        <dl className="iq-metadata">
          <div><dt>Occurred</dt><dd>{formatDate(detail.occurred_at || detail.error_event.occurred_at)}</dd></div>
          <div><dt>Component</dt><dd>{rca?.impacted_component || detail.error_event.system}</dd></div>
          <div><dt>Related error events</dt><dd>{detail.event_count}</dd></div>
          <div><dt>Transaction</dt><dd>{detail.error_event.txn_id || 'Not supplied'}</dd></div>
        </dl>

        {detail.error && <div className="iq-error" role="alert">{detail.error}</div>}
        {!rca ? <div className="iq-notice">{detail.status === 'failed' ? 'Analysis failed and will be retried.' : 'This incident is being analyzed. The page updates automatically.'}</div> : <>
          <section className="iq-root-cause">
            <div className="iq-section-title"><h3>Root cause</h3><span>{Math.round(rca.confidence * 100)}% confidence</span></div>
            <p>{rca.root_cause}</p>
          </section>

          <section>
            <h3>What happened</h3>
            {rca.sequence_of_events?.length ? <ol className="iq-timeline">{rca.sequence_of_events.map((step, index) => <li key={index}>{step}</li>)}</ol> :
              observedSteps.length ? <ol className="iq-timeline">{observedSteps.map(step => <li key={step.id}><strong>{step.title}</strong>{step.detail && <span>{step.detail}</span>}<small>{formatDate(step.timestamp)}</small></li>)}</ol> :
                <p className="iq-muted">No ordered request events were captured.</p>}
          </section>

          <section><h3>Evidence</h3><TextList items={rca.evidence} /></section>
          <section><h3>Contributing factors</h3><TextList items={rca.contributing_factors} /></section>
          <section className="iq-recommendation"><h3>Recommended action</h3><p>{rca.recommended_action || 'No action recommended.'}</p></section>

          <section className="iq-fix-action">
            <div>
              <h3>Prepare a code fix</h3>
              <p>Search the related application code, locate the failure, and prepare a reviewable fix branch.</p>
            </div>
            <button
              className="iq-fix-button"
              disabled={fixing || detail.fix_result?.status === 'created'}
              onClick={prepareFix}
            >
              {fixing ? 'Analyzing codeâ€¦' : detail.fix_result?.status === 'created' ? 'Fix ready' : 'Fix this incident'}
            </button>
          </section>

          {detail.fix_result && <section className={`iq-fix-result ${detail.fix_result.status}`}>
            <div className="iq-section-title">
              <h3>Code fix</h3>
              <span>{detail.fix_result.status}</span>
            </div>
            <p>{detail.fix_result.summary}</p>
            {detail.fix_result.status === 'failed' ? <div className="iq-error">{detail.fix_result.error || 'The code fix could not be prepared.'}</div> : <>
              <dl className="iq-fix-metadata">
                <div><dt>Branch</dt><dd>{detail.fix_result.branch_name || 'Not created'}</dd></div>
                <div><dt>Commit</dt><dd>{detail.fix_result.commit_sha?.slice(0, 12) || 'Not committed'}</dd></div>
                <div><dt>Location</dt><dd>{detail.fix_result.files_changed?.join(', ') || 'Not supplied'}</dd></div>
                <div><dt>Availability</dt><dd>{detail.fix_result.push_status === 'pushed' ? 'Remote branch' : 'Local branch'}</dd></div>
              </dl>
              {detail.fix_result.branch_url && <a className="iq-branch-link" href={detail.fix_result.branch_url} target="_blank" rel="noreferrer">Open fix branch</a>}
              <div className="iq-code-compare">
                <div><h4>Previous code</h4><pre>{detail.fix_result.before_code || 'Snapshot unavailable.'}</pre></div>
                <div><h4>Added fix</h4><pre>{detail.fix_result.after_code || 'Snapshot unavailable.'}</pre></div>
              </div>
              {detail.fix_result.diff && <details className="iq-diff"><summary>View unified diff</summary><pre>{detail.fix_result.diff}</pre></details>}
            </>}
          </section>}
        </>}

        <details className="iq-technical"><summary>Technical logs ({detail.context?.logs?.length || 0})</summary>
          {detail.context?.logs?.length ? detail.context.logs.map((log, index) => <div className="iq-log" key={index}><strong>{log.service || 'Application'} · {log.level || 'EVENT'}</strong><small>{formatDate(log.timestamp)}</small><p>{log.message}</p>
            {log.metadata?.path && <p><code>{log.metadata.method} {log.metadata.path}</code>{log.metadata.httpStatus && <strong> ? HTTP {log.metadata.httpStatus}</strong>}</p>}
            {log.metadata?.requestBody && <><h4>Request</h4><pre>{JSON.stringify(log.metadata.requestBody, null, 2)}</pre></>}
            {log.metadata?.responseBody && <><h4>Response</h4><pre>{JSON.stringify(log.metadata.responseBody, null, 2)}</pre></>}
            <small>log-{index}{log.metadata?.requestId && ` ? Request ${log.metadata.requestId}`}</small>
          </div>) : <p className="iq-muted">No logs recorded.</p>}
        </details>
        <p className="iq-disclaimer">AI-generated analysis. Verify the evidence before taking action.</p>
      </>}
    </article>}
    <p className="iq-disclaimer">New means you have not opened this incident in this browser.</p>
  </main>
}

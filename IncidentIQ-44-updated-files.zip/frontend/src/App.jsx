import { useEffect, useMemo, useRef, useState } from 'react'
import { AlertTriangle, ArrowLeft, ArrowRight, Ban, Barcode, Check, ChevronDown, ChevronRight, CircleHelp, CreditCard, Delete, Eye, EyeOff, Keyboard, Leaf, LockKeyhole, LogOut, Minus, MoreHorizontal, Milk, CupSoda, Package, Plus, ReceiptText, Search, Settings, Ticket, ShoppingCart, Tag, Trash2, UserRound, UsersRound, Wheat, X } from 'lucide-react'
import { api } from './api/client'
import { demoErrorProducts, demoErrors } from './demoErrors'
import { logDisplayedError, logEvent, setLogContext } from './telemetry'

const money = cents => '$' + ((cents || 0) / 100).toFixed(2)

function readStored(key, fallback) {
  try { return JSON.parse(sessionStorage.getItem(key)) ?? fallback } catch { return fallback }
}
const producePhotos = new Set(['p1', 'p2', 'p6', 'p7', 'p13', 'p14', 'p15'])
function ProductVisual({ product }) {
  const [failed, setFailed] = useState(false)
  return <span className="product-photo">{producePhotos.has(product.id) && !failed ? <img src={'/products/' + product.id + '.jpg'} alt={product.name} loading="lazy" onError={() => setFailed(true)} /> : <Package size={42} strokeWidth={1.3} />}</span>
}

function Logo({ small = false }) {
  return <div className={'pos-logo' + (small ? ' logo-small' : '')}>KEELE</div>
}

function ErrorDialog({ message, onCancel, onClear, clearLabel = 'Clear entry' }) {
  useEffect(() => { if (message) logDisplayedError(message) }, [message])
  if (!message) return null
  return <div className="dialog-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onCancel() }}><section className="error-dialog" role="alertdialog" aria-modal="true" aria-labelledby="error-title"><button className="dialog-close" onClick={onCancel} aria-label="Close error"><X size={18} /></button><div className="dialog-icon"><AlertTriangle size={26} /></div><h2 id="error-title">Something needs attention</h2><p>{message}</p><div className="dialog-actions"><button className="dialog-cancel" onClick={onCancel}>Cancel</button><button className="dialog-clear" onClick={onClear}>{clearLabel}</button></div></section></div>
}

function StatusBar({ cashier }) {
  const [now, setNow] = useState(new Date())
  useEffect(() => { const timer = setInterval(() => setNow(new Date()), 30000); return () => clearInterval(timer) }, [])
  return <footer className="status-bar"><div><CircleHelp size={25} /><span>{cashier ? 'Need help? Contact support' : 'Help'}</span></div><strong>Lane 59</strong><div>{cashier && <span className="online-status"><i /> Online</span>}<span>{!cashier && now.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' })}</span><Logo small /></div></footer>
}

function RegisterHeader({ cashier, search, onSearch, onOperator }) {
  const now = new Date()
  return <header className="register-header"><Logo small /><div className="register-meta"><strong>Lane 59</strong><span /><strong>{cashier.role}</strong></div><div className="header-search"><Search size={19} /><input value={search} onChange={event => onSearch(event.target.value)} placeholder="Search item / PLU / Keyword..." aria-label="Search catalog" /></div><nav><button><CircleHelp size={19} /> Help</button><button onClick={onOperator}><Settings size={19} /> Settings</button><button className="header-user" onClick={onOperator}><span><UserRound size={19} /></span>{cashier.role === 'Signed out' ? 'Sign in' : cashier.name.split(' ')[0]}<ChevronDown size={15} /></button><div className="header-date">{now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}<b>{now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</b></div></nav></header>
}

function Keypad({ label, value, onDigit, onBackspace, onClear, onEnter, onKeyboard, disabled = false, lookup = false, onChange, inputRef, children }) {
  return <aside className={'keypad-panel' + (lookup ? ' lookup-panel' : '')}>{lookup ? <div className="lookup-heading"><h2>PLU / Item Lookup</h2><button onClick={onKeyboard}><Barcode size={20} /> Scan</button></div> : <div className="keypad-label">{label}</div>}{lookup ? <label className="plu-field"><span>PLU</span><input ref={inputRef} aria-label="PLU" inputMode="numeric" autoComplete="off" placeholder="Enter PLU number" value={value} onChange={event => onChange(event.target.value.replace(/\D/g, '').slice(0, 12))} onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); onEnter() } }} /></label> : <div className="keypad-display">{value || <span>{label}</span>}</div>}<div className="key-grid">
    {['7', '8', '9', '4', '5', '6', '1', '2', '3'].map(key => <button key={key} onClick={() => onDigit(key)} disabled={disabled}>{key}</button>)}
    <button aria-label="Backspace" onClick={onBackspace} disabled={disabled}><Delete size={27} fill="currentColor" /></button><button onClick={() => onDigit('0')} disabled={disabled}>0</button><button aria-label="Use keyboard" onClick={onKeyboard} disabled={disabled}><Keyboard size={27} /></button>
    <button className="key-clear" onClick={onClear} disabled={disabled}>CLEAR</button><button onClick={() => onDigit('.')} disabled={disabled}>.</button><button className="key-enter" onClick={onEnter} disabled={disabled}>ENTER</button>
  </div>{children}</aside>
}

function Login({ onLogin }) {
  const [username, setUsername] = useState('cashier')
  const [password, setPassword] = useState('')
  const [active, setActive] = useState('password')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const usernameRef = useRef(null)
  const passwordRef = useRef(null)
  const activeValue = active === 'username' ? username : password
  const setActiveValue = active === 'username' ? setUsername : setPassword
  async function submit(event) {
    event?.preventDefault()
    if (!username || !password) { setError('Enter Partner ID and password.'); return }
    setBusy(true); setError(''); logEvent('LOGIN_ATTEMPT', { partnerId: username }, 'STARTED')
    try { onLogin(await api('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) })) }
    catch (err) { logEvent('LOGIN_FAILED', { partnerId: username, ...err.telemetry, message: err.message }, 'ERROR'); setError(err.message) }
    finally { setBusy(false) }
  }
  return <div className="pos-screen login-screen"><div className="login-body"><main className="login-photo"><form className="login-card" onSubmit={submit}><Logo /><h1>Welcome back</h1><p className="login-subtitle">Sign in to open your register</p><div className="login-fields"><label><span>Partner ID</span><div className="credential-field"><UserRound size={18} /><input ref={usernameRef} value={username} onFocus={() => setActive('username')} onChange={e => setUsername(e.target.value)} autoComplete="username" /></div></label><label><span>Password</span><div className="credential-field"><LockKeyhole size={18} /><input ref={passwordRef} value={password} onFocus={() => setActive('password')} onChange={e => setPassword(e.target.value)} type={showPassword ? 'text' : 'password'} autoComplete="current-password" /><button type="button" onClick={() => setShowPassword(value => !value)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></label></div><button className="login-primary" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}<ArrowRight size={19} /></button><div className="login-divider"><span>Use your Partner ID and password to continue</span></div><div className="people-message"><UsersRound size={22} /><span>GREAT FOOD POWERS GREAT PEOPLE™</span></div></form></main><Keypad label="PARTNER ID" value={active === 'username' ? username : '•'.repeat(password.length)} onDigit={digit => setActiveValue(activeValue + digit)} onBackspace={() => setActiveValue(activeValue.slice(0, -1))} onClear={() => setActiveValue('')} onEnter={submit} onKeyboard={() => (active === 'username' ? usernameRef : passwordRef).current?.focus()} /></div><StatusBar /><ErrorDialog message={error} onCancel={() => setError('')} onClear={() => { setError(''); setPassword(''); setActive('password'); passwordRef.current?.focus() }} clearLabel="Clear password" /></div>
}

function OrderPanel({ rows, subtotal, tax, number, onChange, onCheckout, onClear, busy }) {
  const count = rows.reduce((total, row) => total + row.quantity, 0)
  return <section className="order-panel"><div className="order-heading"><strong>{number ? 'Order #' + number : 'New order'}</strong><span>{number ? 'IN PROGRESS' : 'READY'}</span><button onClick={onClear} disabled={!rows.length} aria-label="Clear order"><Trash2 size={18} /></button></div><div className="order-list">{rows.length ? rows.map(({ item, quantity }, index) => <div className="order-row" key={item.id}><span>{index + 1}</span><div className="order-item-name"><strong>{item.name}</strong><small>PLU {item.plu} · {money(item.price_cents)} / {item.unit}</small></div><div className="order-qty"><button aria-label={'Remove one ' + item.name} onClick={() => onChange(item.id, quantity - 1)}><Minus size={13} /></button><span>{quantity}</span><button aria-label={'Add one ' + item.name} onClick={() => onChange(item.id, quantity + 1)}><Plus size={13} /></button></div><b>{money(item.price_cents * quantity)}</b></div>) : <div className="order-empty"><ShoppingCart size={66} /><strong>No items added yet</strong><small>Scan an item, enter a PLU or<br />select a speed key to get started.</small></div>}</div><div className="order-bottom"><div className="order-subtotal"><span>Items ({count})</span><strong>{money(subtotal)}</strong></div><div className="current-total"><strong>Total</strong><b>{money(subtotal + tax)}</b></div></div></section>
}

function PaymentOrder({ quote, receipt, number, onBack }) {
  const data = receipt || quote
  return <section className="order-panel checkout-order"><div className="order-heading"><strong>Order #{number}</strong>{receipt && <span>PAID</span>}</div><div className="payment-order-main"><div className="order-totals"><div><span>Subtotal</span><span>{money(data.subtotal_cents)}</span></div><div><span>Taxes</span><span>{money(data.tax_cents)}</span></div><div className="order-grand"><strong>Order Total</strong><strong>{money(data.total_cents)}</strong></div></div><div className="payment-summary"><h3>Payment Summary</h3><div className="summary-head"><span>Method</span><span>Tendered</span><span>Applied</span></div>{!receipt && <div className="payment-empty"><ReceiptText size={36} /><p>No payments applied yet.</p></div>}{receipt && <div className="summary-line"><span>{receipt.method === 'card' ? 'Electronic' : 'Cash'}</span><span>{money(receipt.amount_tendered_cents)}</span><span>{money(receipt.total_cents)}</span></div>}</div></div><div className="payment-order-bottom"><div className="amount-paid"><span>Amount Paid</span><span>{money(receipt ? receipt.total_cents : 0)}</span></div><div className="balance-due"><strong>{receipt ? 'Change Due' : 'Balance Due'}</strong><b>{money(receipt ? receipt.change_cents : quote.total_cents)}</b></div>{receipt && <div className="next-order-note"><Check size={18} /><span>Payment complete. Select the next item to start a new order.</span></div>}</div></section>
}

function SuspendOrderForm({ currentOrderNumber, onSuspend, busy }) {
  const [orderNumber, setOrderNumber] = useState(currentOrderNumber ? String(currentOrderNumber) : '')
  useEffect(() => {
    if (currentOrderNumber) setOrderNumber(String(currentOrderNumber))
  }, [currentOrderNumber])
  function submit(event) {
    event.preventDefault()
    if (orderNumber) onSuspend(orderNumber)
  }
  return <form className="suspend-order-form" onSubmit={submit}>
    <label htmlFor="suspend-order-number">Order number</label>
    <div><input id="suspend-order-number" inputMode="numeric" value={orderNumber} onChange={event => setOrderNumber(event.target.value.replace(/\D/g, '').slice(0, 12))} placeholder="Enter order number" aria-label="Order number to suspend" /><button className="suspend-button" type="submit" disabled={!orderNumber || busy}><Ban size={18} />{busy ? 'Suspending…' : 'Suspend order'}</button></div>
    <small>Use this to close a retained order even when it belongs to another session.</small>
  </form>
}

function SaleCenter({ products, onAdd, cashier, onLogout, onSuspend, currentOrderNumber, busy, view, setView, search }) {
  const [category, setCategory] = useState('Produce')
  const categoryItems = [
    { key: 'Produce', label: 'Produce', icon: <Leaf size={36} /> },
    { key: 'Bakery', label: 'Bakery', icon: <Wheat size={34} /> },
    { key: 'Dairy', label: 'Dairy', icon: <Milk size={22} /> },
    { key: 'Drinks', label: 'Beverages', icon: <CupSoda size={22} /> },
    { key: 'Snacks', label: 'Snacks', icon: <Package size={22} /> },
    { key: 'All Items', label: 'More', icon: <MoreHorizontal size={36} /> },
  ]
  const visible = products.filter(product => (search || category === 'All Items' || product.category === category) && (product.name + ' ' + product.plu).toLowerCase().includes(search.toLowerCase()))
  return <section className="center-panel quick-add-panel"><div className="center-heading"><div><h2>{view === 'operator' ? 'Operator Menu' : 'Item catalog'}</h2><p>{view === 'operator' ? 'Manage the active register session' : 'Select an item or enter its PLU to add it to the order'}</p></div>{view === 'operator' && <button onClick={() => setView('speed')}>Back to catalog <ArrowRight size={15} /></button>}</div><div className="center-content">{view === 'operator' ? <div className="operator-menu"><div className="operator-avatar"><UserRound size={30} /></div><div><span>Signed in as</span><h2>{cashier.name}</h2><p>{cashier.role} · Lane 59</p></div><SuspendOrderForm currentOrderNumber={currentOrderNumber} onSuspend={onSuspend} busy={busy} /><button onClick={onLogout}><LogOut size={18} /> Log off register</button></div> : <><div className="catalog-categories">{categoryItems.map(item => <button key={item.key} className={category === item.key ? 'selected' : ''} onClick={() => { logEvent('CATEGORY_SELECTED', { category: item.key }); setCategory(item.key); setView('speed') }}><span className="category-art">{item.icon}</span><strong>{item.label}</strong></button>)}</div><div className="speed-grid">{visible.map(product => <button className="speed-tile" key={product.id} onClick={() => onAdd(product)}><ProductVisual product={product} /><span className="product-code">PLU {product.plu}</span><span className="speed-name">{product.name}</span><small>{money(product.price_cents)}{' / ' + product.unit}</small></button>)}</div>{!visible.length && <div className="no-results">No items found for “{search}”</div>}</>}</div></section>
}

function PaymentCenter({ quote, onPay, busy, tendered, onTendered, onCashMode, cashMode, onError }) {
  const cents = Math.round(Number(tendered) * 100)
  const validCash = tendered !== '' && Number.isFinite(cents) && cents >= quote.total_cents
  const methods = [
    { name: 'Electronic Payment', description: 'Credit / Debit / NFC', icon: <CreditCard />, color: 'electronic', action: () => { logEvent('PAYMENT_METHOD_SELECTED', { method: 'card', displayName: 'Electronic Payment' }); onPay('card') } },
    { name: 'Cash', description: 'Physical Cash', icon: <span>$</span>, color: 'cash', action: () => { logEvent('PAYMENT_METHOD_SELECTED', { method: 'cash', displayName: 'Cash' }); onCashMode(true) } },
    { name: 'Coupon', description: 'Scan or enter coupon', icon: <Ticket />, color: 'coupon', action: () => { logEvent('PAYMENT_METHOD_UNAVAILABLE', { method: 'coupon', displayName: 'Coupon' }, 'BLOCKED'); onError('Coupons are not available in this demo. Choose cash or electronic payment.') } },
    { name: 'Other Media', description: 'Gift Card / Store Credit / etc.', icon: <MoreHorizontal />, color: 'other', action: () => { logEvent('PAYMENT_METHOD_UNAVAILABLE', { method: 'other', displayName: 'Other Media' }, 'BLOCKED'); onError('Gift cards and store credit are not available in this demo. Choose cash or electronic payment.') } },
    { name: 'Media Void', description: 'Void a payment', icon: <Ban />, color: 'void', action: () => { logEvent('PAYMENT_METHOD_UNAVAILABLE', { method: 'void', displayName: 'Media Void' }, 'BLOCKED'); onError('There are no applied payments to void.') } },
  ]
  return <section className="center-panel checkout-media">
    <div className="checkout-media-heading"><h2>{cashMode ? 'Cash Payment' : 'Media Selection'}</h2><p>{cashMode ? 'Enter the cash received to continue.' : 'Select a payment method to continue.'}</p></div>
    <div className="checkout-media-content">
      {cashMode ? <div className="cash-workflow">
        <div className="cash-line"><span>Balance Due</span><strong>{money(quote.total_cents)}</strong></div>
        <div className="cash-line"><span>Cash Tendered</span><strong>{money(cents)}</strong></div>
        <div className="quick-amounts">{[quote.total_cents, 2000, 5000, 10000].filter((amount, index, all) => amount >= quote.total_cents && all.indexOf(amount) === index).map(amount => <button disabled={busy} key={amount} onClick={() => onTendered((amount / 100).toFixed(2), 'quick-amount')}>{amount === quote.total_cents ? 'Exact Amount' : money(amount)}</button>)}</div>
        <div className="cash-change"><span>{validCash ? 'Change Due' : 'Still Due'}</span><strong>{money(Math.abs(cents - quote.total_cents))}</strong></div>
        <button className="complete-cash" disabled={!validCash || busy} onClick={() => onPay('cash', cents)}>{busy ? 'Processing…' : 'Complete Cash Payment'}</button>
        <button className="method-back" disabled={busy} onClick={() => onCashMode(false)}>Choose another payment method</button>
      </div> : <div className="payment-cards">{methods.map(method => <button key={method.name} className={'payment-card payment-' + method.color} onClick={method.action} disabled={busy}>
        <span className="payment-card-icon">{method.icon}</span><span className="payment-card-copy"><strong>{method.name}</strong><small>{method.description}</small></span><ChevronRight className="payment-chevron" size={21} />
      </button>)}</div>}
    </div>
  </section>
}

function AmountKeypad({ value, onChange, onEnter, disabled, children }) {
  const inputRef = useRef(null)
  function update(next, inputMethod) { if (/^\d{0,7}(\.\d{0,2})?$/.test(next)) onChange(next, inputMethod) }
  return <aside className="keypad-panel amount-panel">
    <h2>Amount</h2><input ref={inputRef} className="amount-display" aria-label="Cash amount" inputMode="decimal" value={value} placeholder="0.00" disabled={disabled} onChange={event => update(event.target.value, 'keyboard')} onKeyDown={event => { if (event.key === 'Enter') onEnter() }} />
    <div className="amount-digits">{['7', '8', '9', '4', '5', '6', '1', '2', '3'].map(key => <button key={key} disabled={disabled} onClick={() => update(value + key, 'keypad')}>{key}</button>)}
      <button aria-label="Backspace amount" disabled={disabled} onClick={() => update(value.slice(0, -1), 'backspace')}><Delete size={28} /></button><button disabled={disabled} onClick={() => update(value + '0', 'keypad')}>0</button><button disabled={disabled} aria-label="Type amount with keyboard" onClick={() => inputRef.current?.focus()}><Keyboard size={28} /></button>
    </div><div className="amount-actions"><button className="amount-clear" disabled={disabled} onClick={() => onChange('', 'clear')}>CLEAR</button><button className="amount-enter" disabled={disabled} onClick={onEnter}>ENTER</button></div>{children}
  </aside>
}

function App() {
  const [session, setSession] = useState(() => { try { return JSON.parse(sessionStorage.getItem('keele-session')) } catch { return null } })
  const [products, setProducts] = useState(() => readStored('keele-products', []))
  const [draft] = useState(() => readStored('keele-register', {}))
  const [showLogin, setShowLogin] = useState(() => !readStored('keele-session', null))
  const [cart, setCart] = useState(draft.cart || {})
  const [stage, setStage] = useState('sale')
  const [quote, setQuote] = useState(draft.quote || null)
  const [receipt, setReceipt] = useState(draft.receipt || null)
  const [number, setNumber] = useState(draft.orderVersion === 2 && !draft.receipt ? draft.number : null)
  const [plu, setPlu] = useState('')
  const [tendered, setTendered] = useState('')
  const [cashMode, setCashMode] = useState(false)
  const [catalogView, setCatalogView] = useState('speed')
  const [catalogSearch, setCatalogSearch] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [toast, setToast] = useState('')
  const pluRef = useRef(null)
  const reservation = useRef(null)
  const requestKey = useRef(draft.orderVersion === 2 && draft.requestKey ? draft.requestKey : crypto.randomUUID())
  const token = session?.access_token
  const cashier = session?.cashier || { name: 'Sign in', role: 'Signed out' }
  const screen = showLogin ? 'LOGIN' : stage === 'checkout' ? (cashMode ? 'CASH_PAYMENT' : 'CHECKOUT') : catalogView === 'operator' ? 'OPERATOR_MENU' : 'ITEM_CATALOG'
  setLogContext({ screen, orderNumber: number, orderFlowId: requestKey.current, cashier: session?.cashier || null, authenticated: !!token })
  useEffect(() => { logEvent('SCREEN_VIEW', { screen }) }, [screen])
  useEffect(() => { const timer = setTimeout(() => { if (catalogSearch) logEvent('CATALOG_SEARCH', { query: catalogSearch }) }, 500); return () => clearTimeout(timer) }, [catalogSearch])
  useEffect(() => { sessionStorage.setItem('keele-register', JSON.stringify({ cart, quote, receipt, number, requestKey: requestKey.current, orderVersion: 2 })) }, [cart, quote, receipt, number])
  useEffect(() => { if (!token) return; api('/products', { token }).then(data => { logEvent('CATALOG_LOADED', { productCount: data.length }); setProducts(data); sessionStorage.setItem('keele-products', JSON.stringify(data)) }).catch(err => { logEvent('CATALOG_LOAD_FAILED', { ...err.telemetry, message: err.message }, 'ERROR'); setError(err.message); if (err.message.includes('sign in')) { sessionStorage.removeItem('keele-session'); setSession(null) } }) }, [token])
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(''), 3000); return () => clearTimeout(timer) }, [toast])
  const rows = useMemo(() => Object.entries(cart).map(([id, quantity]) => ({ item: products.find(product => product.id === id), quantity })).filter(row => row.item), [cart, products])
  const subtotal = rows.reduce((total, row) => total + row.item.price_cents * row.quantity, 0)
  const tax = Math.round(subtotal * .08)
  const lines = rows.map(row => ({ product_id: row.item.id, quantity: row.quantity }))
  function login(data) { logEvent('LOGIN_SUCCESS', { cashier: data.cashier }); sessionStorage.setItem('keele-session', JSON.stringify(data)); setSession(data); setShowLogin(false); setStage('sale'); setCatalogView('speed'); setError('') }
  async function logout() {
    if ((!receipt && (number || Object.keys(cart).length)) || busy) { logEvent('LOGOUT_BLOCKED', { reason: 'Active order' }, 'BLOCKED'); setError('Complete or suspend the active order before logging off.'); return }
    try {
      if (token) await api('/auth/logout', { token, method: 'POST' })
      logEvent('LOGOUT_SUCCESS'); sessionStorage.removeItem('keele-session'); setSession(null); setShowLogin(true); setStage('sale'); setCatalogView('speed'); setError(''); setToast('')
    } catch (err) { logEvent('LOGOUT_FAILED', { ...err.telemetry, message: err.message }, 'ERROR'); setError(err.message) }
  }
  async function suspendOrder(value) {
    const orderToSuspend = Number.parseInt(String(value || number), 10)
    if (!Number.isSafeInteger(orderToSuspend) || orderToSuspend <= 0 || busy) {
      setError('Enter a valid order number to suspend.')
      return
    }
    setBusy(true); setError('')
    logEvent('SUSPEND_ORDER_STARTED', { orderNumber: orderToSuspend, recovery: true }, 'STARTED')
    try {
      await api(`/orders/${orderToSuspend}/force-suspend`, { token, method: 'POST' })
      logEvent('SUSPEND_ORDER_SUCCESS', { orderNumber: orderToSuspend, recovery: true })
      if (String(number) === String(orderToSuspend)) {
        reservation.current = null
        requestKey.current = crypto.randomUUID()
        setCart({}); setQuote(null); setReceipt(null); setNumber(null); setTendered(''); setCashMode(false); setStage('sale')
        setLogContext({ orderNumber: null })
      }
      setCatalogView('speed'); setToast(`Order #${orderToSuspend} suspended. You can start a new order.`)
    } catch (err) { logEvent('SUSPEND_ORDER_FAILED', { orderNumber: orderToSuspend, ...err.telemetry, message: err.message }, 'ERROR'); setError(err.message) }
    finally { setBusy(false) }
  }
  async function ensureOrder() {
    if (number && !receipt) return number
    if (!reservation.current) reservation.current = api('/orders', { token, method: 'POST', body: JSON.stringify({ request_key: requestKey.current }) }).then(result => { setNumber(result.order_number); setLogContext({ orderNumber: result.order_number }); logEvent('ORDER_STARTED', { orderNumber: result.order_number }); return result.order_number }).catch(err => { reservation.current = null; throw err })
    return reservation.current
  }
  function requireLogin() { if (token) return true; setShowLogin(true); return false }
  function change(id, quantity) { if (!requireLogin()) return; logEvent(quantity <= 0 ? 'ITEM_REMOVED' : 'ITEM_QUANTITY_CHANGED', { productId: id, previousQuantity: cart[id] || 0, quantity: Math.min(quantity, 99) }); setCart(current => { const next = { ...current }; if (quantity <= 0) delete next[id]; else next[id] = Math.min(quantity, 99); return next }) }
  async function add(product) {
    if (!requireLogin() || busy) return false
    try {
      const orderNumber = await ensureOrder()
      const injectInvalidQuantity = demoErrors.invalidItemQuantity && product.id === demoErrorProducts.invalidItemQuantity
      const quantity = injectInvalidQuantity ? 'not-a-number' : 1
      await api(`/orders/${orderNumber}/items`, { token, method: 'POST', body: JSON.stringify({ product_id: product.id, quantity }) })
      logEvent('ITEM_ADDED', { orderNumber, productId: product.id, plu: product.plu, name: product.name, unitPriceCents: product.price_cents })
      setReceipt(null); setQuote(null); setTendered(''); setCashMode(false); setStage('sale')
      setCart(current => ({ ...current, [product.id]: Math.min((current[product.id] || 0) + 1, 99) }))
      return true
    } catch (err) { logEvent('ITEM_ADD_FAILED', { productId: product.id, name: product.name, ...err.telemetry, message: err.message }, 'ERROR'); setError(err.message); return false }
  }
  async function ringPlu() {
    logEvent('PLU_LOOKUP', { plu }, 'STARTED')
    if (!plu.trim()) { logEvent('PLU_LOOKUP_FAILED', { plu: '', message: 'Enter a PLU code before selecting Enter.' }, 'ERROR'); setError('Enter a PLU code before selecting Enter.'); return }
    try {
      const product = await api(`/products/plu/${encodeURIComponent(plu.trim())}`, { token })
      logEvent('PLU_LOOKUP_SUCCEEDED', { plu: plu.trim(), productId: product.id, name: product.name })
      if (await add(product)) { setPlu(''); setError('') }
    } catch (err) {
      logEvent('PLU_LOOKUP_FAILED', { plu: plu.trim(), ...err.telemetry, message: err.message }, 'ERROR')
      setError(err.message)
    }
  }
  async function checkout() {
    if (!requireLogin() || !lines.length) return
    setBusy(true); setError('')
    logEvent('CHECKOUT_STARTED', { lines, subtotalCents: subtotal, taxCents: tax }, 'STARTED')
    try {
      const orderNumber = await ensureOrder()
      const hasCheckoutTrigger = lines.some(line => line.product_id === demoErrorProducts.invalidCheckoutLines)
      const checkoutLines = demoErrors.invalidCheckoutLines && hasCheckoutTrigger ? JSON.stringify(lines) : lines
      const nextQuote = await api('/checkout/quote', { token, method: 'POST', body: JSON.stringify({ lines: checkoutLines }) })
      logEvent('CHECKOUT_READY', { orderNumber, subtotalCents: nextQuote.subtotal_cents, taxCents: nextQuote.tax_cents, totalCents: nextQuote.total_cents })
      setQuote(nextQuote); setCashMode(false); setStage('checkout')
    } catch (err) { logEvent('CHECKOUT_FAILED', { ...err.telemetry, message: err.message }, 'ERROR'); setError(err.message) }
    finally { setBusy(false) }
  }
  async function pay(method, amount_tendered_cents) {
    const flow = method === 'card' ? 'ELECTRONIC_PAYMENT' : 'CASH_PAYMENT'
    const details = { method, amountTenderedCents: amount_tendered_cents, totalCents: quote?.total_cents, orderNumber: number }
    logEvent('PAYMENT_STARTED', details, 'STARTED')
    logEvent(flow + '_STARTED', details, 'STARTED')
    setBusy(true); setError('')
    try {
      const hasCardTrigger = lines.some(line => line.product_id === demoErrorProducts.invalidCardAmount)
      const paymentAmount = method === 'card' && demoErrors.invalidCardAmount && hasCardTrigger ? String(quote.total_cents) : amount_tendered_cents
      const result = await api('/payments', { token, method: 'POST', body: JSON.stringify({ lines, method, amount_tendered_cents: paymentAmount, order_number: number }) })
      const completed = { ...details, orderNumber: result.order_number, changeCents: result.change_cents }
      logEvent(flow + '_COMPLETED', completed)
      logEvent('PAYMENT_COMPLETED', completed)
      logEvent('ORDER_COMPLETED', { orderNumber: result.order_number, receipt: result })
      setReceipt(result); setNumber(null); reservation.current = null; requestKey.current = crypto.randomUUID(); setCart({}); setQuote(null); setTendered(''); setCashMode(false); setPlu(''); setCatalogSearch(''); setCatalogView('speed'); setStage('sale'); setToast('Order #' + result.order_number + ' paid' + (result.method === 'cash' ? ' · Change ' + money(result.change_cents) : ''))
    } catch (err) {
      logEvent(flow + '_FAILED', { ...details, ...err.telemetry, message: err.message }, 'ERROR')
      logEvent('PAYMENT_FAILED', { ...details, ...err.telemetry, message: err.message }, 'ERROR')
      setError(err.message)
    } finally { setBusy(false) }
  }
  function updatePlu(value, inputMethod = 'keyboard') {
    const next = value.replace(/\D/g, '').slice(0, 12)
    setPlu(next)
    logEvent('PLU_ENTRY_CHANGED', { plu: next, inputMethod, length: next.length })
  }
  function updateTendered(value, inputMethod = 'keyboard') {
    setTendered(value)
    logEvent('CASH_TENDER_CHANGED', { value, amountTenderedCents: Math.round(Number(value || 0) * 100), inputMethod })
  }
  function digit(value) { if (stage !== 'checkout') { if (value !== '.') updatePlu(plu + value, 'keypad') } else if (stage === 'checkout' && cashMode) updateTendered(value === '.' ? (tendered.includes('.') ? tendered : (tendered || '0') + '.') : (tendered + value).slice(0, 12), 'keypad') }
  function backspace() { if (stage !== 'checkout') updatePlu(plu.slice(0, -1), 'backspace'); else updateTendered(tendered.slice(0, -1), 'backspace') }
  function clear() { if (stage !== 'checkout') { setPlu(''); logEvent('PLU_ENTRY_CLEARED') } else updateTendered('', 'clear') }
  function clearErrorEntry() { setError(''); if (stage !== 'checkout') setPlu(''); else if (stage === 'checkout') setTendered('') }
  if (showLogin) return <Login onLogin={login} />
  return <div className={"pos-screen register-screen" + (stage === "checkout" ? " checkout-screen" : "")}><RegisterHeader cashier={cashier} search={catalogSearch} onSearch={value => { setCatalogSearch(value); if (stage !== 'checkout') setCatalogView('speed') }} onOperator={() => { if (!session) setShowLogin(true); else if (stage !== 'checkout') setCatalogView('operator') }} /><div className="register-body">{stage === 'sale' ? <OrderPanel rows={rows} subtotal={subtotal} tax={tax} number={number} onChange={change} onCheckout={checkout} onClear={() => { if (requireLogin()) { logEvent('CART_CLEARED', { lines }); setCart({}) } }} busy={busy} /> : <PaymentOrder quote={quote} receipt={receipt} number={number} onBack={() => setStage('sale')} />}{stage !== 'checkout' ? <SaleCenter products={products} onAdd={add} cashier={cashier} onLogout={logout} onSuspend={suspendOrder} currentOrderNumber={number} busy={busy} view={catalogView} setView={setCatalogView} search={catalogSearch} /> : <PaymentCenter key={number} quote={quote} onPay={pay} busy={busy} tendered={tendered} onTendered={updateTendered} onCashMode={setCashMode} cashMode={cashMode} onError={setError} />}{stage === 'checkout' ? <AmountKeypad value={tendered} onChange={updateTendered} disabled={busy} onEnter={() => { if (!cashMode) { setError('Select Cash before completing a cash payment.'); return } const cents = Math.round(Number(tendered) * 100); if (!tendered || !Number.isFinite(cents) || cents < quote.total_cents) { setError('Enter enough cash to cover the balance due.'); return } pay('cash', cents) }}><button className="back-cart-button keypad-navigation" disabled={busy} onClick={() => setStage('sale')}><ArrowLeft size={20} /> Back to Cart</button></AmountKeypad> : <Keypad lookup={stage !== 'checkout'} label={stage === 'sale' ? 'PLU' : stage === 'checkout' ? 'AMOUNT' : 'COMPLETE'} value={stage !== 'checkout' ? plu : stage === 'checkout' && cashMode ? tendered : ''} onDigit={digit} onBackspace={backspace} onClear={clear} onEnter={stage !== 'checkout' ? ringPlu : () => { if (stage === 'checkout' && cashMode && tendered && Math.round(Number(tendered) * 100) >= quote.total_cents) pay('cash', Math.round(Number(tendered) * 100)) }} onKeyboard={() => pluRef.current?.focus()} inputRef={pluRef} onChange={value => updatePlu(value, 'keyboard')} disabled={busy}><button className="total-button keypad-navigation" disabled={!rows.length || busy || !!receipt} onClick={checkout}>{busy ? 'Calculating...' : 'Total'}<ArrowRight size={20} /></button></Keypad>}</div><StatusBar cashier={session ? cashier.name : 'Signed out'} />{toast && <div className="pos-toast" role="status"><Check size={16} />{toast}<button onClick={() => setToast('')} aria-label="Dismiss"><X size={15} /></button></div>}<ErrorDialog message={error} onCancel={() => setError('')} onClear={clearErrorEntry} /></div>
}

export default App

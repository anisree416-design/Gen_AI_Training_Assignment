import assert from 'node:assert/strict'
import test from 'node:test'

let flush
globalThis.window = { addEventListener() {} }
globalThis.document = { addEventListener() {} }
globalThis.sessionStorage = { getItem() { return null }, setItem() {} }
globalThis.setInterval = callback => { flush = callback; return 0 }
const { logEvent, logDisplayedError } = await import('../src/telemetry.js')
const { api } = await import('../src/api/client.js')

test('API, business error and displayed error keep the same request identity', async () => {
  let events
  let headers
  globalThis.fetch = async (path, options) => {
    if (path === '/api/telemetry') {
      events = JSON.parse(options.body).events
      return new Response('{}')
    }
    headers = options.headers
    return new Response(JSON.stringify({ detail: 'Invalid lines' }), { status: 422 })
  }
  try {
    await api('/checkout/quote', { method: 'POST', body: JSON.stringify({ lines: 'bad', password: 'private' }) })
    assert.fail('Request should fail')
  } catch (error) {
    logEvent('CHECKOUT_FAILED', { ...error.telemetry, message: error.message }, 'ERROR')
    logDisplayedError(error.message)
  }
  await flush()
  const failures = events.filter(event => event.status === 'ERROR')
  assert.equal(failures.length, 3)
  assert.deepEqual(new Set(failures.map(event => event.requestId)), new Set([headers['X-Request-ID']]))
  assert.equal(events[0].requestBody.password, '[REDACTED]')
  assert.equal(events[0].requestBody.lines, 'bad')
  assert.equal(failures[0].responseBody.detail, 'Invalid lines')
  assert.ok(headers['X-Session-ID'])
})

test('separate local failures get new identities and each dialog shares its origin', async () => {
  let events
  globalThis.fetch = async (_path, options) => {
    events = JSON.parse(options.body).events
    return new Response('{}')
  }
  for (let attempt = 0; attempt < 2; attempt++) {
    logEvent('PLU_LOOKUP_FAILED', { message: 'Enter a PLU code' }, 'ERROR')
    logDisplayedError('Enter a PLU code')
  }
  await flush()
  assert.equal(events.length, 4)
  assert.equal(events[0].flowId, events[1].flowId)
  assert.equal(events[2].flowId, events[3].flowId)
  assert.notEqual(events[0].flowId, events[2].flowId)
})

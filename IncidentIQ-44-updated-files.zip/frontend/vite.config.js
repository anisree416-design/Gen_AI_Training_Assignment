import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '..', 'INCIDENTIQ_API_PROXY_TARGET')
  return {
    plugins: [react()],
    // Keep one shared .env at the repository root for the frontend and backend.
    envDir: '..',
    server: {
      proxy: { '/api': env.INCIDENTIQ_API_PROXY_TARGET || 'http://127.0.0.1:8000' },
    },
  }
})

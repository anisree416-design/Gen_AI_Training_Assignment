# IncidentIQ

**Agentic Incident Analysis & RCA Platform** — UST Enterprise Capstone Program (team of 7, submission 30 Sep 2026).

IncidentIQ converts reactive incident handling into an agentic workflow: a Splunk poller picks up
new error events, retrieves the surrounding log window, retrieves similar chunks from an in-memory
error-documentation knowledge base (RAG), and produces an evidence-backed RCA — persisted
immediately so it's visible in the UI. A **FIX button is the human-approval gate**: clicking it
resumes the paused graph into an automated code-fix flow that reads the target file, asks the LLM
for a fix, and pushes a branch for review. Merge/deploy stays out of scope for this POC.

## End-to-End Flow

```
Splunk poll (REST Search API) → Intake (normalize error event)
  → Retrieval (Splunk log window) → RAG (top-K error-doc chunks)
  → RCA (evidence + confidence, persisted to DB)
  → Human Approval / FIX button (interrupt)
  → Code Fix (read file → LLM fix → branch/commit/push)
```

## Tech Stack

| Layer | Choice |
|---|---|
| Orchestration | LangGraph (Python) + SQLite checkpointer |
| Backend | FastAPI + Uvicorn |
| Frontend | React + Vite + Tailwind |
| LLM | OpenAI-compatible API (Codex key), tenacity retries, Pydantic-validated output |
| Vector store | ChromaDB (in-memory, rebuilt from `data/knowledge/error_docs.txt` on every startup) |
| Log source | Splunk — Keele POS app writes via HEC, IncidentIQ reads via the REST Search API (polled on an interval, no Slack layer) |
| Code fix | GitPython (branch/commit/push to a sample-app fix target in `data/sample_app/`) |
| Observability | structlog + metrics endpoint |

## Repository Structure

```
backend/
  pyproject.toml            # backend dependencies (installed with pip)
  app/
    config.py                # pydantic-settings (env-driven, see .env.example)
    api/routes/             # FastAPI endpoints: incidents, fix/approve, metrics (not yet built)
    graph/                  # LangGraph state, builder, checkpointer
      nodes/                # intake, retrieval, rag, rca, approval, code_fix
    tools/                  # splunk_query (REST Search API), github_tool (branch/commit/push)
    rag/                    # in-memory ChromaDB store + error_docs.txt ingestion
    db/                     # sqlite3 incident/RCA/fix persistence (repository.py)
    llm/                    # LLM client (OpenAI-compatible API), structured output + repair
      prompts/              # per-agent system prompts
    monitoring/             # structlog config, metrics
  scripts/                 # smoke_graph.py — end-to-end stub run (make graph-smoke)
  tests/
    unit/                   # state/config/tool unit tests
    integration/            # graph integration tests
data/
  knowledge/                # error_docs.txt — RAG source of truth (error/symptom/solution)
  sample_app/               # small synthetic buggy service — the code_fix tool's fix target
frontend/                   # React + Vite + Tailwind (scaffolded later)
docs/
  architecture/             # architecture diagrams and decisions
  demo/                     # demo script, scenarios, recording
  rubric/                   # capstone evaluation mapping
```

## Team Ownership

The workstreams below reflect the pivot to a Splunk → RAG-RCA → human-approved code-fix
pipeline (see `docs/architecture/graph-contract.md`); the team should re-discuss specific
member assignments, since this collapsed the original 11-node design's Slack/JIRA/
classification/pattern-intelligence workstreams into fewer nodes.

| Workstream | Primary areas |
|---|---|
| Orchestration & routing | `backend/app/graph/` |
| Splunk adapter | `backend/app/tools/splunk_query.py`, `graph/nodes/{intake,retrieval}` |
| RCA intelligence | `graph/nodes/rca`, `backend/app/llm/` |
| RAG + knowledge base | `backend/app/rag/`, `data/knowledge/` |
| Code-fix + approval | `graph/nodes/{approval,code_fix}`, `tools/github_tool.py`, `data/sample_app/` |
| API + UI, observability & QA | `backend/app/api/`, `frontend/`, `backend/app/monitoring/`, `backend/tests/` |

## Quickstart

The RCA dashboard is available at **http://localhost:5173/incidents**.
See [RCA dashboard setup and verification](docs/operations/rca-dashboard.md) for
the complete local flow, required Search/LLM credentials, and offline tests.

Prerequisites: Python 3.12 or newer, Node 20+ for the frontend, and GNU Make for the
convenience commands below. `uv` is not required.

```bash
make backend-setup    # create backend/.venv and install dependencies with pip
make backend-dev      # run uvicorn app.main:app --reload
make backend-test     # pytest
make backend-lint     # ruff check + format
make graph-smoke      # run the graph end-to-end (all 6 nodes, zero live LLM/Splunk/GitHub calls)
make graph-smoke ARGS="--decision reject"  # demo the rejected-approval path
```

The graph contract — state fields, node ownership, and the stub-replacement guide —
lives in [`docs/architecture/graph-contract.md`](docs/architecture/graph-contract.md).

## Documentation

The complete documentation index is available at [`docs/README.md`](docs/README.md):

- [System architecture](docs/architecture/system-overview.md)
- [LangGraph contract](docs/architecture/graph-contract.md)
- [RAG pipeline](docs/architecture/rag-pipeline.md)
- [API contract and error scenarios](docs/api/api-contract.md)
- [End-to-end test scenarios](docs/testing/end-to-end-scenarios.md)
- [Local development and Splunk runbook](docs/operations/local-runbook.md)
- [Splunk-to-RCA runtime implementation plan](plan.md)

Copy `.env.example` to the repository-root `.env` and fill in the required values before running.
Both Splunk HEC and Search API settings come from this one file.

### Keele POS demo (error source)

The Keele POS storefront lives in `backend/app/api/routes/pos.py` and `frontend/src/`. It's the
instrumented application IncidentIQ watches: both the POS backend and its React frontend forward
business/telemetry events to Splunk via HEC (`backend/app/telemetry.py`, `frontend/src/telemetry.js`)
— that's the same Splunk index IncidentIQ's poller later searches for new errors. It uses a
hardcoded cashier account and a seeded catalog; no external payment gateway or API key is needed.

```powershell
# Terminal 1, from backend/
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
.\.venv\Scripts\python.exe -m pip install pytest pytest-asyncio ruff
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000

# Terminal 2, from frontend/
npm ci
npm run dev
```

Open `http://localhost:5173` and sign in with **cashier / 1234**. Click products or type a PLU such as **4011** and press Enter. Review the cart, proceed to checkout, and select card or cash. Card approvals are simulated; cash checkout calculates change. The API computes the final subtotal and 8% demo tax from catalog prices, then returns a receipt. Sessions and receipts are kept in memory and reset when the backend restarts.

### Demo error switches

Six opt-in switches in the repository-root `.env` inject failures into the normal POS flow. Set one switch to `true`, restart both dev servers, and perform the listed action. Keep the other switches `false` when demonstrating one incident at a time.

| Switch | Layer | Action that triggers it |
|---|---|---|
| `VITE_DEMO_FE_INVALID_ITEM_QUANTITY` | Frontend | Add **Baby Spinach**; its request sends a string quantity and receives HTTP 422. |
| `VITE_DEMO_FE_INVALID_CHECKOUT_LINES` | Frontend | Include **Fresh Carrots** and select **Total**; `lines` is sent as a string and receives HTTP 422. |
| `VITE_DEMO_FE_INVALID_CARD_AMOUNT` | Frontend | Include **Free Range Eggs** and select **Electronic Payment**; the amount is sent as a string and receives HTTP 422. |
| `DEMO_BE_PLU_LOOKUP_ERROR` | Backend | Enter Sourdough Bread PLU **1072**; lookup returns HTTP 503. |
| `DEMO_BE_CHECKOUT_ERROR` | Backend | Include **Greek Yogurt** and select **Total**; pricing returns HTTP 500. |
| `DEMO_BE_CARD_PAYMENT_ERROR` | Backend | Include **Dark Chocolate** and select **Electronic Payment**; the gateway returns HTTP 502. |

The default value for every switch is `false`. Vite reads the shared root `.env` because `frontend/vite.config.js` sets `envDir`; FastAPI loads the same file through `app.demo_errors`. No error code needs to be moved between components or edited during a demo.

## Demo Scenarios

The Keele POS app above is the error source: a Splunk error (e.g. the `CO-500` checkout-service
crash seeded in `data/knowledge/error_docs.txt` / `data/sample_app/checkout_service.py`) is picked
up by IncidentIQ's poller, retrieved, matched against the error-doc knowledge base, and turned into
an evidence-backed RCA. Clicking **FIX** in the UI approves the human gate and triggers the
automated code-fix flow, producing a review-ready branch.

## References

- `IncidentIQ Project & Demo Plan` — business/demo structure
- `IncidentIQ Technical Implementation Plan` — engineering decisions
- `UST Enterprise Capstone Program` — evaluation rubric (100 marks)

### Order numbering

The backend stores sequential order numbers and completed demo receipts in `backend/orders.sqlite` (created automatically). New numbers are allocated when the first item is added. SQLite transactions prevent duplicate numbers across concurrent sessions; request keys make allocation retries safe. The same number is used by the cart and receipt. Keep this database when restarting or redeploying to preserve the sequence. Set `POS_ORDER_DB` to use another persistent SQLite file.

An active order must be paid before logging off. The Total button below the PLU keypad opens checkout; Back to Cart below the amount keypad returns to the same order.

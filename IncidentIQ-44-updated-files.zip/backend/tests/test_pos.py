from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def signed_in_headers():
    response = client.post("/api/auth/login", json={"username": "cashier", "password": "1234"})
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def test_login_and_protected_catalog():
    assert client.get("/api/products").status_code == 401
    assert (
        client.post(
            "/api/auth/login", json={"username": "cashier", "password": "wrong"}
        ).status_code
        == 401
    )
    products = client.get("/api/products", headers=signed_in_headers())
    assert products.status_code == 200
    assert any(product["plu"] == "4011" for product in products.json())


def test_server_calculates_tax_and_cash_change():
    headers = signed_in_headers()
    lines = [{"product_id": "p1", "quantity": 2}]
    quote = client.post("/api/checkout/quote", json={"lines": lines}, headers=headers)
    assert quote.json()["subtotal_cents"] == 498
    assert quote.json()["tax_cents"] == 40
    assert quote.json()["total_cents"] == 538

    short = client.post(
        "/api/payments",
        json={"lines": lines, "method": "cash", "amount_tendered_cents": 500},
        headers=headers,
    )
    assert short.status_code == 400

    payment = client.post(
        "/api/payments",
        json={"lines": lines, "method": "cash", "amount_tendered_cents": 1000},
        headers=headers,
    )
    assert payment.status_code == 200
    assert payment.json()["change_cents"] == 462
    assert payment.json()["status"] == "paid"


def test_card_payment_and_invalid_product():
    headers = signed_in_headers()
    bad = client.post(
        "/api/checkout/quote",
        json={"lines": [{"product_id": "unknown", "quantity": 1}]},
        headers=headers,
    )
    assert bad.status_code == 400
    paid = client.post(
        "/api/payments",
        json={"lines": [{"product_id": "p2", "quantity": 1}], "method": "card"},
        headers=headers,
    )
    assert paid.status_code == 200
    assert paid.json()["method"] == "card"
    assert paid.json()["amount_tendered_cents"] == paid.json()["total_cents"]


def test_frontend_demo_payload_types_are_rejected():
    headers = signed_in_headers()
    order_number = client.post(
        "/api/orders", json={"request_key": "invalid-payloads"}, headers=headers
    ).json()["order_number"]

    invalid_item = client.post(
        f"/api/orders/{order_number}/items",
        json={"product_id": "p1", "quantity": "not-a-number"},
        headers=headers,
    )
    assert invalid_item.status_code == 422

    invalid_checkout = client.post(
        "/api/checkout/quote",
        json={"lines": '[{"product_id":"p1","quantity":1}]'},
        headers=headers,
    )
    assert invalid_checkout.status_code == 422

    invalid_card = client.post(
        "/api/payments",
        json={
            "lines": [{"product_id": "p1", "quantity": 1}],
            "method": "card",
            "amount_tendered_cents": "269",
            "order_number": order_number,
        },
        headers=headers,
    )
    assert invalid_card.status_code == 422


def test_force_suspend_recovers_an_order_from_another_session(tmp_path, monkeypatch):
    from app import order_store

    monkeypatch.setattr(order_store, "DB_PATH", tmp_path / "orders.sqlite")
    owner_headers = signed_in_headers()
    order_number = client.post(
        "/api/orders", json={"request_key": "stuck-order"}, headers=owner_headers
    ).json()["order_number"]

    # Recovery does not depend on the session that originally created the order.
    response = client.post(f"/api/orders/{order_number}/force-suspend")
    assert response.status_code == 200
    assert response.json()["status"] == "suspended"
    rejected = client.post(
        f"/api/orders/{order_number}/items",
        json={"product_id": "p1", "quantity": 1},
        headers=owner_headers,
    )
    assert rejected.status_code == 404
    assert "suspended" in rejected.json()["detail"].lower()


def test_backend_demo_error_switches(monkeypatch):
    from app.demo_errors import get_demo_errors

    headers = signed_in_headers()
    scenarios = [
        (
            "DEMO_BE_PLU_LOOKUP_ERROR",
            "/api/products/plu/1072",
            "/api/products/plu/4011",
            "get",
            None,
            None,
            503,
        ),
        (
            "DEMO_BE_CHECKOUT_ERROR",
            "/api/checkout/quote",
            "/api/checkout/quote",
            "post",
            {"lines": [{"product_id": "p10", "quantity": 1}]},
            {"lines": [{"product_id": "p1", "quantity": 1}]},
            500,
        ),
        (
            "DEMO_BE_CARD_PAYMENT_ERROR",
            "/api/payments",
            "/api/payments",
            "post",
            {"lines": [{"product_id": "p11", "quantity": 1}], "method": "card"},
            {"lines": [{"product_id": "p1", "quantity": 1}], "method": "card"},
            502,
        ),
    ]

    for flag, path, safe_path, method, payload, safe_payload, expected_status in scenarios:
        monkeypatch.setenv(flag, "true")
        get_demo_errors.cache_clear()
        response = (
            client.get(path, headers=headers)
            if method == "get"
            else client.post(path, json=payload, headers=headers)
        )
        assert response.status_code == expected_status
        assert response.json()["detail"].startswith("Demo error:")

        safe_response = (
            client.get(safe_path, headers=headers)
            if method == "get"
            else client.post(safe_path, json=safe_payload, headers=headers)
        )
        assert safe_response.status_code == 200
        monkeypatch.delenv(flag)
        get_demo_errors.cache_clear()


def test_persistent_sequential_numbers_and_logout_guard():
    headers = signed_in_headers()
    first = client.post("/api/orders", json={"request_key": "first"}, headers=headers).json()[
        "order_number"
    ]
    retry = client.post("/api/orders", json={"request_key": "first"}, headers=headers).json()[
        "order_number"
    ]
    assert retry == first
    assert client.post("/api/auth/logout", headers=headers).status_code == 409
    payload = {
        "lines": [{"product_id": "p1", "quantity": 1}],
        "method": "card",
        "order_number": first,
    }
    receipt = client.post("/api/payments", json=payload, headers=headers).json()
    assert receipt["order_number"] == first
    assert client.post("/api/payments", json=payload, headers=headers).json() == receipt
    assert client.post("/api/auth/logout", headers=headers).status_code == 200
    next_headers = signed_in_headers()
    second = client.post(
        "/api/orders", json={"request_key": "second"}, headers=next_headers
    ).json()["order_number"]
    assert second == first + 1


def test_concurrent_orders_are_unique_and_sequential():
    from concurrent.futures import ThreadPoolExecutor

    from app import order_store

    with ThreadPoolExecutor(max_workers=8) as pool:
        numbers = list(
            pool.map(lambda i: order_store.start_order(str(i), "test-session"), range(20))
        )
    assert sorted(numbers) == list(range(999048, 999068))
    assert order_store.start_order("next-after-reopen", "another-session") == 999068

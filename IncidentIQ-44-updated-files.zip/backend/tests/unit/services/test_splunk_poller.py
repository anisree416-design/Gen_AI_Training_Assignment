import asyncio
from dataclasses import dataclass, field
from datetime import UTC, datetime

import pytest

from app.db.repository import is_event_processed
from app.services.splunk_normalizer import normalize_splunk_error
from app.services.splunk_poller import poll_once, process_splunk_row, run_splunk_poller

ERROR_ROW = {
    "_cd": "bucket:123",
    "_time": "2026-09-25T10:30:00Z",
    "system": "incidentiq_backend",
    "eventType": "BACKEND_API_RESPONSE",
    "level": "ERROR",
    "message": "Checkout failed",
    "txn_id": "999048",
    "error_code": "CO-500",
}


@dataclass
class Snapshot:
    next: tuple[str, ...] = ()
    values: dict = field(default_factory=dict)


class FakeGraph:
    def __init__(self, *, fail: bool = False):
        self.fail = fail
        self.invocations = []
        self.snapshots = {}

    def invoke(self, value, config):
        if self.fail:
            raise RuntimeError("graph failed")
        self.invocations.append((value, config))
        thread_id = config["configurable"]["thread_id"]
        self.snapshots[thread_id] = Snapshot(next=("approval",), values=value)
        return value

    def get_state(self, config):
        thread_id = config["configurable"]["thread_id"]
        return self.snapshots.get(thread_id, Snapshot())

    def update_state(self, config, values, as_node=None):
        thread_id = config["configurable"]["thread_id"]
        current = self.snapshots.get(thread_id, Snapshot())
        self.snapshots[thread_id] = Snapshot(
            next=("retrieval",), values={**current.values, **values}
        )


class FakeSplunkClient:
    def __init__(self, rows=None, failures: int = 0):
        self.rows = rows or []
        self.failures = failures
        self.calls = 0

    def poll_new_errors(self, since):
        self.calls += 1
        if self.calls <= self.failures:
            raise RuntimeError("Splunk unavailable")
        return list(self.rows)

    def fetch_log_window(self, txn_id, system):
        return []


def test_processes_one_event_and_persistently_skips_duplicate(tmp_path):
    db_path = tmp_path / "incidents.sqlite3"
    graph = FakeGraph()

    incident_id = process_splunk_row(graph, ERROR_ROW, db_path)
    duplicate = process_splunk_row(graph, ERROR_ROW, db_path)

    assert incident_id and incident_id.startswith("INC-SPLUNK-")
    assert duplicate is None
    assert len(graph.invocations) == 1
    assert is_event_processed(normalize_splunk_error(ERROR_ROW).error_id, db_path)


def test_graph_failure_does_not_mark_event_processed(tmp_path):
    db_path = tmp_path / "incidents.sqlite3"
    graph = FakeGraph(fail=True)

    with pytest.raises(RuntimeError, match="graph failed"):
        process_splunk_row(graph, ERROR_ROW, db_path)

    assert not is_event_processed(normalize_splunk_error(ERROR_ROW).error_id, db_path)


def test_recovers_checkpoint_already_waiting_at_approval(tmp_path):
    db_path = tmp_path / "incidents.sqlite3"
    graph = FakeGraph()
    event = normalize_splunk_error(ERROR_ROW)
    incident_id = f"INC-{event.error_id}"
    graph.snapshots[incident_id] = Snapshot(next=("approval",), values={"incident_id": incident_id})

    assert process_splunk_row(graph, ERROR_ROW, db_path) == incident_id
    assert graph.invocations == []
    assert is_event_processed(event.error_id, db_path)


@pytest.mark.asyncio
async def test_poll_once_with_no_events_advances_cursor(tmp_path):
    before = datetime.now(UTC)

    result = await poll_once(
        FakeGraph(),
        FakeSplunkClient(),
        since=None,
        db_path=tmp_path / "incidents.sqlite3",
    )

    assert result is not None
    assert result >= before


@pytest.mark.asyncio
async def test_poll_once_processes_multiple_events(tmp_path):
    graph = FakeGraph()
    rows = [
        ERROR_ROW,
        {**ERROR_ROW, "_cd": "bucket:124", "message": "Payment failed"},
    ]

    await poll_once(
        graph,
        FakeSplunkClient(rows=rows),
        since=None,
        db_path=tmp_path / "incidents.sqlite3",
    )

    assert len(graph.invocations) == 2


@pytest.mark.asyncio
async def test_poll_once_groups_frontend_and_backend_errors_for_one_request(tmp_path):
    graph = FakeGraph()
    rows = [
        {**ERROR_ROW, "_cd": "bucket:request", "requestId": "request-44"},
        {
            **ERROR_ROW,
            "_cd": "bucket:browser",
            "system": "incidentiq_frontend",
            "eventType": "API_RESPONSE",
            "requestId": "request-44",
            "message": "Checkout failed in the browser",
        },
    ]

    await poll_once(
        graph,
        FakeSplunkClient(rows=rows),
        since=None,
        db_path=tmp_path / "incidents.sqlite3",
    )

    incident_ids = {call[1]["configurable"]["thread_id"] for call in graph.invocations}
    assert len(incident_ids) == 1


@pytest.mark.asyncio
async def test_poll_once_skips_malformed_rows_and_advances_cursor(tmp_path):
    before = datetime.now(UTC)
    result = await poll_once(
        FakeGraph(),
        FakeSplunkClient(rows=[{"level": "ERROR"}]),
        since=None,
        db_path=tmp_path / "incidents.sqlite3",
    )
    assert result is not None
    assert result >= before


@pytest.mark.asyncio
async def test_poll_once_keeps_cursor_when_processing_must_be_retried(tmp_path):
    since = datetime(2026, 9, 25, tzinfo=UTC)
    result = await poll_once(
        FakeGraph(fail=True),
        FakeSplunkClient(rows=[ERROR_ROW]),
        since=since,
        db_path=tmp_path / "incidents.sqlite3",
    )
    assert result == since


@pytest.mark.asyncio
async def test_poller_retries_search_failure_and_stops_cleanly(tmp_path):
    stop_event = asyncio.Event()
    client = FakeSplunkClient(failures=1)
    task = asyncio.create_task(
        run_splunk_poller(
            FakeGraph(),
            stop_event,
            client=client,
            interval_seconds=0.01,
            db_path=tmp_path / "incidents.sqlite3",
        )
    )

    for _ in range(50):
        if client.calls >= 2:
            break
        await asyncio.sleep(0.01)
    stop_event.set()
    await task

    assert client.calls >= 2


@pytest.mark.asyncio
async def test_poller_propagates_task_cancellation(tmp_path):
    task = asyncio.create_task(
        run_splunk_poller(
            FakeGraph(),
            asyncio.Event(),
            client=FakeSplunkClient(),
            interval_seconds=60,
            db_path=tmp_path / "incidents.sqlite3",
        )
    )

    await asyncio.sleep(0)
    task.cancel()

    with pytest.raises(asyncio.CancelledError):
        await task

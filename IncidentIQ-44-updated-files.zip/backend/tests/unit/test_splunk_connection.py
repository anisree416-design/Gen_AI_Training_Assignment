"""Local Enterprise and bearer authentication at the HTTP boundary."""

import asyncio
import base64
from urllib.parse import parse_qs

import httpx
import pytest

from app.api.routes import incidents
from app.config import Settings
from app.services import splunk_poller
from app.tools import splunk_query


@pytest.fixture
def local_settings(monkeypatch):
    settings = Settings(
        _env_file=None,
        splunk_search_url="https://localhost:8089",
        splunk_search_token="",
        splunk_search_username="local-user",
        splunk_search_password="local-password",
        splunk_verify_ssl=False,
        openai_api_key="test-key",
    )
    for module in (splunk_query, splunk_poller, incidents):
        monkeypatch.setattr(module, "get_settings", lambda: settings)
    return settings


def mock_http(monkeypatch, handler):
    real_client = httpx.Client
    options = []

    def factory(**kwargs):
        options.append(kwargs)
        return real_client(transport=httpx.MockTransport(handler), **kwargs)

    monkeypatch.setattr(splunk_query.httpx, "Client", factory)
    return options


@pytest.mark.parametrize("token", ["", "enterprise-token"])
def test_poll_and_log_window_authentication(local_settings, monkeypatch, token):
    local_settings.splunk_search_token = token
    requests = []
    row = {"_raw": "Checkout failed", "level": "ERROR"}

    def handler(request):
        requests.append(request)
        return httpx.Response(200, json={"results": [row]})

    options = mock_http(monkeypatch, handler)
    client = splunk_query.SplunkRestClient()
    assert client.poll_new_errors(None) == [row]
    assert client.fetch_log_window("order-42", "backend") == [row]
    expected = (
        f"Bearer {token}" if token else
        "Basic " + base64.b64encode(b"local-user:local-password").decode()
    )
    for request in requests:
        assert str(request.url) == "https://localhost:8089/services/search/jobs"
        assert request.headers["authorization"] == expected
        form = parse_qs(request.content.decode())
        assert form["exec_mode"] == ["oneshot"]
        assert form["output_mode"] == ["json"]
        assert "incidentiq" in form["search"][0]
    assert all(option["verify"] is False for option in options)


def test_authentication_failure_is_not_reported_as_empty_results(local_settings, monkeypatch):
    mock_http(monkeypatch, lambda request: httpx.Response(401))
    with pytest.raises(httpx.HTTPStatusError):
        splunk_query.SplunkRestClient().poll_new_errors(None)


@pytest.mark.parametrize("missing_field", ["splunk_search_username", "splunk_search_password"])
def test_incomplete_local_login_pauses_pipeline(local_settings, monkeypatch, missing_field):
    setattr(local_settings, missing_field, "")
    result = incidents.pipeline()
    assert len(result["missing_settings"]) == 1
    assert "SPLUNK_SEARCH_PASSWORD" in result["missing_settings"][0]
    assert "local-password" not in str(result)
    with pytest.raises(RuntimeError, match="username/password"):
        splunk_query.SplunkRestClient().poll_new_errors(None)


@pytest.mark.asyncio
async def test_local_login_starts_background_polling(local_settings, monkeypatch):
    stop = asyncio.Event()
    requests = []
    status = {}
    monkeypatch.setattr(splunk_poller, "pipeline_status", status)
    monkeypatch.setattr(incidents, "pipeline_status", status)

    def handler(request):
        requests.append(request)
        return httpx.Response(200, json={"results": []})

    mock_http(monkeypatch, handler)
    monkeypatch.setattr(
        splunk_poller, "get_splunk_client", lambda: splunk_query.SplunkRestClient()
    )
    original_poll = splunk_poller.poll_once

    async def one_cycle(*args):
        result = await original_poll(*args)
        stop.set()
        return result

    monkeypatch.setattr(splunk_poller, "poll_once", one_cycle)
    await asyncio.wait_for(splunk_poller.run_splunk_poller(object(), stop), timeout=5)
    assert len(requests) == 1
    assert incidents.pipeline()["missing_settings"] == []
    assert incidents.pipeline()["state"] == "polling"

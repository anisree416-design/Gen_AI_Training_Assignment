"""Unit tests for app.config."""

from pathlib import Path

from app.config import REPO_ROOT, Settings, get_settings


def test_defaults(monkeypatch):
    for var in (
        "OPENAI_API_KEY",
        "OPENAI_BASE_URL",
        "OPENAI_MODEL",
        "INCIDENTIQ_ENV",
        "LOG_LEVEL",
        "RAG_TOP_K",
        "SPLUNK_HEC_URL",
        "SPLUNK_HEC_TOKEN",
        "SPLUNK_INDEX",
        "SPLUNK_POLL_INTERVAL_SECONDS",
    ):
        monkeypatch.delenv(var, raising=False)
    settings = Settings(_env_file=None)
    assert settings.openai_api_key == ""
    assert settings.openai_base_url is None
    assert settings.openai_model == "gpt-5-codex"
    assert settings.incidentiq_env == "development"
    assert settings.log_level == "INFO"
    assert settings.rag_top_k == 5
    assert settings.splunk_hec_url == ""
    assert settings.splunk_hec_token == ""
    assert settings.splunk_index == "incidentiq"
    assert settings.splunk_search_query == "index=incidentiq (level=ERROR OR status=ERROR)"
    assert settings.splunk_poll_interval_seconds == 2


def test_env_overrides(monkeypatch):
    monkeypatch.setenv("OPENAI_MODEL", "test-model")
    monkeypatch.setenv("LOG_LEVEL", "DEBUG")
    monkeypatch.setenv("RAG_TOP_K", "8")
    monkeypatch.setenv("SPLUNK_HEC_URL", "https://hec.example.test/services/collector/event")
    settings = Settings(_env_file=None)
    assert settings.openai_model == "test-model"
    assert settings.log_level == "DEBUG"
    assert settings.rag_top_k == 8
    assert settings.splunk_hec_url == "https://hec.example.test/services/collector/event"


def test_relative_paths_resolve_against_repo_root():
    settings = Settings(_env_file=None)
    assert settings.checkpoint_path == REPO_ROOT / "backend" / "checkpoints.sqlite"
    assert settings.app_db_path_resolved == REPO_ROOT / "backend" / "app.sqlite3"
    assert settings.data_path == REPO_ROOT / "data"
    assert settings.error_docs_path_resolved == REPO_ROOT / "data" / "knowledge" / "error_docs.txt"
    assert settings.github_repo_path_resolved == REPO_ROOT / "data" / "sample_app"


def test_absolute_path_passthrough():
    absolute_path = Path(Path.cwd().anchor) / "tmp" / "checkpoints.sqlite"
    settings = Settings(_env_file=None, checkpoint_db_path=absolute_path)
    assert settings.checkpoint_path == absolute_path


def test_get_settings_is_cached():
    assert get_settings() is get_settings()

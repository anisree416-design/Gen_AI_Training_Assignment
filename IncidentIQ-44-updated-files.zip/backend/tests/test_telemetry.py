from types import SimpleNamespace
from unittest.mock import Mock

from fastapi.testclient import TestClient

from app import telemetry
from app.main import app

settings_from_config = telemetry.settings


def test_credentials_are_redacted_recursively():
    value = telemetry.redact(
        {
            "password": "private",
            "response": {"access_token": "private"},
            "headers": {"Authorization": "private"},
            "cashier": {"name": "Alex"},
            "lines": [{"plu": "4011", "quantity": 2}],
        }
    )
    assert value["password"] == "[REDACTED]"
    assert value["response"]["access_token"] == "[REDACTED]"
    assert value["headers"]["Authorization"] == "[REDACTED]"
    assert value["cashier"]["name"] == "Alex"
    assert value["lines"][0]["quantity"] == 2


def test_hec_settings_come_from_central_application_settings(monkeypatch):
    monkeypatch.setattr(
        telemetry,
        "get_settings",
        lambda: SimpleNamespace(
            splunk_hec_url="https://hec.example.test/services/collector/event",
            splunk_hec_token="token",
            splunk_index="incidentiq",
            splunk_environment="TEST",
            splunk_request_channel="channel",
            splunk_verify_ssl=True,
        ),
    )

    assert settings_from_config() == {
        "SPLUNK_HEC_URL": "https://hec.example.test/services/collector/event",
        "SPLUNK_HEC_TOKEN": "token",
        "SPLUNK_INDEX": "incidentiq",
        "SPLUNK_ENVIRONMENT": "TEST",
        "SPLUNK_REQUEST_CHANNEL": "channel",
        "SPLUNK_VERIFY_SSL": True,
    }


def test_collector_failure_is_swallowed(monkeypatch):
    monkeypatch.setattr(telemetry.httpx, "post", Mock(side_effect=RuntimeError("offline")))
    assert (
        telemetry.SplunkForwarder().send(
            {"SPLUNK_HEC_URL": "https://example.test", "SPLUNK_HEC_TOKEN": "test"},
            {"eventType": "TEST"},
        )
        is False
    )


def test_hec_format_and_rejection(monkeypatch):
    post = Mock(return_value=Mock(is_success=True, json=lambda: {"code": 0}))
    monkeypatch.setattr(telemetry.httpx, "post", post)
    forwarder = telemetry.SplunkForwarder()
    config = {
        "SPLUNK_HEC_URL": "https://example.test",
        "SPLUNK_HEC_TOKEN": "test",
        "SPLUNK_REQUEST_CHANNEL": "channel",
    }
    assert forwarder.send(config, {"eventType": "TEST", "orderNumber": 999048}) is True
    payload = post.call_args.kwargs["json"]
    assert payload["index"] == "incidentiq"
    assert payload["event"]["application"] == "incidentiq_backend"
    assert payload["event"]["orderNumber"] == 999048
    assert payload["event"]["message"] == "Test (UNKNOWN)"
    assert post.call_args.kwargs["headers"]["X-Splunk-Request-Channel"] == "channel"
    post.return_value = Mock(is_success=True, json=lambda: {"code": 6})
    assert forwarder.send(config, {}) is False


def test_error_events_get_fields_for_the_incidentiq_search_poller(monkeypatch):
    """app.tools.splunk_query polls `level=ERROR` and correlates by system/txn_id —
    these must be populated for IncidentIQ's Search API side to find anything."""
    post = Mock(return_value=Mock(is_success=True, json=lambda: {"code": 0}))
    monkeypatch.setattr(telemetry.httpx, "post", post)
    config = {"SPLUNK_HEC_URL": "https://example.test", "SPLUNK_HEC_TOKEN": "test"}
    assert telemetry.SplunkForwarder().send(
        config,
        {
            "eventType": "BACKEND_API_ERROR",
            "status": "ERROR",
            "application": "incidentiq_backend",
            "orderNumber": 999048,
            "errorType": "ValueError",
        },
    )
    event = post.call_args.kwargs["json"]["event"]
    assert event["level"] == "ERROR"
    assert event["system"] == "incidentiq_backend"
    assert event["txn_id"] == "999048"
    assert event["error_code"] == "ValueError"


def test_non_error_events_get_info_level_and_no_error_code(monkeypatch):
    post = Mock(return_value=Mock(is_success=True, json=lambda: {"code": 0}))
    monkeypatch.setattr(telemetry.httpx, "post", post)
    config = {"SPLUNK_HEC_URL": "https://example.test", "SPLUNK_HEC_TOKEN": "test"}
    assert telemetry.SplunkForwarder().send(
        config, {"eventType": "ORDER_STARTED", "status": "SUCCESS", "orderNumber": 7}
    )
    event = post.call_args.kwargs["json"]["event"]
    assert event["level"] == "INFO"
    assert event["error_code"] == ""
    assert event["txn_id"] == "7"


def test_existing_message_is_preserved(monkeypatch):
    post = Mock(return_value=Mock(is_success=True, json=lambda: {"code": 0}))
    monkeypatch.setattr(telemetry.httpx, "post", post)
    config = {"SPLUNK_HEC_URL": "https://example.test", "SPLUNK_HEC_TOKEN": "test"}
    assert telemetry.SplunkForwarder().send(
        config, {"eventType": "ORDER_STARTED", "status": "SUCCESS", "message": "Order 7 started"}
    )
    assert post.call_args.kwargs["json"]["event"]["message"] == "Order 7 started"


def test_frontend_application_label_is_preserved(monkeypatch):
    post = Mock(return_value=Mock(is_success=True, json=lambda: {"code": 0}))
    monkeypatch.setattr(telemetry.httpx, "post", post)
    config = {"SPLUNK_HEC_URL": "https://example.test", "SPLUNK_HEC_TOKEN": "test"}
    assert telemetry.SplunkForwarder().send(
        config,
        {
            "application": "incidentiq_frontend",
            "eventType": "SCREEN_VIEW",
            "message": "Opened login screen",
        },
    )
    assert post.call_args.kwargs["json"]["event"]["application"] == "incidentiq_frontend"


def test_backend_api_middleware_logs_request_and_response(monkeypatch):
    submit = Mock(return_value=1)
    monkeypatch.setattr(telemetry.forwarder, "submit", submit)
    client = TestClient(app)
    response = client.get(
        "/api/products",
        headers={"X-Request-ID": "request-123", "X-Order-Number": "999048"},
    )
    assert response.status_code == 401  # Unauthenticated POS calls are still logged.
    assert response.headers["X-Request-ID"] == "request-123"
    events = [call.args[0][0] for call in submit.call_args_list]
    assert [event["eventType"] for event in events] == [
        "BACKEND_API_REQUEST",
        "BACKEND_API_RESPONSE",
    ]
    assert all(event["application"] == "incidentiq_backend" for event in events)
    assert all(event["orderNumber"] == 999048 for event in events)
    assert all(event["message"] for event in events)


def test_backend_api_middleware_always_includes_order_number_key(monkeypatch):
    submit = Mock(return_value=1)
    monkeypatch.setattr(telemetry.forwarder, "submit", submit)
    client = TestClient(app)

    assert client.get("/api/products").status_code == 401

    events = [call.args[0][0] for call in submit.call_args_list]
    assert all("orderNumber" in event for event in events)
    assert all(event["orderNumber"] is None for event in events)


def test_telemetry_endpoint_is_excluded_from_backend_api_logging(monkeypatch):
    submit = Mock(return_value=1)
    monkeypatch.setattr(telemetry.forwarder, "submit", submit)
    client = TestClient(app)
    assert client.post("/api/telemetry", json={"events": []}).status_code == 202
    assert submit.call_count == 1


def test_telemetry_endpoint_fails_open(monkeypatch):
    monkeypatch.setattr(
        telemetry.forwarder, "submit", Mock(side_effect=RuntimeError("unavailable"))
    )
    client = TestClient(app)
    assert client.post("/api/telemetry", json={"events": [{"eventType": "TEST"}]}).json() == {
        "accepted": 0
    }
    assert client.post("/api/telemetry", content="invalid").status_code == 202
    assert client.post("/api/telemetry", content="x" * 128_001).json() == {"accepted": 0}
    assert client.get("/api/health").status_code == 200


def test_disabled_and_full_queue_drop_events(monkeypatch):
    monkeypatch.setattr(telemetry, "settings", lambda: {})
    forwarder = telemetry.SplunkForwarder()
    assert forwarder.submit([{}]) == 0
    monkeypatch.setattr(
        telemetry,
        "settings",
        lambda: {"SPLUNK_HEC_TOKEN": "test", "SPLUNK_HEC_URL": "https://example.test"},
    )
    forwarder.worker = Mock(is_alive=lambda: True)
    assert forwarder.submit([{}] * 600) == 500
    assert forwarder.submit([{}]) == 0

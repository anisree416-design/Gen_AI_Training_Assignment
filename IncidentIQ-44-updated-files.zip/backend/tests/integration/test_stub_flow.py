"""Integration tests — the full graph runs end-to-end with zero LLM/Splunk/GitHub calls.

Covers: all sections populated, sequential run order, the approval interrupt,
resume-with-approve, resume-with-reject, and the pre-seeded auto-approve path.
`rca` and `code_fix` are overridden with canned stand-ins (same pattern as
`scripts/smoke_graph.py`) since their real implementations call a live LLM
(and, for code_fix, push a real git branch).
"""

import pytest
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

from app.graph.builder import build_graph
from app.graph.checkpointer import state_serde
from app.graph.state import ApprovalDecision, FixResult, IncidentState, RCAResult, make_event


def stub_rca(state: IncidentState) -> dict:
    result = RCAResult(root_cause="stub root cause", confidence=0.8)
    return {"rca": result, "events": [make_event("rca", "stub root cause produced")]}


def stub_code_fix(state: IncidentState) -> dict:
    result = FixResult(status="created", branch_name="fix/stub-001")
    return {"fix_result": result, "events": [make_event("code_fix", "stub branch created")]}


NODE_OVERRIDES = {"rca": stub_rca, "code_fix": stub_code_fix}


@pytest.fixture(autouse=True)
def offline_splunk(monkeypatch):
    from unittest.mock import Mock

    from app.tools import splunk_query

    monkeypatch.setattr(splunk_query, "_client", Mock(fetch_log_window=Mock(return_value=[])))


@pytest.fixture
def graph():
    return build_graph(
        checkpointer=MemorySaver(serde=state_serde()),
        node_overrides=NODE_OVERRIDES,
    )


@pytest.fixture
def config():
    return {"configurable": {"thread_id": "test-thread"}}


def run_to_approval(graph, config, incident_id: str = "INC-001"):
    """Invoke up to the human gate; assert the interrupt fired at approval."""
    result = graph.invoke({"incident_id": incident_id}, config)
    snapshot = graph.get_state(config)
    assert snapshot.next == ("approval",)
    return result


class TestStubFlowEndToEnd:
    def test_all_sections_populated_before_approval(self, graph, config):
        result = run_to_approval(graph, config)
        assert result["error_event"] is not None
        assert result["retrieved_logs"]
        assert result["similar_error_docs"] == []  # no docs ingested in this process
        assert result["rca"] is not None

    def test_nodes_run_in_order(self, graph, config):
        result = run_to_approval(graph, config)
        order = [event.node for event in result["events"]]
        assert order == ["intake", "retrieval", "rag", "rca"]

    def test_interrupt_payload_carries_review_data(self, graph, config):
        run_to_approval(graph, config)
        snapshot = graph.get_state(config)
        task = snapshot.tasks[0]
        payload = task.interrupts[0].value
        assert payload["incident_id"] == "INC-001"
        assert payload["root_cause"]


class TestResumeAfterApproval:
    def test_resume_with_approve_completes_flow(self, graph, config):
        run_to_approval(graph, config)
        final = graph.invoke(
            Command(resume=ApprovalDecision(status="approved", reviewer="tester")), config
        )
        assert final["approval"].status == "approved"
        assert final["fix_result"] is not None
        assert final["fix_result"].status == "created"
        order = [event.node for event in final["events"]]
        assert order[-1] == "code_fix"

    def test_resume_with_reject_skips_fix(self, graph, config):
        run_to_approval(graph, config)
        final = graph.invoke(
            Command(resume=ApprovalDecision(status="rejected", reviewer="tester")), config
        )
        assert final["approval"].status == "rejected"
        assert final.get("fix_result") is None
        assert "code_fix" not in [event.node for event in final["events"]]

    def test_preseeded_approval_runs_without_interrupt(self):
        """Auto-approve mode: a pre-seeded decision bypasses the human gate."""
        graph = build_graph(
            checkpointer=MemorySaver(serde=state_serde()),
            node_overrides=NODE_OVERRIDES,
        )
        config = {"configurable": {"thread_id": "auto-approve"}}
        final = graph.invoke(
            {
                "incident_id": "INC-AUTO",
                "approval": ApprovalDecision(status="approved", reviewer="auto"),
            },
            config,
        )
        assert final["fix_result"] is not None

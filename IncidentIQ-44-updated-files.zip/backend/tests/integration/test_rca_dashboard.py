"""Exercise real ingestion, retrieval, RCA parsing, persistence and read APIs offline."""

import importlib
import json
import os
from types import SimpleNamespace

import pytest
from chromadb.api.types import EmbeddingFunction
from fastapi.testclient import TestClient

from app.config import Settings
from app.db import repository
from app.graph.builder import build_graph
from app.graph.checkpointer import get_checkpointer
from app.rag import ingest, store
from app.services.splunk_poller import poll_once, process_splunk_row
from app.tools import splunk_query

rca_module = importlib.import_module("app.graph.nodes.rca")
rag_module = importlib.import_module("app.graph.nodes.rag")
code_fix_module = importlib.import_module("app.graph.nodes.code_fix")


class OfflineEmbedding(EmbeddingFunction):
    """Deterministic embedding replaces model downloads in integration tests only."""

    def __init__(self):
        pass

    def get_config(self):
        return {}

    @staticmethod
    def build_from_config(config):
        return OfflineEmbedding()

    def __call__(self, input):
        return [
            [float("checkout" in text.lower()), float("payment" in text.lower()), 0.1]
            for text in input
        ]

    @staticmethod
    def name():
        return "test-keywords"


ROW = {
    "_cd": "test-bucket:1",
    "_time": "2026-09-25T10:00:00Z",
    "application": "incidentiq_backend",
    "status": "ERROR",
    "eventType": "CHECKOUT_FAILED",
    "orderNumber": 42,
    "message": "Demo error: checkout pricing failed.",
}


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    knowledge = tmp_path / "errors.txt"
    knowledge.write_text(
        "Error: checkout pricing failed\nSolution: disable demo switch\n---\n"
        "Error: payment timeout\nSolution: investigate gateway",
        encoding="utf-8",
    )
    settings = Settings(
        _env_file=None, app_db_path=tmp_path / "app.sqlite3", error_docs_path=knowledge, rag_top_k=1
    )
    monkeypatch.setattr(repository, "get_settings", lambda: settings)
    monkeypatch.setattr(ingest, "get_settings", lambda: settings)
    monkeypatch.setattr(rag_module, "get_settings", lambda: settings)
    chroma = store.get_chroma_client()
    collection = chroma.create_collection(
        "test-" + tmp_path.name.replace("_", "-"), embedding_function=OfflineEmbedding()
    )
    monkeypatch.setattr(ingest, "reset_error_docs_collection", lambda: collection)
    monkeypatch.setattr(rag_module, "get_error_docs_collection", lambda: collection)
    assert ingest.ingest_error_docs() == 2
    calls = []

    class Splunk:
        def poll_new_errors(self, since):
            return [ROW]

        def fetch_log_window(self, txn_id, system, occurred_at=None):
            calls.append((txn_id, system, occurred_at))
            return [
                {
                    "_raw": json.dumps(
                        {
                            "timestamp": "2026-09-25T10:00:00Z",
                            "application": system,
                            "message": ROW["message"],
                            "status": "ERROR",
                        }
                    )
                }
            ]

    monkeypatch.setattr(splunk_query, "_client", Splunk())
    prompts = []

    class LLM:
        def invoke(self, messages):
            payload = json.loads(messages[1]["content"])
            prompts.append(payload)
            return SimpleNamespace(
                content=json.dumps(
                    {
                        "root_cause": "Demo checkout switch deliberately raises a pricing error",
                        "summary": "Checkout demo failure",
                        "confidence": 0.9,
                        "severity": "high",
                        "evidence": [payload["log_window"][0]["message"]],
                        "evidence_ids": [
                            payload["similar_error_docs"][0]["id"],
                            "log-0",
                            "invented",
                        ],
                        "recommended_action": "Disable DEMO_BE_CHECKOUT_ERROR and restart backend",
                    }
                )
            )

    monkeypatch.setattr(rca_module, "get_chat_model", lambda: LLM())
    checkpoint = get_checkpointer(tmp_path / "checkpoint.sqlite")
    graph = build_graph(checkpointer=checkpoint)
    yield settings, graph, calls, prompts
    checkpoint.conn.close()
    chroma.delete_collection(collection.name)


def test_splunk_to_saved_rca_api_with_real_rag(runtime):
    from app.main import app

    settings, graph, calls, prompts = runtime
    incident_id = process_splunk_row(graph, ROW, settings.app_db_path)
    assert calls[0][0] == "42"
    assert calls[0][2].year == 2026
    assert "checkout" in prompts[0]["similar_error_docs"][0]["content"]
    assert graph.get_state({"configurable": {"thread_id": incident_id}}).next == ("approval",)
    assert process_splunk_row(graph, ROW, settings.app_db_path) is None
    # No context manager: do not start the real background poller in this API test.
    client = TestClient(app)
    result = client.get("/api/incidents").json()
    assert result["total"] == 1
    assert result["items"][0]["status"] == "rca_ready"
    assert "context" not in result["items"][0]
    detail = client.get(f"/api/incidents/{incident_id}").json()
    assert detail["rca"]["summary"] == "checkout pricing failed."
    assert "demo" not in detail["rca"]["root_cause"].lower()
    assert "DEMO_" not in detail["rca"]["recommended_action"]
    assert "invented" not in detail["rca"]["evidence_ids"]
    assert detail["context"]["documents"][0]["doc_id"] in detail["rca"]["evidence_ids"]
    assert detail["context"]["logs"][0]["message"] == ROW["message"]
    assert "raw" not in detail["error_event"]
    assert client.get("/api/incidents/missing").status_code == 404
    assert client.get("/api/incidents?limit=0").status_code == 422
    assert client.get("/api/incidents?offset=1").json()["items"] == []


def test_incidents_can_be_deleted_individually_or_all_at_once(runtime):
    from app.main import app

    settings, graph, _, _ = runtime
    first_id = process_splunk_row(graph, ROW, settings.app_db_path)
    client = TestClient(app)

    response = client.delete(f"/api/incidents/{first_id}")
    assert response.status_code == 200
    assert response.json()["deleted"] == 1
    assert client.get("/api/incidents").json()["total"] == 0
    assert client.delete(f"/api/incidents/{first_id}").status_code == 404

    second_row = {**ROW, "_cd": "test-bucket:delete-all", "requestId": "delete-all"}
    process_splunk_row(graph, second_row, settings.app_db_path)
    assert client.get("/api/incidents").json()["total"] == 1
    assert client.delete("/api/incidents").json()["deleted"] == 1
    assert client.get("/api/incidents").json()["total"] == 0


def test_fix_button_resumes_analysis_and_returns_reviewable_snapshots(runtime, monkeypatch):
    from app.main import app
    from app.tools.issue_fix import ProposedFix

    settings, graph, _, _ = runtime
    incident_id = process_splunk_row(graph, ROW, settings.app_db_path)
    app.state.graph = graph
    monkeypatch.setattr(code_fix_module, "search_code", lambda *args: [object()])
    monkeypatch.setattr(
        code_fix_module,
        "propose_fix",
        lambda *args: ProposedFix(
            file_path="checkout.py",
            before_code="total = None\n",
            after_code="total = calculate_total(order)\n",
            diff="-total = None\n+total = calculate_total(order)\n",
            explanation="Calculate the order total before returning the quote.",
        ),
    )
    monkeypatch.setattr(
        code_fix_module,
        "create_fix_branch",
        lambda *args, **kwargs: {
            "branch_name": f"fix/{incident_id.lower()}-20260927120000",
            "branch_url": "",
            "commit_sha": "abc123",
            "push_status": "local",
        },
    )

    response = TestClient(app).post(f"/api/incidents/{incident_id}/fix")

    assert response.status_code == 200
    fix = response.json()["fix_result"]
    assert fix["status"] == "created"
    assert fix["branch_name"].startswith(f"fix/{incident_id.lower()}-")
    assert fix["before_code"] == "total = None\n"
    assert fix["after_code"] == "total = calculate_total(order)\n"
    assert "demo" not in fix["summary"].lower()
    assert TestClient(app).post(f"/api/incidents/{incident_id}/fix").json()["fix_result"] == fix


@pytest.mark.asyncio
async def test_failed_llm_validation_retries_checkpoint_and_appears_in_api(runtime, monkeypatch):
    from app.main import app

    settings, graph, calls, prompts = runtime
    original = rca_module.get_chat_model

    class InvalidLLM:
        def invoke(self, messages):
            return SimpleNamespace(content='{"root_cause": "test", "confidence": 2}')

    monkeypatch.setattr(rca_module, "get_chat_model", lambda: InvalidLLM())
    assert await poll_once(graph, splunk_query._client, None, settings.app_db_path) is None
    client = TestClient(app)
    result = client.get("/api/incidents").json()["items"][0]
    assert result["status"] == "failed"
    assert result["rca"] is None
    monkeypatch.setattr(rca_module, "get_chat_model", original)
    assert await poll_once(graph, splunk_query._client, None, settings.app_db_path) is not None
    result = client.get("/api/incidents").json()["items"][0]
    assert result["status"] == "rca_ready"
    assert len(calls) == 1  # The failed RCA node resumed; Splunk retrieval was not repeated.


def test_search_is_scoped_and_uses_safe_time_bounds(monkeypatch):
    from datetime import UTC, datetime

    settings = Settings(_env_file=None, splunk_index="incidentiq")
    monkeypatch.setattr(splunk_query, "get_settings", lambda: settings)
    client = splunk_query.SplunkRestClient()
    searches = []
    monkeypatch.setattr(client, "_run_search", lambda search: searches.append(search) or [])
    client.fetch_log_window('42" OR index=*', "backend", datetime(2026, 9, 25, tzinfo=UTC))
    assert 'index="incidentiq"' in searches[0]
    assert '42\\" OR index=*' in searches[0]
    assert "earliest=" in searches[0] and "latest=" in searches[0]
    assert "head 200" in searches[0]


def test_pipeline_missing_configuration_does_not_expose_secrets(monkeypatch):
    from app.api.routes import incidents

    monkeypatch.setattr(
        incidents,
        "get_settings",
        lambda: Settings(
            _env_file=None, splunk_search_url="", splunk_search_token="", openai_api_key=""
        ),
    )
    result = incidents.pipeline()
    assert set(result["missing_settings"]) == {
        "SPLUNK_SEARCH_URL",
        "SPLUNK_SEARCH_TOKEN or (SPLUNK_SEARCH_USERNAME and SPLUNK_SEARCH_PASSWORD)",
        "OPENAI_API_KEY",
    }


def test_dashboard_requests_do_not_generate_recursive_splunk_errors(runtime, monkeypatch):
    from unittest.mock import Mock

    from app.main import app
    from app.telemetry import forwarder

    submit = Mock()
    monkeypatch.setattr(forwarder, "submit", submit)
    client = TestClient(app)
    assert client.get("/api/incidents/missing").status_code == 404
    assert client.get("/api/pipeline/status").status_code == 200
    assert client.get("/api/health").status_code == 200
    submit.assert_not_called()


@pytest.mark.skipif(
    not os.environ.get("RCA_TEST_BROWSER"),
    reason="Set RCA_TEST_BROWSER for headless UI verification",
)
@pytest.mark.parametrize("view", ["list", "detail"])
def test_browser_displays_persisted_rca(runtime, tmp_path, view):
    """Serve the built frontend with real read APIs and inspect the browser-rendered DOM."""
    import subprocess
    import threading
    from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
    from pathlib import Path

    from app.main import app

    settings, graph, _, _ = runtime
    process_splunk_row(graph, ROW, settings.app_db_path)
    client = TestClient(app)
    dist = Path(__file__).resolve().parents[3] / "frontend" / "dist"
    assert (dist / "index.html").exists(), "Run npm run build before the browser test"

    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(dist), **kwargs)

        def do_GET(self):
            if self.path.startswith("/api/"):
                response = client.get(self.path)
                self.send_response(response.status_code)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(response.content)
            else:
                if self.path == "/incidents":
                    html = (dist / "index.html").read_text(encoding="utf-8")
                    if view == "detail":
                        html += """<script>
                        const clickTimer = setInterval(() => {
                          const button = document.querySelector('.iq-view-button');
                          if (button) { button.click(); clearInterval(clickTimer); }
                        }, 50);
                        </script>"""
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    self.wfile.write(html.encode())
                    return
                super().do_GET()

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        result = subprocess.run(
            [
                os.environ["RCA_TEST_BROWSER"],
                "--headless=new",
                "--disable-gpu",
                "--no-first-run",
                "--disable-extensions",
                "--disable-background-networking",
                f"--user-data-dir={tmp_path / 'browser-profile'}",
                "--dump-dom",
                "--virtual-time-budget=5000",
                f"http://127.0.0.1:{server.server_port}/incidents",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=45,
        )
        assert result.returncode == 0, result.stderr[-1500:]
        assert "checkout pricing failed." in result.stdout
        assert "INC-00001" in result.stdout
        assert "DEMO_BE_CHECKOUT_ERROR" not in result.stdout
        if view == "list":
            assert "View details" in result.stdout
            assert 'class="iq-new-badge"' in result.stdout
            assert 'aria-label="Incident details"' not in result.stdout
        else:
            assert "Back to incidents" in result.stdout
            assert "does not establish the internal cause" in result.stdout
            assert "Technical logs" in result.stdout
            assert 'class="iq-new-badge"' not in result.stdout
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)

"""Request-level grouping, late evidence, and separate failures in one order."""

import pytest
from fastapi.testclient import TestClient

from app.db import repository
from app.services.incident_correlation import correlation_key
from app.services.splunk_poller import poll_once, process_splunk_row
from tests.integration import test_rca_dashboard as dashboard

ROW = dashboard.ROW
runtime = dashboard.runtime


def row(number, request="request-one", **extra):
    return {
        **ROW,
        "_cd": f"group:{number}",
        "requestId": request,
        "path": "/api/checkout/quote",
        "method": "POST",
        "httpStatus": 422,
        "message": "POST /api/checkout/quote returned HTTP 422",
        **extra,
    }


@pytest.mark.asyncio
async def test_one_analysis_for_frontend_and_backend_request_errors(runtime):
    settings, graph, _, prompts = runtime
    rows = [
        row(1),
        row(2, application="incidentiq_frontend"),
        row(3, eventType="CHECKOUT_FAILED", message="lines: Input should be a valid list"),
    ]

    class Splunk:
        def poll_new_errors(self, since):
            return rows

    assert await poll_once(graph, Splunk(), None, settings.app_db_path)
    assert len(prompts) == 1
    records = repository.list_incidents(settings.app_db_path)
    assert len(records) == 1
    assert (
        len(repository.read_incident_events(records[0]["incident_id"], settings.app_db_path)) == 3
    )
    # Replay across polling cycles is idempotent.
    assert await poll_once(graph, Splunk(), None, settings.app_db_path)
    assert len(prompts) == 1


def test_late_response_updates_same_incident_and_new_request_creates_another(runtime):
    settings, graph, _, prompts = runtime
    first = process_splunk_row(graph, row(1), settings.app_db_path)
    late = process_splunk_row(
        graph, row(2, responseBody={"detail": "Invalid lines"}), settings.app_db_path
    )
    assert late == first
    assert len(prompts) == 2
    assert any(log["details"].get("responseBody") for log in prompts[-1]["log_window"])
    another = process_splunk_row(graph, row(3, request="request-two"), settings.app_db_path)
    assert another != first
    assert len(repository.list_incidents(settings.app_db_path)) == 2


def test_legacy_ui_message_requires_unique_request_and_matching_scope():
    ui = row(3, request=None, message="Invalid lines", sessionId="browser-one")
    anchor = row(1, responseBody={"detail": "Invalid lines"}, sessionId="browser-one")
    assert correlation_key(ui, [anchor]) == "request:request-one"
    assert correlation_key(ui, [anchor, {**anchor, "requestId": "request-two"}]) is None
    assert correlation_key({**ui, "orderNumber": 99}, [anchor]) is None
    assert correlation_key({**ui, "sessionId": "browser-two"}, [anchor]) is None


def test_request_evidence_redacts_credentials(runtime):
    settings, graph, _, prompts = runtime
    process_splunk_row(
        graph, row(1, requestBody={"password": "private", "lines": "bad"}), settings.app_db_path
    )
    bodies = [
        log["details"]["requestBody"]
        for log in prompts[0]["log_window"]
        if "requestBody" in log["details"]
    ]
    assert bodies == [{"password": "[REDACTED]", "lines": "bad"}]


def test_api_groups_historical_rows_and_preserves_old_detail_links(runtime):
    from app.graph.state import RCAResult
    from app.main import app
    from app.services.splunk_normalizer import normalize_splunk_error

    settings, _, _, _ = runtime
    for index in (1, 2):
        event = normalize_splunk_error(row(index))
        repository.save_rca(
            f"legacy-{index}",
            event,
            RCAResult(root_cause="The request was rejected.", summary="Checkout failed."),
            settings.app_db_path,
        )
    client = TestClient(app)
    listing = client.get("/api/incidents").json()
    assert listing["total"] == 1
    number = listing["items"][0]["incident_number"]
    for index in (1, 2):
        detail = client.get(f"/api/incidents/legacy-{index}").json()
        assert detail["incident_number"] == number
        assert detail["event_count"] == 2
        assert len(detail["context"]["logs"]) == 1  # Identical evidence is shown once.
    assert client.get("/api/incidents").json()["items"][0]["incident_number"] == number


def test_numbers_are_stable_and_read_requests_do_not_consume_numbers(tmp_path):
    path = tmp_path / "numbering.sqlite"
    for _ in range(4):
        assert repository.incident_numbers(["first"], path)["first"] == 1
    assert repository.incident_numbers(["first", "second"], path)["second"] == 2

"""Thin LLM client wrapper — the single place members get a chat model.

Owner: Member 1. Members 3/4/6 call ``get_chat_model()`` inside their nodes;
prompts stay per-agent (owned by each member). ``with_retries()`` wraps any
callable with exponential backoff for transient provider errors.
"""

from collections.abc import Callable
from functools import lru_cache

from langchain_openai import ChatOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import get_settings


@lru_cache(maxsize=4)
def get_chat_model(temperature: float = 0.0) -> ChatOpenAI:
    """Cached ChatOpenAI wired from settings (OpenAI-compatible Codex endpoint)."""
    settings = get_settings()
    return ChatOpenAI(
        model=settings.openai_model,
        api_key=settings.openai_api_key,
        base_url=settings.openai_base_url or None,
        temperature=temperature,
        timeout=60,
        max_retries=0,  # The outer retry wrapper owns the retry budget.
    )


def with_retries[T](fn: Callable[..., T]) -> Callable[..., T]:
    """Exponential-backoff retry wrapper for transient LLM/provider errors."""
    return retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )(fn)


def strip_code_fences(text: str) -> str:
    """Strip a leading/trailing markdown code fence (e.g. ```json ... ```) if present."""
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[len("json") :]
    return text.strip()

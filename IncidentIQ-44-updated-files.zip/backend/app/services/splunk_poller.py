"""Background service that turns new Splunk errors into paused RCA workflows."""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.config import get_settings
from app.db.repository import (
    is_event_processed,
    mark_event_processed,
    read_incident_events,
    record_incident_event,
    save_analysis_status,
)
from app.services.incident_correlation import correlation_key, incident_id_for_key
from app.services.splunk_normalizer import normalize_splunk_error
from app.tools.splunk_query import SplunkClient, get_splunk_client

logger = logging.getLogger(__name__)
pipeline_status = {"state": "starting", "last_successful_poll": None, "last_error": None}


def incident_id_for_error(error_id: str) -> str:
    """Derive a stable graph thread/incident ID from the stable Splunk error ID."""
    return f"INC-{error_id}"


def process_splunk_row(
    graph: Any,
    row: dict[str, Any],
    db_path: str | Path | None = None,
    candidates=(),
    refresh_evidence=False,
) -> str | None:
    """Process one row through approval, returning its incident ID or None if duplicate."""
    error_event = normalize_splunk_error(row)
    if is_event_processed(error_event.error_id, db_path):
        return None

    key = correlation_key(row, candidates)
    incident_id = incident_id_for_key(key) if key else incident_id_for_error(error_event.error_id)
    added = record_incident_event(incident_id, error_event, db_path)
    config = {"configurable": {"thread_id": incident_id}}
    existing = graph.get_state(config)
    if getattr(existing, "values", None):
        if key and (added or refresh_evidence):
            # New evidence can arrive while analysis is paused OR failed.
            graph.update_state(config, {"error_event": error_event}, as_node="intake")
            existing = graph.get_state(config)
        elif tuple(existing.next) == ("approval",):
            mark_event_processed(error_event.error_id, incident_id, db_path)
            return incident_id
    save_analysis_status(incident_id, error_event, "analyzing", db_path=db_path)
    try:
        # Resume a failed checkpoint at its pending node instead of restarting intake.
        graph.invoke(
            None
            if getattr(existing, "values", None)
            else {"incident_id": incident_id, "error_event": error_event},
            config,
        )
    except Exception:
        save_analysis_status(
            incident_id,
            error_event,
            "failed",
            "Analysis failed; the next polling cycle will retry. Check backend logs.",
            db_path=db_path,
        )
        raise
    snapshot = graph.get_state(config)
    if tuple(snapshot.next) != ("approval",):
        raise RuntimeError(f"incident {incident_id} did not pause at approval")

    mark_event_processed(error_event.error_id, incident_id, db_path)
    save_analysis_status(incident_id, error_event, "rca_ready", db_path=db_path)
    return incident_id


async def poll_once(
    graph: Any,
    client: SplunkClient,
    since: datetime | None,
    db_path: str | Path | None = None,
) -> datetime | None:
    """Run one polling cycle and advance the cursor only when retryable work succeeds."""
    cycle_started = datetime.now(UTC)
    rows = await asyncio.to_thread(client.poll_new_errors, since)
    candidates = rows + [event.raw for event in read_incident_events(db_path=db_path)]
    retry_required = False

    groups = {}
    for row in rows:
        try:
            event = normalize_splunk_error(row)
        except (ValueError, TypeError):
            logger.warning("Skipping malformed Splunk error")
            continue
        if not is_event_processed(event.error_id, db_path):
            key = correlation_key(row, candidates)
            group_id = incident_id_for_key(key) if key else incident_id_for_error(event.error_id)
            groups.setdefault(group_id, []).append((row, event))

    for group_id, members in groups.items():
        row, _ = members[-1]
        try:
            # Analyze once per request per poll, with all constituent errors present.
            new_evidence = False
            for _, event in members[:-1]:
                new_evidence |= record_incident_event(group_id, event, db_path)
            await asyncio.to_thread(
                process_splunk_row, graph, row, db_path, candidates, new_evidence
            )
            for _, event in members:
                mark_event_processed(event.error_id, group_id, db_path)
        except Exception:
            # Only malformed input is skipped. LLM validation errors must be retried.
            try:
                normalize_splunk_error(row)
            except (ValueError, TypeError):
                logger.warning("Skipping malformed Splunk error")
                continue
            retry_required = True
            logger.exception("Failed to process a Splunk error; it will be retried")

    pipeline_status.update(
        state="processing_errors" if retry_required else "polling",
        last_successful_poll=cycle_started.isoformat(),
        last_error="Some incidents failed; retrying." if retry_required else None,
    )
    return since if retry_required else cycle_started


async def run_splunk_poller(
    graph: Any,
    stop_event: asyncio.Event,
    *,
    client: SplunkClient | None = None,
    interval_seconds: float | None = None,
    db_path: str | Path | None = None,
) -> None:
    """Poll until shutdown, isolating transient search and per-event failures."""
    poll_client = client or get_splunk_client()
    interval = interval_seconds or get_settings().splunk_poll_interval_seconds
    since: datetime | None = None

    while not stop_event.is_set():
        try:
            settings = get_settings()
            if client is None and settings.pipeline_missing_settings:
                pipeline_status.update(state="configuration_required", last_error=None)
            else:
                since = await poll_once(graph, poll_client, since, db_path)
        except asyncio.CancelledError:
            raise
        except Exception:
            pipeline_status.update(
                state="connection_error",
                last_error="Splunk search failed. Check connection settings and backend logs.",
            )
            logger.exception("Splunk polling cycle failed; retrying after the configured interval")

        try:
            await asyncio.wait_for(stop_event.wait(), timeout=interval)
        except TimeoutError:
            continue

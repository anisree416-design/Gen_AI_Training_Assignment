"""Operational summaries for both new and previously saved analyses."""

import re


def operational_message(value):
    return re.sub(r"\bdemo error:\s*", "", value or "", flags=re.I).strip()


def _setup_explanation(value):
    return bool(
        re.search(
            r"\bdemo\b|\b(?:VITE_)?DEMO_|(?:injected|deliberate|simulated) (?:error|failure)"
            r"|disable.*switch",
            value,
            re.I,
        )
    )


def operational_rca(rca, event):
    """Replace setup-only explanations with an explicit statement of uncertainty.

    Original evidence stays in storage. Never turn a simulated failure into an
    invented production outage or assert an internal cause absent from the logs.
    """
    if not rca:
        return None
    result = dict(rca)
    observed = operational_message(event.get("message", "")) or "The cashier operation failed."
    if _setup_explanation(result.get("summary", "")):
        result["summary"] = observed
    if _setup_explanation(result.get("root_cause", "")):
        result["root_cause"] = (
            f"Observed failure: {observed} "
            "The available analysis does not establish the internal cause. "
            "Review the recorded request, response and cashier activity below."
        )
        result["confidence"] = min(result.get("confidence", 0), 0.3)
    if _setup_explanation(result.get("recommended_action", "")):
        result["recommended_action"] = (
            "Inspect the failed endpoint's response and submitted fields in the timeline; "
            "use the request ID to investigate the corresponding server failure."
        )
    for field in ("contributing_factors", "sequence_of_events"):
        result[field] = [text for text in result.get(field, []) if not _setup_explanation(text)]
    result["evidence"] = [
        operational_message(text)
        for text in result.get("evidence", [])
        if not _setup_explanation(operational_message(text))
    ]
    return result


def short_analysis(rca, event):
    from app.services.splunk_normalizer import _event_fields

    summary = (rca or {}).get("summary")
    if not summary:
        path = str(_event_fields(event.get("raw", {})).get("path") or "")
        labels = (
            ("/items", "An item could not be added to the order."),
            ("/checkout/quote", "The cashier could not get an order total."),
            ("/payments", "Payment could not be completed."),
            ("/products/plu", "The product lookup failed."),
            ("/auth/login", "The cashier could not sign in."),
        )
        summary = next((label for endpoint, label in labels if endpoint in path), None)
    summary = summary or operational_message(event.get("message", ""))
    return summary if len(summary) <= 220 else summary[:217].rsplit(" ", 1)[0] + "..."

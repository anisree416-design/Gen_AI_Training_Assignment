"""Correlate one failed request across browser and server telemetry."""

import hashlib
import json

from app.services.splunk_normalizer import _event_fields, _parse_timestamp


def request_key(row):
    if not isinstance(row, dict):
        return None
    fields = _event_fields(row)
    # Each request is a failure boundary: another failed request in the same order
    # is a new incident, even when its endpoint or error text is identical.
    value = fields.get("requestId") or fields.get("flowId")
    return f"request:{value}" if value else None


def _scope(fields):
    return str(fields.get("orderNumber") or fields.get("txn_id") or ""), str(
        fields.get("sessionId") or ""
    )


def correlation_key(row, candidates=()):
    """Use exact IDs; associate legacy UI messages only with an unambiguous request."""
    direct = request_key(row)
    if direct:
        return direct
    fields = _event_fields(row)
    timestamp = _parse_timestamp(fields.get("_time") or fields.get("timestamp"))
    message = str(fields.get("message") or "").strip()
    order, session = _scope(fields)
    matches = set()
    if timestamp and message and (order or session):
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            other = _event_fields(candidate)
            key = request_key(other)
            when = _parse_timestamp(other.get("_time") or other.get("timestamp"))
            other_order, other_session = _scope(other)
            same_scope = (order and order == other_order) or (
                session and session == other_session and not (order and other_order)
            )
            if not key or not when or not same_scope:
                continue
            if session and other_session and session != other_session:
                continue
            if abs((timestamp - when).total_seconds()) > 5:
                continue
            response = other.get("responseBody") or {}
            detail = response.get("detail") if isinstance(response, dict) else None
            messages = {str(other.get("message") or ""), str(detail or "")}
            if isinstance(detail, list):
                messages.add(
                    "; ".join(
                        (
                            ".".join(str(p) for p in item.get("loc", []) if p != "body") + ": "
                            if item.get("loc")
                            else ""
                        )
                        + item.get("msg", "Invalid value")
                        for item in detail
                        if isinstance(item, dict)
                    )
                )
            if message in messages:
                matches.add(key)
    return matches.pop() if len(matches) == 1 else None


def incident_id_for_key(key):
    return "INC-FLOW-" + hashlib.sha256(key.encode()).hexdigest()[:20].upper()


EVIDENCE_FIELDS = (
    "requestId",
    "flowId",
    "sessionId",
    "orderNumber",
    "eventType",
    "userFlow",
    "method",
    "path",
    "httpStatus",
    "requestBody",
    "responseBody",
    "durationMs",
    "productId",
    "name",
    "plu",
    "quantity",
    "lines",
    "action",
    "cashier",
)


def evidence_metadata(row):
    # Keep only useful fields, and apply the same redaction as telemetry ingestion.
    from app.telemetry import redact

    fields = _event_fields(row)
    return redact({key: fields[key] for key in EVIDENCE_FIELDS if key in fields})


def log_identity(log):
    return json.dumps(log, sort_keys=True, default=str)

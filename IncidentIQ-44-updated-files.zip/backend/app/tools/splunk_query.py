"""Splunk REST Search API client — polls for new error events and fetches log windows.

Owner: Member 2. Behind a small Protocol so tests/dev can inject a fake client
without hitting a real Splunk instance (mirrors the `node_overrides` pattern
used elsewhere in the graph).
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from typing import Any, Protocol

import httpx

from app.config import get_settings


class SplunkClient(Protocol):
    """Minimal interface real and fake Splunk clients both satisfy."""

    def poll_new_errors(self, since: datetime | None) -> list[dict[str, Any]]: ...

    def fetch_log_window(
        self, txn_id: str, system: str, occurred_at: datetime | None = None, session_id: str = ""
    ) -> list[dict[str, Any]]: ...


class SplunkRestClient:
    """Real client — runs SPL searches against the Splunk REST Search API."""

    def __init__(self, base_url: str | None = None, token: str | None = None) -> None:
        settings = get_settings()
        self._base_url = (base_url or settings.splunk_search_url).rstrip("/")
        self._token = settings.splunk_search_token if token is None else token
        self._username = settings.splunk_search_username
        self._password = settings.splunk_search_password
        self._query = settings.splunk_search_query
        self._verify_ssl = settings.splunk_verify_ssl
        self._index = settings.splunk_index

    def _run_search(self, spl: str) -> list[dict[str, Any]]:
        """Run a oneshot SPL search and return result rows as dicts."""
        if not self._base_url or not (
            self._token or (self._username and self._password)
        ):
            raise RuntimeError("Splunk Search URL and a token or username/password are required")
        # Keep bearer support for Cloud/Enterprise; use basic auth for local Enterprise.
        headers = {"Authorization": f"Bearer {self._token}"} if self._token else {}
        auth = None if self._token else httpx.BasicAuth(self._username, self._password)
        with httpx.Client(base_url=self._base_url, timeout=30.0, verify=self._verify_ssl) as client:
            response = client.post(
                "/services/search/jobs",
                headers=headers,
                auth=auth,
                data={"search": spl, "output_mode": "json", "exec_mode": "oneshot"},
            )
            response.raise_for_status()
            payload = response.json()
            if any(
                message.get("type") in {"ERROR", "FATAL"} for message in payload.get("messages", [])
            ):
                raise RuntimeError("Splunk rejected the search; check its query and permissions")
            return payload.get("results", [])

    def poll_new_errors(self, since: datetime | None) -> list[dict[str, Any]]:
        # Overlap polling windows to tolerate indexing delays; persistent IDs deduplicate.
        earliest = str((since - timedelta(minutes=5)).timestamp()) if since else "-24h"
        spl = f"search {self._query} earliest={earliest} latest=now | sort 0 _time"
        return self._run_search(spl)

    def fetch_log_window(
        self, txn_id: str, system: str, occurred_at: datetime | None = None, session_id: str = ""
    ) -> list[dict[str, Any]]:
        center = occurred_at or datetime.now(UTC)
        start, end = (
            (center - timedelta(minutes=5)).timestamp(),
            (center + timedelta(minutes=5)).timestamp(),
        )
        correlation = (
            (
                f"(txn_id={json.dumps(txn_id)} OR orderNumber={json.dumps(txn_id)} "
                f"OR requestId={json.dumps(txn_id)})"
            )
            if txn_id
            else (f"(system={json.dumps(system)} OR application={json.dumps(system)})")
        )
        if session_id:
            # Capture selections before an order exists as well as API traffic.
            # Do not mix another order from the same browser into this window.
            session_clause = (
                f"(sessionId={json.dumps(session_id)} "
                f"(NOT orderNumber=* OR orderNumber={json.dumps(txn_id)}))"
            )
            correlation = f"({correlation} OR {session_clause})" if txn_id else session_clause
        spl = (
            f"search index={json.dumps(self._index)} earliest={start} latest={end} "
            f"{correlation} | sort 0 _time | head 200"
        )
        return self._run_search(spl)


_client: SplunkClient | None = None


def get_splunk_client() -> SplunkClient:
    """Cached Splunk client accessor — override via `set_splunk_client` in tests/dev."""
    global _client
    if _client is None:
        _client = SplunkRestClient()
    return _client


def set_splunk_client(client: SplunkClient | None) -> None:
    """Test/dev hook to inject a fake client (or reset to the real one)."""
    global _client
    _client = client

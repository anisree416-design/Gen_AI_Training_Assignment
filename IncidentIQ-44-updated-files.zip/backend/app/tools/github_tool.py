"""GitHub code-fix tool — branches, commits, and pushes fixes to the sample app.

Owner: Member 6. The fix target is a dedicated sample-app folder inside this
repo (see Settings.github_repo_path), so file reads are plain filesystem
reads — no GitHub API is needed to read code. Branch/commit/push use GitPython
against this repo's checked-out remote, authenticated via GITHUB_TOKEN.
"""

from __future__ import annotations

from dataclasses import dataclass

from app.config import REPO_ROOT, get_settings


@dataclass
class FixWrite:
    """One file to write as part of a fix, relative to `github_repo_path`."""

    path: str
    content: str


def read_file(relative_path: str) -> str:
    """Read a file from the fix-target sample app (local filesystem)."""
    settings = get_settings()
    full_path = settings.github_repo_path_resolved / relative_path
    return full_path.read_text(encoding="utf-8")


def create_fix_branch(
    branch_name: str, writes: list[FixWrite], commit_message: str
) -> dict[str, str]:
    """Create a branch off the current HEAD, write files, commit, and push it.

    Returns branch_name, commit_sha, and a best-effort branch_url derived from
    the remote URL. Restores the original branch checkout before returning.
    """
    from git import Repo

    settings = get_settings()
    repo = Repo(REPO_ROOT)

    original_branch = repo.active_branch
    new_branch = repo.create_head(branch_name, original_branch.commit)
    new_branch.checkout()

    remote = None
    push_status = "local"
    branch_url = ""
    try:
        repo_paths: list[str] = []
        for write in writes:
            full_path = settings.github_repo_path_resolved / write.path
            full_path.parent.mkdir(parents=True, exist_ok=True)
            full_path.write_text(write.content, encoding="utf-8")
            repo_path = full_path.relative_to(REPO_ROOT).as_posix()
            repo_paths.append(repo_path)
            repo.index.add([repo_path])

        # Commit only the generated files. Any unrelated staged user work remains
        # staged and cannot leak into an automatically prepared incident fix.
        repo.git.commit("--only", "-m", commit_message, "--", *repo_paths)
        commit = repo.head.commit

        try:
            remote = repo.remote(settings.github_remote_name)
            push_url = _authenticated_url(remote.url, settings.github_token)
            repo.git.push(push_url, f"{branch_name}:{branch_name}")
            push_status = "pushed"
            branch_url = _branch_url(remote.url, branch_name)
        except Exception:
            # The committed local branch remains reviewable when no remote/token is available.
            push_status = "local"
    finally:
        original_branch.checkout()

    return {
        "branch_name": branch_name,
        "commit_sha": commit.hexsha,
        "branch_url": branch_url,
        "push_status": push_status,
    }


def _authenticated_url(remote_url: str, token: str) -> str:
    if token and remote_url.startswith("https://") and "@" not in remote_url:
        return remote_url.replace("https://", f"https://{token}@", 1)
    return remote_url


def _branch_url(remote_url: str, branch_name: str) -> str:
    if remote_url.endswith(".git"):
        remote_url = remote_url[: -len(".git")]
    if remote_url.startswith("git@github.com:"):
        remote_url = "https://github.com/" + remote_url[len("git@github.com:") :]
    return f"{remote_url}/tree/{branch_name}"

"""Analyze candidate source files and propose one evidence-grounded code fix."""

import difflib
import json
from dataclasses import dataclass

from app.llm.client import get_chat_model, strip_code_fences, with_retries
from app.tools.code_search import CodeCandidate

SYSTEM_PROMPT = """You are a production code-fix agent. Select the relevant supplied file and
return the smallest safe correction for the observed application failure. Treat the incident as
real. Never mention, change, disable, or rely on demo flags, injected-error switches, seed setup,
or environment configuration. Do not invent a cause absent from the RCA and code. Return strict
JSON: {"file_path": str, "fixed_content": str, "explanation": str}."""


@dataclass
class ProposedFix:
    file_path: str
    before_code: str
    after_code: str
    diff: str
    explanation: str


def propose_fix(rca: dict, event: dict, candidates: list[CodeCandidate]) -> ProposedFix:
    if not candidates:
        raise FileNotFoundError("No source files were found in the configured fix target.")
    payload = {
        "root_cause_analysis": rca,
        "observed_error": event,
        "candidate_files": [{"path": item.path, "content": item.content} for item in candidates],
    }
    response = with_retries(get_chat_model().invoke)(
        [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload)},
        ]
    )
    proposed = json.loads(strip_code_fences(response.content))
    originals = {item.path: item.content for item in candidates}
    path = proposed.get("file_path", "")
    if path not in originals:
        raise ValueError("The fix agent selected a file outside the searched candidates.")
    after = proposed.get("fixed_content", "")
    if not after or after == originals[path]:
        raise ValueError("The fix agent did not produce a code change.")
    diff = "".join(
        difflib.unified_diff(
            originals[path].splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
        )
    )
    return ProposedFix(path, originals[path], after, diff, proposed.get("explanation", ""))

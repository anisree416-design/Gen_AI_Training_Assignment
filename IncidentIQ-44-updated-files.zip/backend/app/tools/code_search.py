"""Search the configured fix target for code relevant to an incident RCA."""

import re
from dataclasses import dataclass

from app.config import get_settings

CODE_SUFFIXES = {".py", ".js", ".jsx", ".ts", ".tsx"}
IGNORED_TERMS = {"demo", "config", "error", "failed", "failure", "incident"}


@dataclass
class CodeCandidate:
    path: str
    content: str
    score: int


def search_code(root_cause: str, impacted_component: str, evidence: list[str], limit: int = 5):
    """Rank code files using component and RCA terms without executing repository code."""
    root = get_settings().github_repo_path_resolved
    query = " ".join([impacted_component, root_cause, *evidence])
    terms = {
        word.lower()
        for word in re.findall(r"[A-Za-z_][A-Za-z0-9_]{3,}", query)
        if word.lower() not in IGNORED_TERMS
    }
    candidates = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in CODE_SUFFIXES:
            continue
        content = path.read_text(encoding="utf-8", errors="replace")
        relative = path.relative_to(root).as_posix()
        haystack = f"{relative}\n{content}".lower()
        score = sum((4 if term in relative.lower() else 1) * haystack.count(term) for term in terms)
        candidates.append(CodeCandidate(relative, content, score))
    return sorted(candidates, key=lambda item: (-item.score, item.path))[:limit]

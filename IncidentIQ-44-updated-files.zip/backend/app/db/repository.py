"""Lightweight sqlite3-backed persistence for incidents/RCA/fix records.

Owner: Member 4/6. No ORM — plain sqlite3, one row per incident, nested
Pydantic models stored as JSON. Separate from the LangGraph checkpointer DB:
this one is for querying finished/in-flight incident records (e.g. from a UI),
not for graph-resume state.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.config import get_settings
from app.graph.state import ErrorEvent, FixResult, RCAResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents (
    incident_id TEXT PRIMARY KEY,
    error_event TEXT NOT NULL,
    rca TEXT,
    fix_result TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS processed_splunk_events (
    error_id TEXT PRIMARY KEY,
    incident_id TEXT NOT NULL,
    processed_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS analysis_runs (
    incident_id TEXT PRIMARY KEY,
    error_event TEXT NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    context TEXT,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS incident_groups (
    incident_number INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS incident_events (
    error_id TEXT PRIMARY KEY,
    incident_id TEXT NOT NULL,
    error_event TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS incident_events_group ON incident_events(incident_id);
"""


def save_analysis_status(incident_id, event, status, error=None, db_path=None):
    with _connect(db_path) as conn:
        conn.execute(
            """INSERT INTO analysis_runs (incident_id, error_event, status, error)
            VALUES (?, ?, ?, ?) ON CONFLICT(incident_id) DO UPDATE SET
            status=excluded.status, error=excluded.error, updated_at=CURRENT_TIMESTAMP""",
            (incident_id, event.model_dump_json(), status, error),
        )


def save_analysis_context(incident_id, event, logs, docs, db_path=None):
    context = {
        "logs": [entry.model_dump(mode="json") for bundle in logs for entry in bundle.entries],
        "documents": [doc.model_dump(mode="json") for doc in docs],
    }
    with _connect(db_path) as conn:
        conn.execute(
            """INSERT INTO analysis_runs (incident_id, error_event, status, context)
            VALUES (?, ?, 'analyzing', ?) ON CONFLICT(incident_id) DO UPDATE SET
            context=excluded.context, updated_at=CURRENT_TIMESTAMP""",
            (incident_id, event.model_dump_json(), json.dumps(context)),
        )


def read_analysis_runs(db_path=None):
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT incident_id, error_event, status, error, context, updated_at "
            "FROM analysis_runs ORDER BY updated_at DESC"
        ).fetchall()
    return [
        {
            "incident_id": row[0],
            "error_event": json.loads(row[1]),
            "status": row[2],
            "error": row[3],
            "context": json.loads(row[4]) if row[4] else None,
            "updated_at": row[5],
        }
        for row in rows
    ]


@contextmanager
def _connect(db_path: str | Path | None = None):
    path = Path(db_path) if db_path else get_settings().app_db_path_resolved
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    try:
        conn.executescript(SCHEMA)
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(db_path: str | Path | None = None) -> None:
    """Create the incidents table if it doesn't exist yet."""
    with _connect(db_path):
        pass


def record_incident_event(incident_id, event, db_path=None):
    """Persist every constituent error before analysis, including delayed telemetry."""
    with _connect(db_path) as conn:
        conn.execute(
            "INSERT INTO incident_groups (incident_id) SELECT ? "
            "WHERE NOT EXISTS (SELECT 1 FROM incident_groups WHERE incident_id = ?)",
            (incident_id, incident_id),
        )
        cursor = conn.execute(
            "INSERT OR IGNORE INTO incident_events VALUES (?, ?, ?)",
            (event.error_id, incident_id, event.model_dump_json()),
        )
    return cursor.rowcount == 1


def read_incident_events(incident_id=None, db_path=None):
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT error_event FROM incident_events"
            + (" WHERE incident_id = ?" if incident_id else ""),
            (incident_id,) if incident_id else (),
        ).fetchall()
    events = [ErrorEvent.model_validate_json(row[0]) for row in rows]
    return sorted(events, key=lambda event: event.occurred_at or datetime.min.replace(tzinfo=UTC))


def incident_numbers(incident_ids, db_path=None):
    with _connect(db_path) as conn:
        conn.executemany(
            "INSERT INTO incident_groups (incident_id) SELECT ? "
            "WHERE NOT EXISTS (SELECT 1 FROM incident_groups WHERE incident_id = ?)",
            [(value, value) for value in incident_ids],
        )
        return dict(conn.execute("SELECT incident_id, incident_number FROM incident_groups"))


def delete_incidents(incident_ids=None, db_path=None):
    """Delete visible incident data while retaining processed-event deduplication."""
    with _connect(db_path) as conn:
        if incident_ids is None:
            count = conn.execute(
                "SELECT COUNT(*) FROM incident_groups"
            ).fetchone()[0]
            for table in ("incidents", "analysis_runs", "incident_events", "incident_groups"):
                conn.execute(f"DELETE FROM {table}")
            return count

        ids = list(dict.fromkeys(incident_ids))
        if not ids:
            return 0
        placeholders = ",".join("?" for _ in ids)
        count = conn.execute(
            f"SELECT COUNT(*) FROM incident_groups WHERE incident_id IN ({placeholders})",
            ids,
        ).fetchone()[0]
        for table in ("incidents", "analysis_runs", "incident_events", "incident_groups"):
            conn.execute(f"DELETE FROM {table} WHERE incident_id IN ({placeholders})", ids)
        return count


def save_rca(
    incident_id: str, error_event: ErrorEvent, rca: RCAResult, db_path: str | Path | None = None
) -> None:
    """Insert or update an incident's error event + RCA."""
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO incidents (incident_id, error_event, rca)
            VALUES (?, ?, ?)
            ON CONFLICT(incident_id) DO UPDATE SET
                error_event = excluded.error_event,
                rca = excluded.rca,
                updated_at = CURRENT_TIMESTAMP
            """,
            (incident_id, error_event.model_dump_json(), rca.model_dump_json()),
        )


def save_fix_result(
    incident_id: str, fix_result: FixResult, db_path: str | Path | None = None
) -> None:
    """Attach the code-fix outcome to an existing incident record."""
    with _connect(db_path) as conn:
        conn.execute(
            """
            UPDATE incidents
            SET fix_result = ?, updated_at = CURRENT_TIMESTAMP
            WHERE incident_id = ?
            """,
            (fix_result.model_dump_json(), incident_id),
        )


def is_event_processed(error_id: str, db_path: str | Path | None = None) -> bool:
    """Return whether a Splunk error has already reached the approval stage."""
    with _connect(db_path) as conn:
        row = conn.execute(
            "SELECT 1 FROM processed_splunk_events WHERE error_id = ?",
            (error_id,),
        ).fetchone()
    return row is not None


def mark_event_processed(
    error_id: str, incident_id: str, db_path: str | Path | None = None
) -> bool:
    """Persist a processed Splunk error, returning True only for the first insert."""
    with _connect(db_path) as conn:
        cursor = conn.execute(
            """
            INSERT OR IGNORE INTO processed_splunk_events (error_id, incident_id)
            VALUES (?, ?)
            """,
            (error_id, incident_id),
        )
    return cursor.rowcount == 1


def get_incident(incident_id: str, db_path: str | Path | None = None) -> dict[str, Any] | None:
    """Fetch one incident record as a dict of parsed models, or None if missing."""
    with _connect(db_path) as conn:
        row = conn.execute(
            "SELECT incident_id, error_event, rca, fix_result, created_at, updated_at "
            "FROM incidents WHERE incident_id = ?",
            (incident_id,),
        ).fetchone()
    return _row_to_dict(row) if row else None


def list_incidents(db_path: str | Path | None = None) -> list[dict[str, Any]]:
    """Fetch all incident records, most recently updated first."""
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT incident_id, error_event, rca, fix_result, created_at, updated_at "
            "FROM incidents ORDER BY updated_at DESC"
        ).fetchall()
    return [_row_to_dict(row) for row in rows]


def _row_to_dict(row: tuple) -> dict[str, Any]:
    incident_id, error_event_json, rca_json, fix_result_json, created_at, updated_at = row
    return {
        "incident_id": incident_id,
        "error_event": ErrorEvent.model_validate_json(error_event_json),
        "rca": RCAResult.model_validate_json(rca_json) if rca_json else None,
        "fix_result": FixResult.model_validate_json(fix_result_json) if fix_result_json else None,
        "created_at": created_at,
        "updated_at": updated_at,
    }

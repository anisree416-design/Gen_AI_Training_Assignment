"""Persistent, transaction-safe numbering and demo payment receipts."""

import json
import os
import sqlite3
from pathlib import Path

DB_PATH = Path(
    os.environ.get("POS_ORDER_DB", Path(__file__).resolve().parents[2] / "orders.sqlite")
)


def connect():
    connection = sqlite3.connect(DB_PATH, timeout=15)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS order_sequence "
        "(id INTEGER PRIMARY KEY CHECK(id=1), next_number INTEGER NOT NULL)"
    )
    connection.execute("INSERT OR IGNORE INTO order_sequence VALUES (1, 999048)")
    connection.execute(
        "CREATE TABLE IF NOT EXISTS pos_orders "
        "(number INTEGER PRIMARY KEY, request_key TEXT UNIQUE, session_token TEXT, "
        "receipt TEXT, items TEXT NOT NULL DEFAULT '{}', suspended INTEGER NOT NULL DEFAULT 0)"
    )
    columns = {row[1] for row in connection.execute("PRAGMA table_info(pos_orders)").fetchall()}
    if "items" not in columns:
        connection.execute("ALTER TABLE pos_orders ADD COLUMN items TEXT NOT NULL DEFAULT '{}'")
    if "suspended" not in columns:
        connection.execute("ALTER TABLE pos_orders ADD COLUMN suspended INTEGER NOT NULL DEFAULT 0")
    connection.commit()
    return connection


def allocate(connection, request_key, token):
    if request_key:
        existing = connection.execute(
            "SELECT number FROM pos_orders WHERE request_key=?", (request_key,)
        ).fetchone()
        if existing:
            return existing[0]
    number = connection.execute("SELECT next_number FROM order_sequence WHERE id=1").fetchone()[0]
    connection.execute("UPDATE order_sequence SET next_number=next_number+1 WHERE id=1")
    connection.execute(
        "INSERT INTO pos_orders(number, request_key, session_token) VALUES (?, ?, ?)",
        (number, request_key, token),
    )
    return number


def start_order(request_key, token):
    connection = connect()
    try:
        with connection:
            connection.execute("BEGIN IMMEDIATE")
            return allocate(connection, request_key, token)
    finally:
        connection.close()


def has_active_order(token):
    connection = connect()
    try:
        return (
            connection.execute(
                "SELECT 1 FROM pos_orders WHERE session_token=? AND receipt IS NULL "
                "AND suspended=0 LIMIT 1",
                (token,),
            ).fetchone()
            is not None
        )
    finally:
        connection.close()


def suspend_order(number, token):
    """End an in-progress order without payment, freeing the register to start a new one."""
    connection = connect()
    try:
        with connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT receipt, suspended FROM pos_orders WHERE number=?", (number,)
            ).fetchone()
            if row is None:
                raise ValueError("Order not found.")
            receipt, suspended = row
            if receipt:
                raise ValueError("Order is already paid and cannot be suspended.")
            if not suspended:
                connection.execute("UPDATE pos_orders SET suspended=1 WHERE number=?", (number,))
    finally:
        connection.close()


def force_suspend_order(number):
    """Suspend any order number as a register-recovery operation.

    Ownership, payment and current-session state intentionally do not block this
    operation. If local browser state references a number missing from the store,
    persist a suspended placeholder and advance the sequence past it.
    """
    connection = connect()
    try:
        with connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT 1 FROM pos_orders WHERE number=?", (number,)
            ).fetchone()
            if row is None:
                connection.execute(
                    "INSERT INTO pos_orders(number, session_token, suspended) VALUES (?, NULL, 1)",
                    (number,),
                )
                connection.execute(
                    "UPDATE order_sequence SET next_number=? WHERE id=1 AND next_number<=?",
                    (number + 1, number),
                )
            else:
                connection.execute(
                    "UPDATE pos_orders SET suspended=1 WHERE number=?", (number,)
                )
    finally:
        connection.close()


def complete_order(number, receipt, token):
    connection = connect()
    try:
        with connection:
            connection.execute("BEGIN IMMEDIATE")
            if number is None:
                number = allocate(connection, None, token)
            row = connection.execute(
                "SELECT receipt FROM pos_orders WHERE number=?", (number,)
            ).fetchone()
            if row is None:
                raise ValueError("Order not found. Return to the cart and try again.")
            if row[0]:
                return json.loads(row[0])
            receipt = {**receipt, "order_number": number, "order_id": f"POS-{number}"}
            connection.execute(
                "UPDATE pos_orders SET receipt=? WHERE number=?", (json.dumps(receipt), number)
            )
            return receipt
    finally:
        connection.close()


def add_item(number, product_id, quantity, token):
    """Add (or increase) a line item on an in-progress order. Server is the source of truth."""
    connection = connect()
    try:
        with connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT items, session_token, receipt, suspended FROM pos_orders WHERE number=?",
                (number,),
            ).fetchone()
            if row is None:
                raise ValueError("Order not found. Start a new order and try again.")
            items_json, session_token, receipt, suspended = row
            if receipt:
                raise ValueError("Order is already paid. Start a new order to add items.")
            if suspended:
                raise ValueError("Order was suspended. Start a new order to add items.")
            if session_token != token:
                raise ValueError("Order does not belong to this session.")
            items = json.loads(items_json or "{}")
            items[product_id] = min(items.get(product_id, 0) + quantity, 99)
            connection.execute(
                "UPDATE pos_orders SET items=? WHERE number=?", (json.dumps(items), number)
            )
            return items
    finally:
        connection.close()


def get_order_items(number):
    connection = connect()
    try:
        row = connection.execute(
            "SELECT items FROM pos_orders WHERE number=?", (number,)
        ).fetchone()
        if row is None:
            raise ValueError("Order not found.")
        return json.loads(row[0] or "{}")
    finally:
        connection.close()

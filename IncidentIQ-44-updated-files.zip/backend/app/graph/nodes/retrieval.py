"""Retrieval node — fetch the surrounding log window from Splunk.

Owner: Member 2. Calls `app.tools.splunk_query` for the log window around the
error's transaction id and system, then folds in the structured
log-bundling job that used to live in a separate log_analysis node.

Consumes: state.error_event
Produces: retrieved_logs, events
"""

from datetime import UTC, datetime

from app.db.repository import read_incident_events
from app.graph.state import IncidentState, LogBundle, LogEntry, make_event
from app.services.incident_correlation import evidence_metadata
from app.services.splunk_normalizer import _event_fields, _parse_timestamp
from app.tools.splunk_query import get_splunk_client


def retrieval(state: IncidentState) -> dict:
    """Retrieve the log slice for the error's system/transaction and time window."""
    error_event = state.error_event
    system = error_event.system if error_event else "unknown"
    txn_id = error_event.txn_id if error_event else ""
    session_id = _event_fields(error_event.raw).get("sessionId") if error_event else None

    rows = (
        get_splunk_client().fetch_log_window(
            txn_id=txn_id,
            system=system,
            occurred_at=error_event.occurred_at,
            **({"session_id": session_id} if session_id else {}),
        )
        if error_event
        else []
    )
    rows = [_event_fields(row) for row in rows]
    # Include errors already observed even when Splunk's context search has not
    # indexed them yet. Request/response fields are retained for the RCA and UI.
    known = {str(row.get("_cd")) for row in rows if row.get("_cd")}
    for event in read_incident_events(state.incident_id):
        fields = _event_fields(event.raw)
        if not fields.get("_cd") or str(fields["_cd"]) not in known:
            rows.append(fields)

    now = datetime.now(UTC)
    entries = [
        LogEntry(
            timestamp=_parse_timestamp(row.get("_time") or row.get("timestamp")),
            level=row.get("level", row.get("status", "")),
            service=row.get("system", row.get("application", system)),
            message=row.get("message", ""),
            txn_id=row.get("txn_id", txn_id),
            metadata=evidence_metadata(row),
        )
        for row in rows
    ] or [
        LogEntry(
            timestamp=now,
            level="ERROR",
            service=system,
            message=error_event.message if error_event else "no log window available",
            txn_id=txn_id,
        )
    ]
    entries.sort(key=lambda entry: entry.timestamp or datetime.min.replace(tzinfo=UTC))

    bundle = LogBundle(
        service=system,
        query=f'system="{system}" txn_id="{txn_id}"',
        start_time=now,
        end_time=now,
        entries=entries,
    )
    return {
        "retrieved_logs": [bundle],
        "events": [
            make_event("retrieval", f"retrieved {len(bundle.entries)} log entries for {system}")
        ],
    }

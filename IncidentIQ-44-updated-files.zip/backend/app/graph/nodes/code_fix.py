"""Generate a reviewable fix from code search, then create a dedicated branch."""

from datetime import UTC, datetime

from app.db.repository import save_fix_result
from app.graph.state import FixResult, IncidentState, RCAResult, make_event
from app.services.incident_presentation import operational_rca
from app.tools.code_search import search_code
from app.tools.github_tool import FixWrite, create_fix_branch
from app.tools.issue_fix import propose_fix


def code_fix(state: IncidentState) -> dict:
    if not state.rca or not state.error_event:
        result = FixResult(status="failed", summary="No RCA is available to fix.")
        return {"fix_result": result, "events": [make_event("code_fix", result.summary)]}

    try:
        event = state.error_event.model_dump(mode="json", exclude={"raw"})
        clean_rca = operational_rca(state.rca.model_dump(mode="json"), event)
        grounded = RCAResult.model_validate(clean_rca)
        candidates = search_code(
            grounded.root_cause,
            grounded.impacted_component,
            grounded.evidence,
        )
        proposed = propose_fix(grounded.model_dump(mode="json"), event, candidates)
        timestamp = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
        branch_name = f"fix/{state.incident_id.lower()}-{timestamp}"
        branch = create_fix_branch(
            branch_name,
            [FixWrite(path=proposed.file_path, content=proposed.after_code)],
            f"Fix {state.incident_id}: {grounded.summary or grounded.root_cause}",
        )
        result = FixResult(
            status="created",
            branch_name=branch["branch_name"],
            branch_url=branch.get("branch_url", ""),
            commit_sha=branch["commit_sha"],
            files_changed=[proposed.file_path],
            summary=proposed.explanation,
            before_code=proposed.before_code,
            after_code=proposed.after_code,
            diff=proposed.diff,
            push_status=branch.get("push_status", "local"),
        )
    except Exception as exc:
        result = FixResult(status="failed", summary=f"Fix generation failed: {exc}")

    if state.incident_id:
        save_fix_result(state.incident_id, result)
    return {
        "fix_result": result,
        "events": [make_event("code_fix", result.summary)],
    }

"""IncidentState — the team-wide contract every node reads and writes.

Owner: Member 1 (orchestration & routing). Changing a field here affects everyone;
propose changes via the graph-contract doc (docs/architecture/graph-contract.md).

Sub-models live here for now so the contract is self-contained. Member 4 may later
promote shared models into app/schemas/ — state.py would then import from there.
"""

import operator
from datetime import UTC, datetime
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field


class ErrorEvent(BaseModel):
    """Normalized Splunk error event produced by the intake node — the run's entrypoint."""

    error_id: str
    source: str = "splunk"
    severity: Literal["critical", "high", "medium", "low"] = "high"
    system: str = ""
    host: str = ""
    event: str = ""
    error_code: str = ""
    message: str = ""
    txn_id: str = ""
    occurred_at: datetime | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


class LogEntry(BaseModel):
    """A single log line (unified envelope, shared txn_id)."""

    timestamp: datetime | None = None
    level: str = ""
    service: str = ""
    message: str
    txn_id: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class LogBundle(BaseModel):
    """Log slice retrieved for a service/time window (Splunk retrieval)."""

    source: str = "splunk"
    service: str
    query: str = ""
    start_time: datetime | None = None
    end_time: datetime | None = None
    entries: list[LogEntry] = Field(default_factory=list)


class ErrorDoc(BaseModel):
    """A chunk retrieved from the in-memory error-documentation collection (RAG)."""

    doc_id: str
    content: str
    similarity: float = Field(ge=0.0, le=1.0)
    source_section: str = ""


class RCAResult(BaseModel):
    """Evidence-backed root-cause analysis."""

    root_cause: str
    contributing_factors: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
    evidence_ids: list[str] = Field(default_factory=list)
    impacted_component: str = ""
    severity: Literal["critical", "high", "medium", "low"] = "medium"
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    recommended_action: str = ""
    summary: str = ""
    sequence_of_events: list[str] = Field(default_factory=list)


class ApprovalDecision(BaseModel):
    """Human-gate decision recorded at the approval interrupt (the FIX button)."""

    status: Literal["pending", "approved", "rejected"]
    reviewer: str = ""
    note: str = ""
    decided_at: datetime | None = None


class FixResult(BaseModel):
    """Outcome of the automated code-fix flow (branch/commit created after approval)."""

    status: Literal["created", "failed", "none"] = "none"
    branch_name: str = ""
    branch_url: str = ""
    commit_sha: str = ""
    files_changed: list[str] = Field(default_factory=list)
    summary: str = ""
    before_code: str = ""
    after_code: str = ""
    diff: str = ""
    push_status: str = ""


class NodeEvent(BaseModel):
    """Audit-trace entry appended by every node; powers the UI run timeline."""

    node: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    detail: str = ""


def make_event(node: str, detail: str = "") -> NodeEvent:
    """Standard audit event every node appends to state["events"]."""
    return NodeEvent(node=node, detail=detail)


class IncidentState(BaseModel):
    """The single state object flowing through the IncidentIQ graph.

    Nodes return *partial* updates (plain dicts keyed by field name). Fields
    annotated with `operator.add` merge across parallel branches; everything
    else takes the last write.
    """

    # Identity
    incident_id: str = ""

    # Intake (Splunk poller) → Retrieval
    error_event: ErrorEvent | None = None
    retrieved_logs: list[LogBundle] = Field(default_factory=list)

    # RAG over the in-memory error-documentation collection → RCA
    similar_error_docs: list[ErrorDoc] = Field(default_factory=list)
    rca: RCAResult | None = None

    # Human gate (FIX button) → automated code fix
    approval: ApprovalDecision | None = None
    fix_result: FixResult | None = None

    # Cross-cutting (append-only, parallel-safe)
    errors: Annotated[list[str], operator.add] = Field(default_factory=list)
    events: Annotated[list[NodeEvent], operator.add] = Field(default_factory=list)

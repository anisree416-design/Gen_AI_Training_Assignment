"""In-memory ChromaDB store for the error-documentation collection.

Owner: Member 5. The collection is always rebuilt from the error-docs text
file (see `app.rag.ingest`) — nothing is persisted to disk, so every restart
reloads the current file contents fresh.
"""

from __future__ import annotations

from functools import lru_cache

import chromadb
from chromadb.config import Settings
from chromadb.utils.embedding_functions import ONNXMiniLM_L6_V2

COLLECTION_NAME = "error_docs"


@lru_cache(maxsize=1)
def get_embedding_function():
    return ONNXMiniLM_L6_V2()


@lru_cache(maxsize=1)
def get_chroma_client() -> chromadb.ClientAPI:
    """Process-wide in-memory Chroma client (ephemeral — no disk persistence)."""
    return chromadb.EphemeralClient(settings=Settings(anonymized_telemetry=False))


def get_error_docs_collection():
    """Get (or lazily create) the in-memory error-documentation collection."""
    client = get_chroma_client()
    return client.get_or_create_collection(
        COLLECTION_NAME, embedding_function=get_embedding_function()
    )


def reset_error_docs_collection():
    """Drop and recreate the collection — call before re-ingesting fresh content."""
    client = get_chroma_client()
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:  # chromadb raises if the collection doesn't exist yet
        pass
    return client.create_collection(COLLECTION_NAME, embedding_function=get_embedding_function())

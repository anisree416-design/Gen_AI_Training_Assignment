"""Ingestion of the error-documentation text file into the in-memory Chroma collection.

Owner: Member 5. `ingest_error_docs()` re-reads the source text file and
reloads the collection from scratch every time it's called — call it once at
app startup so every restart reflects the file's current contents, per the
"always rebuild in-memory, never persist" requirement.
"""

from __future__ import annotations

import hashlib

from app.config import get_settings
from app.rag.store import reset_error_docs_collection

CHUNK_DELIMITER = "\n---\n"


def chunk_error_docs(text: str) -> list[str]:
    """Split the error-doc file into one chunk per '---'-delimited entry."""
    return [chunk.strip() for chunk in text.split(CHUNK_DELIMITER) if chunk.strip()]


def ingest_error_docs() -> int:
    """Reload the error-documentation collection from the source text file.

    Returns the number of chunks ingested. Safe to call repeatedly (e.g. on
    every app startup) — always rebuilds the in-memory collection from scratch.
    """
    path = get_settings().error_docs_path_resolved
    if not path.exists():
        return 0

    chunks = chunk_error_docs(path.read_text(encoding="utf-8"))
    if not chunks:
        return 0

    collection = reset_error_docs_collection()
    chunks = list(dict.fromkeys(chunks))
    collection.add(
        ids=["error-doc-" + hashlib.sha256(chunk.encode()).hexdigest()[:16] for chunk in chunks],
        documents=chunks,
    )
    return len(chunks)

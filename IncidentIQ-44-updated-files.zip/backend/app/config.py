"""Application settings for IncidentIQ (env-driven, see root .env.example)."""

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent  # backend/
REPO_ROOT = BASE_DIR.parent


class Settings(BaseSettings):
    """Environment-driven configuration."""

    model_config = SettingsConfigDict(
        env_file=REPO_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # LLM provider (OpenAI-compatible API — Codex key)
    openai_api_key: str = ""
    openai_base_url: str | None = None
    openai_model: str = "gpt-5-codex"


    # Application
    incidentiq_env: str = "development"
    log_level: str = "INFO"

    # Storage paths — relative values resolve against the repo root
    checkpoint_db_path: Path = Path("backend/checkpoints.sqlite")
    app_db_path: Path = Path("backend/app.sqlite3")
    data_dir: Path = Path("data")
    error_docs_path: Path = Path("data/knowledge/error_docs.txt")

    # RAG (in-memory ChromaDB, rebuilt from error_docs_path on every startup —
    # never persisted to disk)
    rag_top_k: int = Field(default=5, ge=1)

    # Splunk (real REST Search API polling — no Slack layer for this POC)
    splunk_hec_url: str = ""
    splunk_hec_token: str = ""
    splunk_index: str = "incidentiq"
    splunk_environment: str = "DEMO"
    splunk_request_channel: str = ""

    splunk_search_url: str = ""
    splunk_search_token: str = ""
    splunk_search_username: str = ""
    splunk_search_password: str = Field(default="", repr=False)
    splunk_search_query: str = "index=incidentiq (level=ERROR OR status=ERROR)"
    splunk_poll_interval_seconds: int = Field(default=2, ge=1)
    splunk_verify_ssl: bool = True

    @property
    def pipeline_missing_settings(self) -> list[str]:
        """Required configuration for either token or Enterprise basic authentication."""
        missing = []
        if not self.splunk_search_url:
            missing.append("SPLUNK_SEARCH_URL")
        if not (
            self.splunk_search_token
            or (self.splunk_search_username and self.splunk_search_password)
        ):
            missing.append(
                "SPLUNK_SEARCH_TOKEN or (SPLUNK_SEARCH_USERNAME and SPLUNK_SEARCH_PASSWORD)"
            )
        if not self.openai_api_key:
            missing.append("OPENAI_API_KEY")
        return missing

    # GitHub code-fix tool — fix target is a dedicated sample-app folder in
    # this repo (never backend/ or frontend/), so demo pushes stay scoped.
    github_token: str = ""
    github_repo_path: Path = Path("data/sample_app")
    github_remote_name: str = "origin"

    def resolve_path(self, value: Path) -> Path:
        """Resolve a configured path against the repo root when relative."""
        return value if value.is_absolute() else REPO_ROOT / value

    @property
    def checkpoint_path(self) -> Path:
        return self.resolve_path(self.checkpoint_db_path)

    @property
    def app_db_path_resolved(self) -> Path:
        return self.resolve_path(self.app_db_path)

    @property
    def data_path(self) -> Path:
        return self.resolve_path(self.data_dir)

    @property
    def error_docs_path_resolved(self) -> Path:
        return self.resolve_path(self.error_docs_path)

    @property
    def github_repo_path_resolved(self) -> Path:
        return self.resolve_path(self.github_repo_path)


@lru_cache
def get_settings() -> Settings:
    """Cached settings accessor (clear with get_settings.cache_clear() in tests)."""
    return Settings()

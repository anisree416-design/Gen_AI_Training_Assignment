import asyncio
from contextlib import asynccontextmanager, suppress
from datetime import UTC, datetime
from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes.incidents import router as incidents_router
from app.api.routes.pos import router as pos_router
from app.db.repository import init_db
from app.graph.builder import build_graph
from app.graph.checkpointer import get_checkpointer
from app.rag.ingest import ingest_error_docs
from app.services.splunk_poller import run_splunk_poller
from app.telemetry import forwarder
from app.telemetry import router as telemetry_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize and own the process-wide IncidentIQ runtime resources."""
    init_db()
    error_doc_count = ingest_error_docs()
    if error_doc_count <= 0:
        raise RuntimeError("No RAG error-document chunks were loaded during startup")

    checkpointer = get_checkpointer()
    graph = build_graph(checkpointer=checkpointer)
    stop_event = asyncio.Event()
    poller_task = asyncio.create_task(
        run_splunk_poller(graph, stop_event),
        name="incidentiq-splunk-poller",
    )

    app.state.database_ready = True
    app.state.error_doc_count = error_doc_count
    app.state.checkpointer = checkpointer
    app.state.graph = graph
    app.state.poller_stop_event = stop_event
    app.state.poller_task = poller_task

    try:
        yield
    finally:
        stop_event.set()
        try:
            await asyncio.wait_for(asyncio.shield(poller_task), timeout=2.0)
        except TimeoutError:
            poller_task.cancel()
            with suppress(asyncio.CancelledError):
                await poller_task
        except asyncio.CancelledError:
            pass
        checkpointer.conn.close()


app = FastAPI(title="Keele POS API", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(pos_router)
app.include_router(incidents_router)
app.include_router(telemetry_router)


def submit_backend_log(event: dict) -> None:
    """Never allow observability failures to affect a business API request."""
    try:
        forwarder.submit([event])
    except Exception:
        pass


@app.middleware("http")
async def log_backend_api(request: Request, call_next):
    """Log every backend API call without recursively logging telemetry ingestion."""
    if request.url.path.startswith(
        ("/api/telemetry", "/api/incidents", "/api/pipeline", "/api/health")
    ):
        return await call_next(request)

    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    order_number_header = request.headers.get("X-Order-Number")
    try:
        order_number = int(order_number_header) if order_number_header else None
    except ValueError:
        order_number = None
    started = perf_counter()
    common = {
        "application": "incidentiq_backend",
        "environment": "DEMO",
        "requestId": request_id,
        "sessionId": request.headers.get("X-Session-ID", ""),
        "orderNumber": order_number,
        "method": request.method,
        "path": request.url.path,
        "clientIp": request.client.host if request.client else None,
        "timestamp": datetime.now(UTC).isoformat(),
    }
    submit_backend_log(
        {
            **common,
            "eventType": "BACKEND_API_REQUEST",
            "status": "STARTED",
            "message": f"{request.method} {request.url.path} request received by backend",
        }
    )

    try:
        response = await call_next(request)
    except Exception as exc:
        duration_ms = round((perf_counter() - started) * 1000)
        submit_backend_log(
            {
                **common,
                "eventType": "BACKEND_API_ERROR",
                "status": "ERROR",
                "message": f"{request.method} {request.url.path} failed in backend: {exc}",
                "durationMs": duration_ms,
                "errorType": type(exc).__name__,
            }
        )
        raise

    duration_ms = round((perf_counter() - started) * 1000)
    status = "SUCCESS" if response.status_code < 400 else "ERROR"
    submit_backend_log(
        {
            **common,
            "eventType": "BACKEND_API_RESPONSE",
            "status": status,
            "message": (
                f"{request.method} {request.url.path} completed with HTTP "
                f"{response.status_code} in {duration_ms} ms"
            ),
            "httpStatus": response.status_code,
            "durationMs": duration_ms,
        }
    )
    response.headers["X-Request-ID"] = request_id
    return response


@app.get("/api/health")
def health(request: Request):
    poller_task = getattr(request.app.state, "poller_task", None)
    if poller_task is None:
        poller_status = "not_started"
    elif poller_task.cancelled():
        poller_status = "stopped"
    elif poller_task.done():
        poller_status = "failed" if poller_task.exception() else "stopped"
    else:
        poller_status = "running"

    return {
        "status": "ok",
        "database": "ready" if getattr(request.app.state, "database_ready", False) else "not_ready",
        "graph": "ready" if getattr(request.app.state, "graph", None) is not None else "not_ready",
        "rag_documents": getattr(request.app.state, "error_doc_count", 0),
        "splunk_poller": poller_status,
    }

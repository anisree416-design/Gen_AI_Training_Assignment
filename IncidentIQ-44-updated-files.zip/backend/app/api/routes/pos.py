from datetime import UTC, datetime
from decimal import ROUND_HALF_UP, Decimal
from secrets import token_urlsafe

from fastapi import APIRouter, Depends, Header, HTTPException

from app import order_store
from app.demo_errors import (
    CARD_PAYMENT_ERROR_PRODUCT_ID,
    CHECKOUT_ERROR_PRODUCT_ID,
    PLU_LOOKUP_ERROR_PLU,
    get_demo_errors,
)
from app.schemas.pos import (
    AddItemRequest,
    CheckoutRequest,
    LoginRequest,
    PaymentRequest,
    StartOrderRequest,
)

router = APIRouter(prefix="/api", tags=["pos"])

TAX_RATE = Decimal("0.08")
PRODUCTS = [
    {
        "id": product_id,
        "plu": plu,
        "name": name,
        "category": category,
        "price_cents": price_cents,
        "unit": unit,
        "emoji": emoji,
        "color": color,
    }
    for product_id, plu, name, category, price_cents, unit, emoji, color in [
        ("p1", "4011", "Organic Bananas", "Produce", 249, "bunch", "🍌", "#fff2d7"),
        ("p2", "3028", "Fresh Avocados", "Produce", 199, "each", "🥑", "#e4f3d8"),
        ("p3", "1072", "Sourdough Bread", "Bakery", 649, "loaf", "🍞", "#f5e9d9"),
        ("p4", "2045", "Whole Milk", "Dairy", 429, "gallon", "🥛", "#e7f0f9"),
        ("p5", "5510", "Free Range Eggs", "Dairy", 599, "dozen", "🥚", "#f6eadd"),
        ("p6", "6074", "Strawberries", "Produce", 499, "pack", "🍓", "#fde3e4"),
        ("p7", "4390", "Baby Spinach", "Produce", 349, "bag", "🥬", "#e6f1df"),
        ("p8", "8921", "Ground Coffee", "Pantry", 1299, "bag", "☕", "#ede4da"),
        ("p9", "6233", "Orange Juice", "Drinks", 549, "bottle", "🍊", "#fff0d9"),
        ("p10", "7442", "Greek Yogurt", "Dairy", 179, "cup", "🥣", "#e9eefa"),
        ("p11", "8138", "Dark Chocolate", "Snacks", 399, "bar", "🍫", "#ede3db"),
        ("p12", "9306", "Sparkling Water", "Drinks", 199, "can", "💧", "#dff2f3"),
        ("p13", "4130", "Honeycrisp Apples", "Produce", 129, "each", "🍎", "#fbe5e8"),
        ("p14", "4664", "Vine Tomatoes", "Produce", 249, "pack", "🍅", "#fceddf"),
        ("p15", "4562", "Fresh Carrots", "Produce", 199, "bunch", "🥕", "#fff0df"),
    ]
]

_sessions: set[str] = set()


def require_cashier(authorization: str | None = Header(default=None)) -> str:
    token = authorization.removeprefix("Bearer ") if authorization else ""
    if token not in _sessions:
        raise HTTPException(status_code=401, detail="Please sign in to continue.")
    return token


def calculate(lines: list) -> dict:
    products = {product["id"]: product for product in PRODUCTS}
    merged: dict[str, int] = {}
    for line in lines:
        if line.product_id not in products:
            raise HTTPException(status_code=400, detail=f"Unknown product: {line.product_id}")
        merged[line.product_id] = merged.get(line.product_id, 0) + line.quantity
        if merged[line.product_id] > 99:
            raise HTTPException(status_code=400, detail="Maximum quantity is 99 per item.")

    items = [
        {
            "product_id": product_id,
            "name": products[product_id]["name"],
            "plu": products[product_id]["plu"],
            "quantity": quantity,
            "unit_price_cents": products[product_id]["price_cents"],
            "line_total_cents": quantity * products[product_id]["price_cents"],
        }
        for product_id, quantity in merged.items()
    ]
    subtotal = sum(item["line_total_cents"] for item in items)
    tax = int((Decimal(subtotal) * TAX_RATE).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return {
        "items": items,
        "subtotal_cents": subtotal,
        "tax_rate": float(TAX_RATE),
        "tax_cents": tax,
        "total_cents": subtotal + tax,
    }


@router.post("/auth/login")
def login(credentials: LoginRequest):
    if credentials.username.strip().lower() != "cashier" or credentials.password != "1234":
        raise HTTPException(status_code=401, detail="Incorrect username or password.")
    token = token_urlsafe(32)
    _sessions.add(token)
    return {"access_token": token, "cashier": {"name": "Alex Morgan", "role": "Cashier"}}


@router.post("/auth/logout")
def logout(token: str = Depends(require_cashier)):
    if order_store.has_active_order(token):
        raise HTTPException(status_code=409, detail="Complete the active order before logging off.")
    _sessions.discard(token)
    return {"ok": True}


@router.post("/orders")
def start_order(request: StartOrderRequest, token: str = Depends(require_cashier)):
    return {"order_number": order_store.start_order(request.request_key, token)}


@router.get("/products")
def list_products(_: str = Depends(require_cashier)):
    return PRODUCTS


@router.get("/products/plu/{plu}")
def lookup_by_plu(plu: str, _: str = Depends(require_cashier)):
    if get_demo_errors().demo_be_plu_lookup_error and plu.strip() == PLU_LOOKUP_ERROR_PLU:
        raise HTTPException(
            status_code=503, detail="Demo error: product lookup service unavailable."
        )
    product = next((item for item in PRODUCTS if item["plu"] == plu.strip()), None)
    if product is None:
        raise HTTPException(status_code=404, detail=f"No item was found for PLU {plu}.")
    return product


@router.post("/orders/{order_number}/items")
def add_item_to_order(
    order_number: int, request: AddItemRequest, token: str = Depends(require_cashier)
):
    if request.product_id not in {product["id"] for product in PRODUCTS}:
        raise HTTPException(status_code=400, detail=f"Unknown product: {request.product_id}")
    try:
        items = order_store.add_item(order_number, request.product_id, request.quantity, token)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"order_number": order_number, "items": items}


@router.post("/orders/{order_number}/suspend")
def suspend_order(order_number: int, token: str = Depends(require_cashier)):
    """End an in-progress order without payment, freeing the register for a new one.

    Used as a recovery path when the register's local order state is out of
    sync with the server (e.g. after a session reset) and a new order cannot
    otherwise be started.
    """
    try:
        order_store.suspend_order(order_number, token)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"ok": True, "order_number": order_number, "status": "suspended"}


@router.post("/orders/{order_number}/force-suspend")
def force_suspend_order(order_number: int):
    """Force-suspend an order during register recovery, regardless of ownership."""
    if order_number <= 0:
        raise HTTPException(status_code=422, detail="Enter a valid order number.")
    order_store.force_suspend_order(order_number)
    return {"ok": True, "order_number": order_number, "status": "suspended"}


@router.post("/checkout/quote")
def quote(request: CheckoutRequest, _: str = Depends(require_cashier)):
    has_trigger_product = any(
        line.product_id == CHECKOUT_ERROR_PRODUCT_ID for line in request.lines
    )
    if get_demo_errors().demo_be_checkout_error and has_trigger_product:
        raise HTTPException(status_code=500, detail="Demo error: checkout pricing failed.")
    return calculate(request.lines)


@router.post("/payments")
def pay(request: PaymentRequest, token: str = Depends(require_cashier)):
    has_trigger_product = any(
        line.product_id == CARD_PAYMENT_ERROR_PRODUCT_ID for line in request.lines
    )
    if (
        request.method == "card"
        and get_demo_errors().demo_be_card_payment_error
        and has_trigger_product
    ):
        raise HTTPException(
            status_code=502, detail="Demo error: electronic payment gateway unavailable."
        )
    summary = calculate(request.lines)
    if request.method == "cash":
        if request.amount_tendered_cents is None:
            raise HTTPException(status_code=400, detail="Enter the cash amount tendered.")
        if request.amount_tendered_cents < summary["total_cents"]:
            raise HTTPException(status_code=400, detail="Cash tendered is less than the total.")

    receipt = {
        "created_at": datetime.now(UTC).isoformat(),
        "status": "paid",
        "method": request.method,
        "amount_tendered_cents": (
            request.amount_tendered_cents if request.method == "cash" else summary["total_cents"]
        ),
        "change_cents": (
            request.amount_tendered_cents - summary["total_cents"]
            if request.method == "cash"
            else 0
        ),
        **summary,
    }
    try:
        return order_store.complete_order(request.order_number, receipt, token)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

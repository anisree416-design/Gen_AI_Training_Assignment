"""Read-only incident and pipeline APIs for the local RCA dashboard."""

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.encoders import jsonable_encoder
from langgraph.types import Command

from app.config import get_settings
from app.db.repository import (
    delete_incidents,
    incident_numbers,
    list_incidents,
    read_analysis_runs,
    read_incident_events,
)
from app.graph.nodes.code_fix import code_fix
from app.graph.state import IncidentState
from app.services.incident_correlation import correlation_key, evidence_metadata, log_identity
from app.services.incident_presentation import operational_rca, short_analysis
from app.services.splunk_poller import pipeline_status

router = APIRouter(prefix="/api")


def _records():
    records = {item["incident_id"]: {**item, "rca": None} for item in read_analysis_runs()}
    for item in jsonable_encoder(list_incidents()):
        previous = records.get(item["incident_id"], {})
        records[item["incident_id"]] = {
            **previous,
            **item,
            "status": previous.get("status", "rca_ready" if item["rca"] else "analyzing"),
            "error": previous.get("error"),
        }
    # Consolidate historical per-log rows without deleting saved history.
    events = jsonable_encoder(read_incident_events())
    candidates = [item["error_event"].get("raw", {}) for item in records.values()]
    candidates += [event.get("raw", {}) for event in events]
    grouped = {}
    numbers = incident_numbers(records)
    for item in sorted(records.values(), key=lambda value: numbers[value["incident_id"]]):
        key = correlation_key(item["error_event"].get("raw", {}), candidates) or item["incident_id"]
        if key not in grouped:
            grouped[key] = {
                **item,
                "aliases": [],
                "events": [],
                "context": item.get("context") or {},
            }
        group = grouped[key]
        group["aliases"].append(item["incident_id"])
        group["events"].append(item["error_event"])
        if item.get("rca"):
            # The selected RCA's evidence IDs must still match its original log order.
            group.update(rca=item["rca"], context=item.get("context") or {}, status=item["status"])
        group["updated_at"] = max(group["updated_at"], item["updated_at"])
    for event in events:
        key = correlation_key(event.get("raw", {}), candidates)
        group = grouped.get(key) or grouped.get(f"INC-{event['error_id']}")
        if group:
            group["events"].append(event)
    numbers = incident_numbers([item["incident_id"] for item in grouped.values()])
    for item in grouped.values():
        unique = {event["error_id"]: event for event in item.pop("events")}
        item["event_count"] = len(unique)
        logs = list(item["context"].get("logs", []))
        identities = {log_identity(log) for log in logs}
        for event in unique.values():
            log = {
                "timestamp": event["occurred_at"],
                "level": "ERROR",
                "service": event["system"],
                "message": event["message"],
                "txn_id": event["txn_id"],
                "metadata": evidence_metadata(event.get("raw", {})),
            }
            if log_identity(log) not in identities:
                logs.append(log)
                identities.add(log_identity(log))
        item["context"]["logs"] = logs
        item["occurred_at"] = min(
            (event["occurred_at"] for event in unique.values() if event.get("occurred_at")),
            default=item.get("created_at", item["updated_at"]),
        )
        item["rca"] = operational_rca(item.get("rca"), item["error_event"])
        item["short_analysis"] = short_analysis(item["rca"], item["error_event"])
        item["error_event"].pop("raw", None)
        item["incident_number"] = numbers[item["incident_id"]]
    return sorted(grouped.values(), key=lambda item: item["occurred_at"], reverse=True)


def _short_analysis(item):
    return item["short_analysis"]


@router.get("/pipeline/status")
def pipeline():
    settings = get_settings()
    return {
        **pipeline_status,
        "missing_settings": settings.pipeline_missing_settings,
        "poll_interval_seconds": settings.splunk_poll_interval_seconds,
    }


@router.get("/incidents")
def incidents(limit: int = Query(default=100, ge=1, le=500), offset: int = Query(default=0, ge=0)):
    records = _records()
    items = [
        {
            **{
                key: value
                for key, value in item.items()
                if key
                in {
                    "incident_id",
                    "incident_number",
                    "occurred_at",
                    "status",
                    "updated_at",
                    "event_count",
                }
            },
            "error_event": {
                key: item["error_event"].get(key) for key in ("severity", "message", "occurred_at")
            },
            "rca": (
                {key: item["rca"].get(key) for key in ("summary", "severity")}
                if item.get("rca")
                else None
            ),
            "short_analysis": _short_analysis(item),
        }
        for item in records[offset : offset + limit]
    ]
    return {"items": items, "total": len(records)}


@router.delete("/incidents")
def delete_all_incidents():
    return {"deleted": delete_incidents()}


@router.delete("/incidents/{incident_id}")
def delete_incident(incident_id: str):
    record = next((item for item in _records() if incident_id in item["aliases"]), None)
    if record is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    deleted = delete_incidents(record["aliases"])
    return {"deleted": deleted, "incident_id": incident_id}


@router.get("/incidents/{incident_id}")
def incident(incident_id: str):
    record = next((item for item in _records() if incident_id in item["aliases"]), None)
    if record is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    return {key: value for key, value in record.items() if key != "aliases"}


@router.post("/incidents/{incident_id}/fix")
def fix_incident(incident_id: str, request: Request):
    record = next((item for item in _records() if incident_id in item["aliases"]), None)
    if record is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    if record.get("fix_result") and record["fix_result"].get("status") == "created":
        return {key: value for key, value in record.items() if key != "aliases"}

    graph = getattr(request.app.state, "graph", None)
    if graph is None:
        raise HTTPException(status_code=503, detail="The code analysis runtime is not ready.")
    thread_id = record["incident_id"]
    config = {"configurable": {"thread_id": thread_id}}
    snapshot = graph.get_state(config)
    if tuple(snapshot.next) == ("approval",):
        graph.invoke(
            Command(
                resume={
                    "status": "approved",
                    "reviewer": "incident-dashboard",
                    "note": "Code analysis and fix requested from incident details.",
                }
            ),
            config,
        )
    elif (record.get("fix_result") or {}).get("status") == "failed" and snapshot.values:
        # A transient model/Git failure may be retried from the persisted graph state
        # without re-running intake, retrieval, or RCA generation.
        code_fix(IncidentState.model_validate(snapshot.values))
    else:
        raise HTTPException(status_code=409, detail="This incident is not awaiting a fix decision.")
    refreshed = next((item for item in _records() if incident_id in item["aliases"]), None)
    if refreshed is None:
        raise HTTPException(status_code=500, detail="The incident disappeared during fix generation.")
    return {key: value for key, value in refreshed.items() if key != "aliases"}

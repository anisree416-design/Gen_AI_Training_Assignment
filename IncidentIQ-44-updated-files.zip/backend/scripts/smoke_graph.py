"""Run the stub graph end-to-end and print the event trace — standup demo.

Usage (from backend/):
    uv run python -m scripts.smoke_graph [--decision approve|reject]
                                         [--incident-id INC-DEMO-001]

Uses zero live LLM/Splunk/GitHub calls: rca and code_fix are overridden with
canned stand-ins, matching the sample checkout-service bug in
data/knowledge/error_docs.txt.
"""

import argparse
from unittest.mock import Mock

from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

from app.graph.builder import build_graph
from app.graph.checkpointer import state_serde
from app.graph.state import ApprovalDecision, ErrorEvent, FixResult, RCAResult, make_event
from app.rag.ingest import ingest_error_docs
from app.tools.splunk_query import set_splunk_client

SAMPLE_ERROR_EVENT = ErrorEvent(
    error_id="CO-500-001",
    system="checkout",
    event="CHECKOUT_SERVICE_CRASH",
    error_code="CO-500",
    message="ZeroDivisionError in calculate_discounted_total for an empty cart",
    txn_id="txn-demo-001",
    severity="critical",
)


def rca_override(state) -> dict:
    """Stand-in for the LLM-backed RCA node during the demo (no live LLM call)."""
    result = RCAResult(
        root_cause="calculate_discounted_total divides by item_count without guarding "
        "against an empty cart",
        contributing_factors=["no zero-item guard before the discount division"],
        evidence=["ZeroDivisionError in checkout_service.py"],
        evidence_ids=["error-doc-0"],
        impacted_component="checkout_service",
        severity="high",
        confidence=0.87,
        recommended_action="guard item_count == 0 before dividing",
        summary="Demo RCA (smoke script override — no live LLM call).",
    )
    return {"rca": result, "events": [make_event("rca", "override: demo RCA produced")]}


def code_fix_override(state) -> dict:
    """Stand-in for the LLM+GitHub-backed code-fix node during the demo (no live push)."""
    result = FixResult(
        status="created",
        branch_name="fix/demo-001",
        branch_url="(demo override — no real push performed)",
        commit_sha="0000000",
        files_changed=["checkout_service.py"],
        summary="Demo fix (smoke script override — no live GitHub push).",
    )
    return {
        "fix_result": result,
        "events": [make_event("code_fix", "override: demo branch created")],
    }


def print_events(events, start: int = 0) -> None:
    for event in events[start:]:
        print(f"  {event.node:<10} {event.detail}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--decision", choices=["approve", "reject"], default="approve")
    parser.add_argument("--incident-id", default="INC-DEMO-001")
    args = parser.parse_args()
    set_splunk_client(Mock(fetch_log_window=Mock(return_value=[])))

    chunk_count = ingest_error_docs()
    print(f"ingested {chunk_count} error-doc chunk(s) into the in-memory RAG collection\n")

    graph = build_graph(
        checkpointer=MemorySaver(serde=state_serde()),
        node_overrides={"rca": rca_override, "code_fix": code_fix_override},
    )
    config = {"configurable": {"thread_id": args.incident_id}}

    print("=== IncidentIQ smoke run ===\n")
    result = graph.invoke(
        {"incident_id": args.incident_id, "error_event": SAMPLE_ERROR_EVENT}, config
    )
    print_events(result["events"])
    print(f"\n  root cause: {result['rca'].root_cause}")

    status = "approved" if args.decision == "approve" else "rejected"
    print(f"\n--- human gate (FIX button): {status.upper()} — resuming ---\n")
    final = graph.invoke(
        Command(resume=ApprovalDecision(status=status, reviewer="smoke-script")),
        config,
    )
    print_events(final["events"], start=len(result["events"]))

    fix_result = final.get("fix_result")
    outcome = (
        f"{fix_result.branch_name} ({fix_result.status})" if fix_result else "(skipped — rejected)"
    )
    print(f"\n  fix result:  {outcome}")
    print(f"  nodes run:   {len(final['events'])}")
    print("\n=== smoke run complete ===")


if __name__ == "__main__":
    main()

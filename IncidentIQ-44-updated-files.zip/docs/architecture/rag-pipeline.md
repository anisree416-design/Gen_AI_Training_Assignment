# RAG Pipeline

## 1. Purpose

IncidentIQ uses retrieval-augmented generation (RAG) to give the RCA model relevant historical error knowledge. RAG helps the model connect a current Splunk error with documented symptoms, causes, and solutions while keeping the RCA grounded in evidence supplied by the application.

RAG does not independently diagnose an incident and does not guarantee that a similar historical error has the same root cause.

## 2. Pipeline

```mermaid
flowchart LR
    File[error_docs.txt] --> Chunk[Split on delimiter]
    Chunk --> Embed[Embedding function]
    Embed --> Chroma[(In-memory ChromaDB)]

    Error[Normalized Splunk error] --> Query[Build retrieval query]
    Query --> Chroma
    Chroma --> TopK[Top-K similar chunks]
    TopK --> Prompt[RCA prompt]
    Logs[Related Splunk logs] --> Prompt
    Error --> Prompt
    Prompt --> LLM[LLM]
    LLM --> RCA[Validated RCAResult]
```

## 3. Source of Truth

The knowledge source is:

```text
data/knowledge/error_docs.txt
```

The file is version controlled and should be updated through normal code review. ChromaDB is derived runtime state and must not be treated as the source of truth.

## 4. Error-Document Format

Each entry should describe one recognizable error family. Separate entries using a line containing `---`.

Recommended format:

```text
Error: CO-500 CHECKOUT_SERVICE_CRASH
Component: checkout_service
Symptoms: Checkout requests fail when the triggering condition occurs.
Cause: The checkout calculation performs an invalid operation.
Evidence: Logs contain the expected exception and error code.
Solution: Validate the input before performing the calculation.
Validation: Re-run checkout with both the failing and normal cases.

---
```

Current ingestion only requires non-empty text separated by `\n---\n`; the labels are conventions that improve retrieval and human maintainability.

### Authoring rules

- Use a stable error code when one exists.
- Name the affected component using the same value expected in `RCAResult.impacted_component`.
- Describe observable symptoms separately from the suspected cause.
- Include the smallest safe remediation.
- Include a validation step.
- Do not include secrets, customer information, real card data, or access tokens.
- Avoid multiple unrelated problems in one entry.
- Prefer concrete language that also appears in application logs.

## 5. Ingestion

Implementation files:

```text
backend/app/rag/ingest.py
backend/app/rag/store.py
```

`ingest_error_docs()` performs these steps:

1. Resolve `ERROR_DOCS_PATH` relative to the repository root.
2. Read the UTF-8 text file.
3. Split it using `\n---\n`.
4. Remove empty chunks.
5. Reset the existing ChromaDB collection.
6. Deduplicate entries and add chunks with stable content-derived IDs.
7. Return the number of loaded chunks.

The FastAPI lifecycle in `main.py` calls ingestion on every startup and rejects an empty knowledge base.

## 6. Vector Store and Embeddings

The collection name is:

```text
error_docs
```

The application uses `chromadb.EphemeralClient`, so the collection exists only in the backend process memory.

The collection explicitly uses ChromaDB's `ONNXMiniLM_L6_V2` embedding function for both ingestion and queries. Dependency/model artifact pinning and retrieval-quality evaluation remain deployment considerations.

Operational implications:

- The first ingestion may need to download the default model.
- A machine without the required model or network access may fail during ingestion.
- Restarting the application clears and rebuilds the collection.
- Multiple backend worker processes would each hold a separate collection.

## 7. Retrieval Query

The RAG node builds the query from the current error:

```text
{error_code} {event} {message}
```

Example:

```text
CO-500 CHECKOUT_SERVICE_CRASH ZeroDivisionError while calculating checkout discount
```

The number of requested results comes from:

```dotenv
RAG_TOP_K=5
```

The actual result count is the smaller of `RAG_TOP_K` and the collection size.

## 8. Retrieval Output

Every result becomes an `ErrorDoc`:

```json
{
  "doc_id": "error-doc-0",
  "content": "Error: CO-500 ...",
  "similarity": 0.91,
  "source_section": ""
}
```

The current implementation calculates display similarity as:

```text
1 - Chroma distance
```

and clamps the value to the range `0..1`. This is an approximation for display and ranking visibility; it must not be interpreted as a calibrated probability.

## 9. RCA Grounding

The RCA prompt contains:

- The normalized current error.
- Messages from the related Splunk log window.
- Content and stable IDs from the retrieved historical error documents.

Logs have `log-N` IDs. The prompt includes these source IDs, and unrecognized IDs
are removed from the response. Source context is saved alongside each analysis for
inspection in the RCA dashboard. This validates ID membership, not claim accuracy.

The RCA model is instructed to return strict JSON matching `RCAResult` and to avoid inventing evidence. Pydantic validation rejects responses that do not match the contract.

Expected RCA fields include:

- Root cause
- Contributing factors
- Evidence and evidence IDs
- Impacted component
- Severity
- Confidence
- Recommended action
- Summary

## 10. Updating the Knowledge Base

Use this process:

1. Add or update an entry in `data/knowledge/error_docs.txt`.
2. Preserve the `---` delimiter between entries.
3. Review the entry for sensitive data.
4. Add or update a retrieval test for its error code and representative message.
5. Restart the backend so the in-memory collection is rebuilt.
6. Confirm the startup/health document count.
7. Query using a representative error and confirm the expected entry appears near the top.

Do not manually update ChromaDB. Any manual update disappears after restart and creates a mismatch with the repository.

## 11. Testing Strategy

### Unit tests

- Empty text produces no chunks.
- One entry produces one chunk.
- Multiple `---`-separated entries produce the expected chunks.
- Whitespace-only chunks are ignored.
- A missing source file returns zero or produces the agreed startup error.
- Re-ingestion replaces rather than duplicates the collection.
- `RAG_TOP_K` is respected.

### Retrieval tests

Use known deterministic examples:

```text
Given:
  error_code = CO-500
  event = CHECKOUT_SERVICE_CRASH
  message = ZeroDivisionError during checkout

Expected:
  The CO-500 document is included in the returned results.
```

Also test an unrelated query and document the acceptable result behavior. Similarity search normally returns a nearest result even when the match is weak, so production logic may require a minimum-distance threshold.

### Integration tests

- Application startup loads more than zero chunks.
- A graph run places retrieved documents in `similar_error_docs`.
- The RCA prompt contains the retrieved document text.
- Automated tests use a fake LLM and do not contact a live model provider.

## 12. Observability

The application should expose non-sensitive RAG readiness information:

```json
{
  "rag_documents": 3,
  "rag_status": "ready"
}
```

Recommended internal logs:

- Source path without file contents.
- Number of ingested chunks.
- Ingestion duration.
- Query duration and returned count.
- Document IDs and distances, but not sensitive document content.
- Clear ingestion and query errors.

## 13. Failure Behavior

| Failure | Expected behavior |
|---|---|
| File does not exist | Startup should fail clearly once lifecycle integration is enabled, unless empty RAG is explicitly allowed |
| File is empty | Report zero chunks and do not claim RAG is ready |
| Embedding model cannot load | Report startup failure with a useful operational message |
| Chroma query fails | Record the graph error; do not invent historical evidence |
| No documents are available | RCA may proceed using the current error and Splunk logs, but must show that no historical context was found |
| Weak similarity | Treat results as context, not proof; consider a future threshold |

## 14. Limitations and Future Improvements

- Pin dependency/model artifacts and evaluate embedding quality with representative errors.
- Add metadata fields such as component, error code, version, and document revision.
- Add document metadata filters and source provenance beyond content-derived IDs.
- Add a retrieval threshold.
- Add retrieval quality evaluation fixtures.
- Validate whether each cited source actually supports its associated claim.
- Consider a persistent/vector-service deployment only if corpus size or multi-worker requirements justify it.
- Add a controlled re-index endpoint or administrative command if restarts become undesirable.

# Run the Splunk-to-RCA demo

The implemented scope ends at saved RCA displayed in the browser. The workflow
pauses at approval, and the dashboard has no code-fix or deployment action.

## Setup

Use Python 3.12+ and Node 20+. From the repository root, copy `.env.example` to
`.env` if you do not already have a root `.env`. Preserve your existing values.
Use plain `KEY=value` entries: no Markdown links or escaped underscores.

Configure these locally:

| Setting | Purpose |
| --- | --- |
| `SPLUNK_HEC_URL`, `SPLUNK_HEC_TOKEN` | Send POS telemetry to Splunk |
| `SPLUNK_INDEX` | Index receiving the POS logs (`incidentiq` by default) |
| `SPLUNK_SEARCH_URL` | Your Splunk REST Search base URL, not the HEC URL |
| `SPLUNK_SEARCH_TOKEN` | Search API bearer token with permission to search the index |
| `SPLUNK_SEARCH_USERNAME`, `SPLUNK_SEARCH_PASSWORD` | Local Enterprise login; used when the search token is blank |
| `SPLUNK_SEARCH_QUERY` | `index=incidentiq (level=ERROR OR status=ERROR)` |
| `OPENAI_API_KEY` | Credential for the configured LLM provider |
| `OPENAI_MODEL` | A model available to that credential and compatible with the chat client |
| `OPENAI_BASE_URL` | Optional custom compatible endpoint; leave blank for the default |

HEC credentials do not substitute for Search credentials. Change both index settings
if you use a different index. Restart the backend after configuration changes.
Missing Search/LLM credentials pause polling and are shown on the dashboard.

### Local Splunk Enterprise

The backend supports Splunk Enterprise's REST API using your local Splunk username
and password (HTTP Basic authentication), or a bearer token. Both error polling and
related-log retrieval use the same connection. A nonempty search token takes
precedence, so clear an old Cloud token when switching to a local login.

Use these root `.env` values when Splunk and IncidentIQ run on the same machine:

```dotenv
SPLUNK_SEARCH_URL=https://localhost:8089
SPLUNK_SEARCH_TOKEN=
SPLUNK_SEARCH_USERNAME=admin
SPLUNK_SEARCH_PASSWORD='your-local-Splunk-password'
SPLUNK_INDEX=incidentiq
SPLUNK_SEARCH_QUERY="index=incidentiq (level=ERROR OR status=ERROR)"
SPLUNK_POLL_INTERVAL_SECONDS=30
SPLUNK_VERIFY_SSL=false
SPLUNK_HEC_URL=https://localhost:8088/services/collector/event
SPLUNK_HEC_TOKEN=your-local-HEC-token
SPLUNK_REQUEST_CHANNEL=
INCIDENTIQ_API_PROXY_TARGET=http://127.0.0.1:8001
```

Replace the password and HEC token locally; use your actual Splunk username if it
isn't `admin`. `SPLUNK_VERIFY_SSL=false` is for local development with Splunk's
self-signed certificate and applies to both Search and HEC. Use `true` with trusted
certificates. The management API uses HTTPS on 8089; the browser UI normally uses
HTTP on 8000. IncidentIQ uses 8001 below to avoid that port conflict. If Splunk runs
in Docker or a VM, publish/forward 8089 and 8088 and adjust the hostname as needed.

To send the POS application's logs to local Splunk:

1. Open Splunk Web at `http://localhost:8000` and log in.
2. Under **Settings > Indexes**, create the `incidentiq` events index if needed.
3. Under **Settings > Data inputs > HTTP Event Collector > Global Settings**, enable
   HEC on port 8088 with SSL enabled to match the URL above.
4. Create a local HEC token, allow the `incidentiq` index and select it as the default.
   Use `_json` as the source type. Leave indexer acknowledgment disabled for this
   demo's best-effort telemetry sender. Put the token in `SPLUNK_HEC_TOKEN`.
5. Ensure the Search user can search `incidentiq`. Restart both IncidentIQ servers
   and trigger a demo error. In Splunk Web, verify
   `index=incidentiq (level=ERROR OR status=ERROR)` returns it.

HEC is optional if logs already arrive in the index through another input. Existing
Cloud data is not copied automatically. Custom logs need searchable `level=ERROR`
or `status=ERROR` fields for the default query; adjust the query for other formats.

Check connectivity and authentication before starting RCA:

```powershell
Test-NetConnection -ComputerName localhost -Port 8089
# Prompts for the password rather than placing it in your command history.
curl.exe -k --user admin "https://localhost:8089/services/search/jobs" --data-urlencode 'search=search index=incidentiq earliest=-24h | head 5' -d output_mode=json -d exec_mode=oneshot
```

`-k` is only for this local self-signed certificate. A successful JSON search with
empty results means the connection works but the selected index/time window has
no matching events. HTTP 401 indicates a login problem; a TCP failure means the
local service or mapped port is unavailable. Never use the Cloud HEC token for the
local collector. See [Splunk REST authentication documentation](https://help.splunk.com/en/splunk-enterprise/leverage-rest-apis/rest-api-user-manual/9.4/rest-api-user-manual/basic-concepts-about-the-splunk-platform-rest-api).

Terminal 1, from `backend`:

```powershell
py -3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install -e .
.\.venv312\Scripts\python.exe -m uvicorn app.main:app --reload --port 8001
```

Terminal 2, from `frontend`:

```powershell
npm ci
npm run dev
```

Open http://localhost:5173/incidents for RCA. The POS at http://localhost:5173
also has an **IncidentIQ · RCA** link. Its demo login is `cashier` / `1234`.

## Generate an incident

Enable one demo switch at a time, restart both dev servers, and trigger its action:

| Switch | Action |
| --- | --- |
| `VITE_DEMO_FE_INVALID_ITEM_QUANTITY` | Add Baby Spinach |
| `VITE_DEMO_FE_INVALID_CHECKOUT_LINES` | Add Fresh Carrots, then Total |
| `VITE_DEMO_FE_INVALID_CARD_AMOUNT` | Add Free Range Eggs, then pay by card |
| `DEMO_BE_PLU_LOOKUP_ERROR` | Look up Sourdough Bread PLU 1072 |
| `DEMO_BE_CHECKOUT_ERROR` | Add Greek Yogurt, then Total |
| `DEMO_BE_CARD_PAYMENT_ERROR` | Add Dark Chocolate, then pay by card |

Splunk is polled every 30 seconds by default. Allow additional time for indexing
and the LLM response. Dashboard data refreshes every five seconds. Frontend and backend errors for the same failed request share one incident.
A later failed request in the same order creates a new incident.
The initial search covers the past 24 hours. Later polls overlap by five minutes
to tolerate indexing delay; stable event IDs prevent repeat analysis.

## Data flow

1. Startup reads `data/knowledge/error_docs.txt`, splits entries on `---`, and
   embeds them with the explicitly selected ONNX MiniLM L6 v2 model in ChromaDB.
   The first startup may download the embedding model; subsequent runs use its cache.
2. ChromaDB is in memory and rebuilt on every restart. Stable content-derived IDs
   identify document revisions. The knowledge file includes all six demo scenarios.
3. Each Splunk error is normalized. Related logs are retrieved from the configured
   index within five minutes before/after the event, capped at 200 entries.
4. RAG retrieves up to `RAG_TOP_K` similar documents. The LLM receives the error,
   related logs and documents with source IDs. Historical matches are context, not proof.
5. Validated RCA and its source context are persisted in SQLite (`backend/app.sqlite3`).
   The UI displays root cause, factors, evidence, confidence and recommended action.
6. Failed analysis is recorded and retried from its checkpoint on the next poll.
   Restarting preserves completed RCA and processed-event IDs.

## APIs

- `GET /api/incidents?limit=25&offset=0`: paginated incident list, including failures.
- `GET /api/incidents/{incident_id}`: RCA and saved knowledge/log context.
- `GET /api/pipeline/status`: missing settings, last successful poll, safe error summary.
- `GET /api/health`: runtime readiness and knowledge document count.

These read APIs serve a local POC without authentication. They should only be
exposed in a trusted demo environment. API docs: http://localhost:8001/docs.

## Offline verification

From `backend`:

```powershell
.\.venv312\Scripts\python.exe -m pip install pytest pytest-asyncio ruff
.\.venv312\Scripts\python.exe -m pytest -q
```

The integration tests use mocked Splunk and LLM responses, a deterministic test
embedding function, real Chroma queries, real graph nodes/checkpoints, SQLite and
FastAPI endpoints. They cover retrieval, citation IDs, persistence, deduplication,
failed-output retry and missing configuration. They do not verify live credentials
or semantic quality of the production embedding model/LLM.

From `frontend`, run `npm run build` to check the production bundle.

For optional browser verification, after building the frontend set
`RCA_TEST_BROWSER` to your Chrome/Edge executable and run the browser test from `backend`:

```powershell
$env:RCA_TEST_BROWSER = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
.\.venv312\Scripts\python.exe -m pytest tests/integration/test_rca_dashboard.py -k browser -q
Remove-Item Env:RCA_TEST_BROWSER
```

This launches a headless browser with an isolated temporary profile against a local
test server and verifies that saved RCA, recommended actions, knowledge and logs
appear in the rendered page. It does not use your live Splunk or LLM credentials.


## Incident list and grouping

The incident page fetches `/api/incidents` on opening and refreshes every five
seconds. The list contains a persistent incident number, brief analysis,
occurrence time, status, and View details. All saved incidents are accessible
through pagination. New means not yet opened in this browser; viewed state is
stored locally. Opening an incident fetches `/api/incidents/{incident_id}` and
shows its root cause, cashier sequence, endpoint responses, and request evidence.

New telemetry carries request IDs through API failures, business-operation errors,
and the error dialog. Local validation errors carry their own flow ID. Errors
sharing that ID are stored together in `incident_events` and analyzed once per
poll. Late error logs refresh the same incident. Another failed request in the
same order creates another incident, including a failed retry. `incident_groups`
assigns stable display numbers. Both tables are added automatically without
removing existing records.

Historical per-log records are consolidated in the API view when their saved
request IDs match. A legacy UI message without an ID is matched only when its
message, order/session, and five-second window identify exactly one request.
Ambiguous historical errors remain separate, and old detail URLs keep working.

RCA uses recorded cashier actions, HTTP methods, endpoints, submitted fields,
response bodies and timestamps. Credentials are redacted. Operational knowledge
entries explain the failure behavior rather than demo setup. If the internal
cause cannot be established, the analysis says so. Historical setup-only RCA is
presented as an observed failure with uncertainty; original stored evidence is
preserved. Complete new request trails require reloading the POS frontend.

Frontend telemetry regression tests (from `frontend`):

```powershell
node --test tests/incident-telemetry.test.mjs
```
